EFFECT.GlowMat = Material( "sprites/light_glow02_add" )
EFFECT.SmokeMat = {
	"particle/smokesprites_0001",
	"particle/smokesprites_0002",
	"particle/smokesprites_0003",
	"particle/smokesprites_0004",
	"particle/smokesprites_0005",
	"particle/smokesprites_0006",
	"particle/smokesprites_0007",
	"particle/smokesprites_0008",
	"particle/smokesprites_0009",
	"particle/smokesprites_0010",
	"particle/smokesprites_0011",
	"particle/smokesprites_0012",
	"particle/smokesprites_0013",
	"particle/smokesprites_0014",
	"particle/smokesprites_0015",
	"particle/smokesprites_0016"
}

EFFECT.DustMat = {
	"effects/lvs_base/particle_debris_01",
	"effects/lvs_base/particle_debris_02",
}

EFFECT.DecalMat = Material( util.DecalMaterial( "Scorch" ) )

function EFFECT:Init(data)
	local scale = data:GetMagnitude() * 0.5

	self.Scale = 3 * scale

    self.Pos = data:GetOrigin()
    self.Dir = data:GetNormal()


	ParticleEffect("gred_50mm", self.Pos, Angle(-90,0,0), nil)

    -- Play a particle effect at the impact position
    --ParticleEffect("gred_50mm", self.Pos, Angle(-90,0,0), nil)

    -- Optionally play a sound
    -- sound.Play("explosions/doi_wp_01.wav", self.Pos, 100, 100)
	
	local traceSky = util.TraceLine( {
		start = self.Pos,
		endpos = self.Pos + Vector(0,0,50000),
		filter = self,
	} )

	local traceWater = util.TraceLine( {
		start = traceSky.HitPos,
		endpos = self.Pos - Vector(0,0,100),
		filter = self,
		mask = MASK_WATER,
	} )

	if traceWater.Hit then
		local effectdata = EffectData()
		effectdata:SetOrigin( traceWater.HitPos )
		effectdata:SetScale( 100 )
		effectdata:SetFlags( 2 )
		util.Effect( "WaterSplash", effectdata, true, true )
	end

	local Pos = self.Pos
	local Dist = (traceWater.HitPos - Pos):Length()
	local ply = LocalPlayer():GetViewEntity()

	if not IsValid( ply ) then return end

	local delay = (Pos - ply:GetPos()):Length() / 13503.9

	if traceWater.Hit and Dist > 150 then
		timer.Simple( delay, function()
			local effectdata = EffectData()
			effectdata:SetOrigin( Pos )
			util.Effect( "WaterSurfaceExplosion", effectdata, true, true )
		end )

		if Dist > 300 then return end
	else
		timer.Simple( delay, function()
			sound.Play( "LVS.BULLET_EXPLOSION", Pos )
			sound.Play( "LVS.BULLET_EXPLOSION_DYNAMIC", Pos )
		end )

		local trace = util.TraceLine( {
			start = self.Pos + Vector(0,0,100),
			endpos = self.Pos - Vector(0,0,100),
			mask = MASK_SOLID_BRUSHONLY,
		} )

		if trace.Hit and not trace.HitNonWorld then
			util.DecalEx( self.DecalMat, trace.Entity, trace.HitPos + trace.HitNormal, trace.HitNormal, Color(255,255,255,255), self.Scale * 2.5, self.Scale * 2.5 )
		end
	end
end