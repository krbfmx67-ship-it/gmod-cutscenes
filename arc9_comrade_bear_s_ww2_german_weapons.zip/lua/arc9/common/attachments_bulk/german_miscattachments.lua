local ATT = {}

ATT.PrintName = [[M1884/98 Bayonet]]
ATT.CompactName = "BAYONET"
ATT.Description = [[A M1884/98 Bayonet which can fit on any weapon that supports the bayonet lugs, This includes Kar98K Rifles, MKb-42H and W, as well as the G41 Rifle.]]
ATT.Icon = Material("entities/mkbh_bayonet.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_kar98_bayonet"}

ATT.Bash = true
ATT.BashWhileSprint = true
ATT.BashDamage = 100
ATT.BashRange = 64
ATT.BashLungeRange = 0
ATT.PreBashTime = 0.1
ATT.PostBashTime = 0.75
ATT.BashDamageType = DMG_SLASH

ARC9.LoadAttachment(ATT, "cb_perk_kar98_bayonet")

ATT = {}

ATT.PrintName = [[Fold Stock]]
ATT.CompactName = "FOLD STOCK"
ATT.Description = [[Folding the stock will allow you to use the weapon in more compact and close quarter situations at the cost of decrease recoil control.]]
ATT.Icon = Material("entities/arc9_att_doi_perk_stock.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_foldstock"}

ATT.IKAnimationProxy = {
    ["ready"] = {
        -- All standard animation stuff works
        Source = "base_draw",
        Priority = 1, -- Like _Priority, this determines whether a proxy should override other identical animations.
    }
} -- When an animation event plays, override it with one based on this LHIK model.

ARC9.LoadAttachment(ATT, "cb_perk_foldstock")

ATT = {}

ATT.PrintName = [[STG Mag Grip]]
ATT.CompactName = "MagGrip"
ATT.Description = [[Just a way that some people grip the STG type weapons.]]
ATT.Icon = Material("entities/cb_stg_maggrip.png", "mips smooth")

ATT.Model = "models/weapons/comradebear/ww2/att/stg44_maggrip_pose.mdl"

ATT.ModelOffset = Vector(-16, -2.6, 7)

ATT.LHIK = true
ATT.LHIK_Priority = 50

ATT.SortOrder = 0

ATT.Category = {"cb_stg_maggrip"}

ARC9.LoadAttachment(ATT, "cb_stg_maggrip")

ATT = {}

ATT.PrintName = [[STG-44 Optic Rail]]
ATT.CompactName = "Optic Rail"
ATT.Description = [[An additional dovetail style plate welded to the side of the reciever to allow the installing of compatible optics.]]
ATT.Icon = Material("entities/stg_rail.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_stg_rail"}

ARC9.LoadAttachment(ATT, "cb_stg_rail")

ATT = {}

ATT.PrintName = [[StKb 98K/I Full Auto Modification]]
ATT.CompactName = "Full Auto"
ATT.Description = [[These are some parts that are compatible with the StKb 98K/I, To allow the weapon to fire from an open bolt as well as firing full auto.]]
ATT.Icon = Material("entities/funnyface.png", "mips smooth")

ATT.SortOrder = 0

ATT.EjectDelay = 0.12

ATT.RPM = 250

ATT.ShootSound = "comradebear/wpn/ger/g43/g41_fp.wav"
ATT.DistantShootSound = "comradebear/wpn/ger/g43/g41_dist.wav"

ATT.ShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_fp.wav"
ATT.DistantShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_dist.wav"

ATT.Firemodes = {
    {
        Mode = -1,
    }
}

ATT.Category = {"cb_stkb_fullauto"}

ARC9.LoadAttachment(ATT, "cb_stkb_fullauto")

ATT = {}

ATT.PrintName = [[P08 Stock]]
ATT.CompactName = "P08 Stock"
ATT.Description = [[Just a way that some people grip the STG type weapons.]]
ATT.Icon = Material("entities/cb_stg_maggrip.png", "mips smooth")

ATT.Model = "models/weapons/comradebear/ww2/att/p08luger_stock.mdl"

ATT.ModelOffset = Vector(-16, -2.6, 7)
ATT.ModelAngleOffset = Angle(0, -90, 180)

ATT.LHIK = true
ATT.LHIK_Priority = 50

ATT.SortOrder = 0

ATT.Category = {"cb_p08_stock"}

ARC9.LoadAttachment(ATT, "cb_p08_stock")

ATT = {}

ATT.PrintName = [[Unfold Bipod]]
ATT.CompactName = "Unfold Bipod"
ATT.Description = [[Unfolding the bipod will allow the user to rest their gun on the bipod of a surface to reduce recoil and increase accuracy.
allowing for accurate and prolonged engagement on targets.]]
ATT.Icon = Material("entities/funnyface.png", "mips smooth")

ATT.Bipod = true

ATT.SortOrder = 0

ATT.Category = {"cb_dply_bipod"}

ARC9.LoadAttachment(ATT, "cb_dply_bipod")

ATT = {}

ATT.PrintName = [[MP-508 Vertical Grip]]
ATT.CompactName = "Vertical Grip"
ATT.Description = [[Prototype addition to the Prototype Gustloff rifle.]]
ATT.Icon = Material("entities/cb_stg_maggrip.png", "mips smooth")

ATT.Model = "models/weapons/comradebear/ww2/att/vg15_vertgrip.mdl"

ATT.ModelOffset = Vector(-16, -2.6, 7)

ATT.LHIK = true
ATT.LHIK_Priority = 50

ATT.SortOrder = 0

ATT.Category = {"cb_mp508_vertgrip"}

ARC9.LoadAttachment(ATT, "cb_mp508_vertgrip")

local ATT = {}

ATT.PrintName = [[Silent Hunter]]
ATT.CompactName = "Shhhh"
ATT.Description = [[Your a seasoned sniper, You know to manipulate your weapon to be as quiet as possible, Even better control while cycling to maintain a constant view on your scope or sights.]]
ATT.Icon = Material("entities/perk_silenthunter.png", "mips smooth")

ATT.Sway = 0.4

ATT.CustomPros = {
    ["Cycling Volume"] = "30 Db",
    ["Reloading Volume"] = "30 Db",
}
ATT.CustomCons = {
    ["Slow Reload"] = "",
    ["Cannot use Stripper clips"] = "",
}

ATT.SortOrder = 0

ATT.Category = {"cb_perk"}

ARC9.LoadAttachment(ATT, "cb_perk_silent_hunter")