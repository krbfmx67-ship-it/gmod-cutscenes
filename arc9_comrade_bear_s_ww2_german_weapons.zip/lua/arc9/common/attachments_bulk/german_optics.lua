local ATT = {}

ATT = {}

ATT.PrintName = [[ZF-39 4x]]
ATT.CompactName = "ZF-39"
ATT.Description = [[Short to medium range optic for the Kar98K Rifles.]]
ATT.Icon = Material("entities/optic_kar98_zf39_12x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_kar98_zf39_12x", "ger_optic_kar98k"}

ATT.Model = "models/weapons/comradebear/ww2/att/zf39_scope.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(-0, 12, -1.9),
        Ang = Angle(0, 0, 0),
		KeepBaseIrons = true,
        ViewModelFOV = 35
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 4
ATT.RTScopeMagnification = 4
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeReticleScale = 1

ATT.RTScopeNew_ShadowScale = 4 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.2 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 1
ATT.RTScopeNew_ShaderDistorsionMult = 2

ATT.AimDownSightsTimeMult = 1.8

ARC9.LoadAttachment(ATT, "optic_kar98_zf39_12x")

ATT = {}

ATT.PrintName = [[MKb-42 ZF-41 1.5x]]
ATT.CompactName = "MKB ZF-41"
ATT.Description = [[Short to medium range optic for the Kar98K Rifles.]]
ATT.Icon = Material("entities/optic_zf41_1.5x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_zf41_1.5x", "ger_optic_mkb42"}

ATT.Model = "models/weapons/comradebear/ww2/att/mkb_zf41_v2.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0, 14, -1.95),
        Ang = Angle(0, 0, 0),
		KeepBaseIrons = true,
        Magnification = 1,
        ViewModelFOV = 36,
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 4
ATT.RTScopeMagnification = 1.5
ATT.RTScopeReticle = Material("reticles/germancross#1_zf41.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 12
ATT.RTScopeReticleScale = 1.5

ATT.RTScopeNew_ShadowScale = 1.3 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.2 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 4
ATT.RTScopeNew_ShaderDistorsionMult = 50

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_zf41_1.5x")

ATT = {}

ATT.PrintName = [[ZF-41 1.5x]]
ATT.CompactName = "ZF-41"
ATT.Description = [[Short range optic for the Kar98K Rifles.]]
ATT.Icon = Material("entities/optic_k98_zf41_1.5x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_k98_zf41_1.5x", "ger_optic_short_k98"}

ATT.Model = "models/weapons/comradebear/ww2/att/k98_zf41_v2.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0, 14, -1.95),
        Ang = Angle(-90, 0, 0),
		KeepBaseIrons = true,
        ViewModelFOV = 35
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 1
ATT.RTScopeMagnification = 1.5
ATT.RTScopeReticle = Material("reticles/germancross#1_zf41.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 12
ATT.RTScopeReticleScale = 1.5

ATT.RTScopeNew_ShadowScale = 0.8 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.2 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 4
ATT.RTScopeNew_ShaderDistorsionMult = 50

ARC9.LoadAttachment(ATT, "optic_k98_zf41_1.5x")

ATT = {}

ATT.PrintName = [[ZF-41 1.5x]]
ATT.CompactName = "ZF-41"
ATT.Description = [[Short range optic for the Kar98K Rifles.]]
ATT.Icon = Material("entities/optic_g41_zf41_1.5x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_g41_zf41_1.5x", "ger_optic_g41"}

ATT.Model = "models/weapons/comradebear/ww2/att/g41_zf41_v2.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0, 14, -1.95),
        Ang = Angle(0, 0, 0),
		KeepBaseIrons = true,
        ViewModelFOV = 35
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 1
ATT.RTScopeMagnification = 1.5
ATT.RTScopeReticle = Material("reticles/germancross#1_zf41.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 12
ATT.RTScopeReticleScale = 1.5

ATT.RTScopeNew_ShadowScale = 0.8 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.2 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 4
ATT.RTScopeNew_ShaderDistorsionMult = 50

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_g41_zf41_1.5x")

ATT = {}

ATT.PrintName = [[ZF-4 4x]]
ATT.CompactName = "ZF-4"
ATT.Description = [[Medium range optic for the STG-44 and G43 Rifles.]]
ATT.Icon = Material("entities/optic_gen_zf4_4x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_zf4_rail", "optic_zf4_g43"}

ATT.Model = "models/weapons/comradebear/ww2/att/rail_zf4_v2.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(-0, 12, -3),
        Ang = Angle(-90, 0, 0),
        ViewModelFOV = 25
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 3
ATT.RTScopeMagnification = 4
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 6
ATT.RTScopeReticleScale = 3

ATT.RTScopeNew_ShadowScale = 0.6
ATT.RTScopeNew_ShadowIntensity = 1
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 1
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1

ATT.ScopeScreenRatio = 0.25

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_gen_zf4_4x")

ATT = {}

ATT.PrintName = [[ZG-1229 Vampir Night Scope]]
ATT.CompactName = "ZG-1229"
ATT.Description = [[A short range prototype infrared night vision scope.
The Scope and infrared lamp requires a large battery pack and other electronics to function. This pack along with the massive
lamp, scope, and cables running all over will weigh you down significantly. But, You can atleast see in the dark.
Yes, That annoying hum comes with the pack.]]
ATT.Icon = Material("entities/optic_stg_zg1229.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_zf4_rail", "optic_gen_zg1229_vampir"}

ATT.Model = "models/weapons/comradebear/ww2/att/stg_zg1229_v2.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0.28, 14, -3.45),
        Ang = Angle(-90, 0, 0),
        ViewModelFOV = 25,
        Blur = true,
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 3
ATT.RTScopeMagnification = 1
ATT.RTScopeReticle = Material("reticles/germancross#4.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeReticleScale = 2

ATT.RTScopeNew_ShadowScale = 2.5 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.2 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 1
ATT.RTScopeNew_ShaderDistorsionMult = 1

ATT.RTScopeNew_ChromaticAberrationMult = 1

ATT.RTScopeNew_DisableShader = false

ATT.CantPeek = true
ATT.Speed = 0.75

ATT.RTScopeNightVision = true
ATT.RTScopeNightVisionMonochrome = true
ATT.RTScopeNightVisionCC = {
    ["$pp_colour_addr"] = -0.01,
    ["$pp_colour_addg"] = -0.02,
    ["$pp_colour_addb"] = -0.02,
    ["$pp_colour_brightness"] = 0.15,
    ["$pp_colour_contrast"] = 1,
    ["$pp_colour_colour"] = 1,
    ["$pp_colour_mulr"] = 0,
    ["$pp_colour_mulg"] = 0,
    ["$pp_colour_mulb"] = 0
}

ATT.RTScopeNightVisionFunc = function(swep) -- Okay, So I used ChatGPT, So what. You gunna burn me alive?
    if not CLIENT then return end
    if not IsValid(swep) then return end
    local owner = swep:GetOwner()
    if not IsValid(owner) then return end

    -- only enable when actually scoped in
    local sight = 0
    if swep.GetSightAmount then
        sight = swep:GetSightAmount()
    elseif swep.GetSightDelta then
        sight = 1 - swep:GetSightDelta()
    end

    if sight >= 0.95 then
        -- create light if not already created
        if not IsValid(swep.ScopeLight) then
            local proj = ProjectedTexture()
            if not proj then return end

            proj:SetTexture("effects/flashlight001")
            proj:SetFarZ(1500) -- distance
            proj:SetNearZ(8)
            proj:SetFOV(45)
            proj:SetBrightness(0.15)
            proj:SetEnableShadows(false)
            swep.ScopeLight = proj
        end

        -- update position & angle
        local vm = owner:GetViewModel()
        if IsValid(vm) and IsValid(swep.ScopeLight) then
            local att = vm:LookupAttachment("muzzle") or 0
            if att > 0 then
                local attach = vm:GetAttachment(att)
                if attach then
                    swep.ScopeLight:SetPos(attach.Pos + Vector(-0, 1, 15))
                    swep.ScopeLight:SetAngles(attach.Ang)
                end
            else
                -- fallback: just use eye position/angles
                swep.ScopeLight:SetPos(owner:EyePos())
                swep.ScopeLight:SetAngles(owner:EyeAngles())
            end
            swep.ScopeLight:Update()
        end
    else
        -- not scoped → remove the light if it exists
        if IsValid(swep.ScopeLight) then
            swep.ScopeLight:Remove()
            swep.ScopeLight = nil
        end
    end
end

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_gen_zg1229_vampir")