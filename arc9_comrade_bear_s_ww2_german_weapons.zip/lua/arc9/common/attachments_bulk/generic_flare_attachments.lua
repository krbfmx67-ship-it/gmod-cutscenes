local ATT = {}

ATT.PrintName = [[Red Flares]]
ATT.CompactName = "RED"
ATT.Description = [[Red Flares for flare guns, Used for signaling and illumination with a green hue]]
ATT.Icon = Material("entities/red_flare.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_flare_types"}

ARC9.LoadAttachment(ATT, "cb_flare_red")

ATT = {}

ATT.PrintName = [[Green Flares]]
ATT.CompactName = "GREEN"
ATT.Description = [[Green Flares for flare guns, Used for signaling and illumination with a green hue]]
ATT.Icon = Material("entities/green_flare.png", "mips smooth")

ATT.SortOrder = 1

ATT.ShootEnt = "cb_signalflare_green"

ATT.Firemodes = {
    {
        Mode = 1,
        PrintName = "Signal"
    },
    {
        Mode = 1,
        PrintName = "Illumination",
        ShootEnt = "cb_illuminationflare_green",
        ShellModel = "models/weapons/comradebear/ww2/shells/36mm_illumination_shell.mdl"
    },
}

ATT.Category = {"cb_flare_types"}

ARC9.LoadAttachment(ATT, "cb_flare_green")

ATT = {}

ATT.PrintName = [[White Flares]]
ATT.CompactName = "WHITE"
ATT.Description = [[White Flares for flare guns, Used for signaling and illumination with a green hue]]
ATT.Icon = Material("entities/white_flare.png", "mips smooth")

ATT.SortOrder = 5

ATT.ShootEnt = "cb_signalflare_white"

ATT.Firemodes = {
    {
        Mode = 1,
        PrintName = "Signal"
    },
    {
        Mode = 1,
        PrintName = "Illumination",
        ShootEnt = "cb_illuminationflare_white",
        ShellModel = "models/weapons/comradebear/ww2/shells/36mm_illumination_shell.mdl"
    },
}

ATT.Category = {"cb_flare_types"}

ARC9.LoadAttachment(ATT, "cb_flare_white")

ATT = {}

ATT.PrintName = [[Yellow Flares]]
ATT.CompactName = "YELLOW"
ATT.Description = [[Yellow Flares for flare guns, Used for signaling and illumination with a green hue]]
ATT.Icon = Material("entities/yellow_flare.png", "mips smooth")

ATT.SortOrder = 3

ATT.ShootEnt = "cb_signalflare_yellow"

ATT.Firemodes = {
    {
        Mode = 1,
        PrintName = "Signal"
    },
    {
        Mode = 1,
        PrintName = "Illumination",
        ShootEnt = "cb_illuminationflare_yellow",
        ShellModel = "models/weapons/comradebear/ww2/shells/36mm_illumination_shell.mdl"
    },
}

ATT.Category = {"cb_flare_types"}

ARC9.LoadAttachment(ATT, "cb_flare_yellow")

ATT = {}

ATT.PrintName = [[Blue Flares]]
ATT.CompactName = "BLUE"
ATT.Description = [[Blue Flares for flare guns, Used for signaling and illumination with a green hue]]
ATT.Icon = Material("entities/blue_flare.png", "mips smooth")

ATT.SortOrder = 4

ATT.ShootEnt = "cb_signalflare_blue"

ATT.Firemodes = {
    {
        Mode = 1,
        PrintName = "Signal"
    },
    {
        Mode = 1,
        PrintName = "Illumination",
        ShootEnt = "cb_illuminationflare_blue",
        ShellModel = "models/weapons/comradebear/ww2/shells/36mm_illumination_shell.mdl"
    },
}

ATT.Category = {"cb_flare_types"}

ARC9.LoadAttachment(ATT, "cb_flare_blue")

ATT = {}

ATT.PrintName = [[Panzerwurfkorper 42]]
ATT.CompactName = "PANZERWURFKORPER"
ATT.Description = [[A relatively heavy HEAT warhead that inserts into the muzzle of a Flare gun, Specifically the Sturm Pistole variant Leuchtpistole 34.
This warhead is capable of penetrating a maximum of 80mm of RHA, and is effective at roughly 70 meters.]]
ATT.Icon = Material("entities/proj_panzerwurfkorper42.png", "mips smooth")

ATT.SortOrder = 4

ATT.Category = {"cb_sturmpistole_types"}

ARC9.LoadAttachment(ATT, "cb_warhead_panzerwurfkorper42")

ATT = {}

ATT.PrintName = [[Wurfkorper 361]]
ATT.CompactName = "WURFKORPER"
ATT.Description = [[An egg shaped fragmentation grenade, similar to that of a Eihandgranate 39, with a spigot and safety pin afixed to it. This
is designed to be inserted into a Flare gun, Specifically the Sturm Pistole variant Leuchtpistole 34. The grenade has a 4.5 second fuse, and can only reach
about 70 or so meters before exploding.]]
ATT.Icon = Material("entities/proj_wurfkorper361.png", "mips smooth")

ATT.SortOrder = 4

ATT.IronSights = {
    Pos = Vector(-3.44, -1.2, 1.5),
    Ang = Angle(0, 0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

ATT.ShootEnt = "cb_wurfkorper361"

ATT.Category = {"cb_sturmpistole_types"}

ARC9.LoadAttachment(ATT, "cb_warhead_wurfkorper361")


ATT = {}

ATT.PrintName = [[Wurfkorper 358 FRAG]]
ATT.CompactName = "WURFKORPER 358 FRAG"
ATT.Description = [[An cylindrical shaped fragmentation grenade, similar to that of a Model 24 Stielhandgranate, with a spigot and safety pin afixed to it. This
is designed to be inserted into a Flare gun, Specifically the Sturm Pistole variant Leuchtpistole 34. The grenade has a 4.5 second fuse, and can only reach
about 50 or so meters before exploding.

Both the Wurfkorper 358 and Nebelwurfkorper 358 never really saw widespread use, as the design of the M24 and M39 warheads were far too heavy,
and most likely generated too much drag with their flat top design, making the warheads not nearly as effective as the later model of Wurfkorper 361.]]
ATT.Icon = Material("entities/proj_wurfkorper358.png", "mips smooth")

ATT.SortOrder = 4

ATT.IronSights = {
    Pos = Vector(-3.44, -1.2, 1.5),
    Ang = Angle(0, 0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

ATT.ShootEnt = "cb_wurfkorper358_frag"
ATT.ShootEntForce = 1500

ATT.Category = {"cb_sturmpistole_types"}

ARC9.LoadAttachment(ATT, "cb_warhead_wurfkorper358_frag")

ATT = {}

ATT.PrintName = [[Nebelwurfkorper 358]]
ATT.CompactName = "NEBELWURFKORPER 358"
ATT.Description = [[An cylindrical shaped smoke grenade, similar to that of a Model 39 Nebelhandgranate, Similar to that of the Wurfkorper 358.
The smoke grenade has a short delay before it emits smoke, and can only reach about 50 or so meters.

Both the Wurfkorper 358 and Nebelwurfkorper 358 never really saw widespread use, as the design of the M24 and M39 warheads were far too heavy,
and most likely generated too much drag with their flat top design, making the warheads not nearly as effective as the later model of Wurfkorper 361.]]
ATT.Icon = Material("entities/proj_nebelwurfkorper358.png", "mips smooth")

ATT.SortOrder = 4

ATT.IronSights = {
    Pos = Vector(-3.44, -1.2, 1.5),
    Ang = Angle(0, 0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

ATT.ShootEnt = "cb_wurfkorper358_smoke"
ATT.ShootEntForce = 1500

ATT.Category = {"cb_sturmpistole_types"}

ARC9.LoadAttachment(ATT, "cb_warhead_wurfkorper358_smoke")

ATT = {}

ATT.PrintName = [[Wurfgranate Patrone 326]]
ATT.CompactName = "WURFGRANATE"
ATT.Description = [[A fin stablized impact fragmentation grenade, The grenade is designed to be inserted through the usual use of the chamber, Like a normal flare round.
This also means the grenade is not as effective as the Wurfkorper 361, As it has a much smaller explosive yield and shorter blast radius. However, The Wurfgranate's advantage is being able to be lobbed well over 100 meters to kill targets.]]
ATT.Icon = Material("entities/proj_wurfgranate326.png", "mips smooth")

ATT.SortOrder = 4

ATT.IronSights = {
    Pos = Vector(-3.44, -1.2, 1.5),
    Ang = Angle(0, 0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

ATT.ShootEnt = "cb_wurfgranate326"
ATT.ShootEntForce = 4500

ATT.Category = {"cb_sturmpistole_types"}

ARC9.LoadAttachment(ATT, "cb_warhead_wurfgranate326")