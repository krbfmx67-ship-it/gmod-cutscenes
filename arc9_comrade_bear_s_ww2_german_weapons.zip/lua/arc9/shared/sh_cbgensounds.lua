CB = {}

CB.Foley = {
    "comradebear/wpn/generic/foley/foley_1.wav",
    "comradebear/wpn/generic/foley/foley_2.wav",
    "comradebear/wpn/generic/foley/foley_3.wav",
    "comradebear/wpn/generic/foley/foley_4.wav",
    "comradebear/wpn/generic/foley/foley_5.wav"
}

CB.PistolHolster = {
    "comradebear/wpn/generic/foley/pistol_holster_01.wav",
    "comradebear/wpn/generic/foley/pistol_holster_02.wav",
    "comradebear/wpn/generic/foley/pistol_holster_03.wav"
}

CB.PistolDraw = {
    "comradebear/wpn/generic/foley/pistol_draw_01.wav",
    "comradebear/wpn/generic/foley/pistol_draw_02.wav",
    "comradebear/wpn/generic/foley/pistol_draw_03.wav"
}

CB.MGDeploy = {
    "comradebear/wpn/generic/foley/mg_bipod_01.wav",
    "comradebear/wpn/generic/foley/mg_bipod_02.wav",
    "comradebear/wpn/generic/foley/mg_bipod_03.wav"
}

CB.LMGZoomIn = {
    "comradebear/wpn/generic/foley/lmg_zoomin.wav",
}
CB.LMGZoomOut = {
    "comradebear/wpn/generic/foley/lmg_zoomout.wav",
}

CB.MMGZoomIn = {
    "comradebear/wpn/generic/foley/mmg_zoomin.wav",
}
CB.MMGZoomOut = {
    "comradebear/wpn/generic/foley/mmg_zoomout.wav",
}

CB.PistolZoomIn = {
    "comradebear/wpn/generic/foley/pistol_zoomin.wav",
}
CB.PistolZoomOut = {
    "comradebear/wpn/generic/foley/pistol_zoomout.wav",
}

CB.SMGZoomIn = {
    "comradebear/wpn/generic/foley/smg_zoomin.wav",
}
CB.SMGZoomOut = {
    "comradebear/wpn/generic/foley/smg_zoomout.wav",
}

CB.RifleZoomIn = {
    "comradebear/wpn/generic/foley/rifle_zoomin.wav",
}
CB.RifleZoomOut = {
    "comradebear/wpn/generic/foley/rifle_zoomout.wav",
}

CB.BipodPickup01 = {
    "comradebear/wpn/gen_bipod_pickup_01.wav"
}

CB.BipodGrab01 = {
    "comradebear/wpn/gen_bipod_grip_01.wav"
}

CB.BipodGrab02 = {
    "comradebear/wpn/gen_bipod_grip_02.wav"
}

CB.BipodDrop01 = {
    "comradebear/wpn/gen_bipod_collide_01.wav"
}

CB.BipodDrop02 = {
    "comradebear/wpn/gen_bipod_collide_02.wav"
}

CB.BipodShift01 = {
    "comradebear/wpn/gen_bipod_shift_01.wav"
}

CB.BipodShift02 = {
    "comradebear/wpn/gen_bipod_shift_02.wav"
}