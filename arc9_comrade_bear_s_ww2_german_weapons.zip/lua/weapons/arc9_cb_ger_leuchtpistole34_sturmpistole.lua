AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Utilities"

SWEP.PrintName = "Leuchtpistole 34 'Sturm Pistole'"

SWEP.Class = "Flare Pistol"

SWEP.Trivia = {
    Manufacturer = "Walther",
    Calibre = "26.6MM",
    Mechanism = "Break open, single action",
    Origin = "Germany",
    Year = "1934"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[A modified version of the Leuchtpistole 34 flare pistol, This converted flare gun includes a special rifled barrel insert,
Collapsable stock, and barrel shroud with iron sights to adjust for projectile drop.

Although this flare gun is functionally identical to the Leuchtpistole 34, It would in reality be allowed to use the Flare cartridges given the
rifled insert is removed first. However, I am LAZY and do not want to have to make the animations and code work for that. So the Sturmpistole
will only function as a weapon, rather than a utility like the Leuchtpistole 34.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_leuchtpistole_34_sturmpistole.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 75

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-14, 3.5, -4),
    TPIKPos = Vector(-9, 4, -4),
    TPIKAng = Angle(-10, -5, -180),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(10, -4, 0),
    Scale = 1,

    TPIKPosSightOffset = Vector(2, 3, -2), -- ironsights offset, disable NoTPIKVMPos
}
SWEP.NoTPIKVMPos = true
SWEP.TPIKnolefthand = false

SWEP.DefaultSkin = 1

-------------------------- TRACERS

SWEP.NeverPhysBullet = false

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(113, 207, 128) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 25 -- Damage done at point blank range
SWEP.DamageMin = 15 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 3700

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 3.5,
    [HITGROUP_CHEST] = 1.55,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1150 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 50

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "Grenade"
    },
}

SWEP.ShotgunReload = false
SWEP.HybridReload = false
SWEP.FiremodeAnimLock = true

-------------------------- RECOIL

SWEP.Recoil = 6

SWEP.RecoilUp = 4 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.7
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 2 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.05 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 15 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2.5, 20, 5) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 5
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 2.2
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 70 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 4
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.25
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.28 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.28 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/sturmpistole/sturmpistole_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/generic/flaregun/flaregun_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/p08/handling/p08_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.PistolZoomIn
SWEP.ExitSightsSound = CB.PistolZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol_red" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.BulletBones = {
    [0] = {"gren_proj", "bullet"},
    [1] = {"gren_proj", "bullet"},
}

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/36mm_signal_shell.mdl"
SWEP.ShellScale = 1.3
SWEP.NoShellEject = true
SWEP.ShellVelocity = 0.4
SWEP.ShellCorrectAng = Angle(0, 0, 90)

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "cb_signalflare_red" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 3500
SWEP.ShootEntInheritPlayerVelocity = false -- Set to true to inherit velocity
SWEP.ShootEntInheritPlayerVelocityLimit = 0 -- Upper limit of velocity to inherit. 0 - no limit.
SWEP.ShootEntData = {} -- Extra data that can be given to a projectile. Sets ENT.ShootEntData with this table.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-3.44, -1.2, 1.5),
    Ang = Angle(0, -4, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 1)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(4, -2, -20)
SWEP.RestAng = Angle(7, 60, -2)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(13, 30, 5)

SWEP.CustomizeRotateAnchor = Vector(13, -3, -5)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "normal"
SWEP.HoldTypeSights = "rpg"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/p08/handling/p08_"
local handling = "comradebear/wpn/generic/flaregun/handling/"
local handling2 = "comradebear/wpn/ger/sturmpistole/handling/"
local gen_exp = "comradebear/wpn/generic/explosives/"

local cocking = {
    handling2 .. "reload_cocking_1.wav",
    handling2 .. "reload_cocking_2.wav",
    handling2 .. "reload_cocking_3.wav",
}

local gren_insert = {
    handling2 .. "reload_insert_1.wav",
    handling2 .. "reload_insert_2.wav",
    handling2 .. "reload_insert_3.wav",
}

local gren_pin_pull = {
    gen_exp .. "mk2_pullpin_01.wav",
    gen_exp .. "mk2_pullpin_02.wav",
    gen_exp .. "mk2_pullpin_03.wav",
    gen_exp .. "mk2_pullpin_04.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_iron"] = { Source = "iron_idle" },
    ["idle_iron_emtpty"] = { Source = "iron_empty" },
    ["fire"] = { Source = {
        "base_shoot",
    } },
    ["fire_empty"] = { Source = "base_shoot" },
    ["fire_iron"] = { Source = {
        "base_shoot",
    } },
    ["enter_sights"] = { Source = "iron_idle" },
    ["enter_sights_empty"] = { Source = "iron_empty" },
    ["fire_iron_empty"] = { Source = "base_shoot" },
    ["dryfire"] = { Source = "empty_idle" },
    ["dryfire_iron"] = { Source = "empty_idle" },
    ["bash"] = { Source = "base_melee_bash" },
    ["bash_empty"] = { Source = "empty_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.9,  EventTable = {
        {s = handling .. "magout.wav",        t = 20 / 30, c = ci},
        {s = handling .. "magin.wav",        t = 65 / 30, c = ci},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.75, MagSwapTime = 0.5, Mult = 1.1, EventTable = {
        {s = handling2 .. "reload_gren_foley.wav",        t = 10 / 30, c = ci},
        --{s = handling .. "foley_throw.wav",        t = 35 / 30, c = ci},
        
        {s = gren_insert,        t = 38 / 30, c = ci},
        {s = cocking,        t = 60 / 30, c = ci},
    } },
    ["reload_empty_frag"] = { Source = "base_reloadempty_frag", MinProgress = 0.75, MagSwapTime = .4, Mult = 1.1, EventTable = {
        {s = handling2 .. "reload_gren_foley.wav",        t = 10 / 30, c = ci},
        {s = gren_pin_pull,        t = 35 / 30, c = ci},
        {s = gren_insert,        t = 60 / 30, c = ci},
        {s = cocking,        t = 90 / 30, c = ci},
    } },
    ["reload_empty_wurfgranate"] = { Source = "base_reloadempty_wurfgranate", EjectAt = 1.4, MinProgress = 0.75, MagSwapTime = 2, Mult = 0.9, EventTable = {
        {s = handling .. "lp34_barrelopen.wav",        t = 20 / 30, c = ci},
        --{s = handling .. "foley_throw.wav",        t = 35 / 30, c = ci},
        {s = handling .. "lp34_ejectshell.wav",        t = 40 / 30, c = ci},
        {s = handling .. "lp34_insertshell.wav",        t = 85 / 30, c = ci},
        {s = handling .. "lp34_barrelclose.wav",        t = 115 / 30, c = ci},
        {s = cocking,        t = 135 / 30, c = ci},
    } },
    ["draw"] = { Source = "base_draw",  Mult = 0.9, EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 30, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster"] = { Source = "base_holster",  Mult = 0.8, EventTable = {
        {s = handling .. "decock.wav",        t = 10 / 30, c = ci},
        {t = 5 / 30, s = CB.PistolHolster},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", Mult = 0.9, EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", Mult = 0.8, EventTable = {
        {t = 0 / 30, s = CB.PistolHolster},
    } },
    ["inspect"] = { Source = "base_inspect" },
    ["inspect_empty"] = { Source = "base_inspect_empty" },
    ["firemode_1"] = { Source = "base_switch_ammo", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.8, EventTable = {
        {s = handling .. "lp34_barrelopen.wav",        t = 20 / 30, c = ci},
        --{s = handling .. "foley_throw.wav",        t = 35 / 30, c = ci},
        {s = handling .. "lp34_removeshell.wav",        t = 50 / 30, c = ci},
        {s = handling .. "lp34_insertshell.wav",        t = 100 / 30, c = ci},
        {s = handling .. "lp34_barrelclose.wav",        t = 130 / 30, c = ci},
    } },
    ["firemode_2"] = { Source = "base_switch_ammo_signal", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.8, EventTable = {
        {s = handling .. "lp34_barrelopen.wav",        t = 20 / 30, c = ci},
        --{s = handling .. "foley_throw.wav",        t = 35 / 30, c = ci},
        {s = handling .. "lp34_removeshell.wav",        t = 50 / 30, c = ci},
        {s = handling .. "lp34_insertshell.wav",        t = 100 / 30, c = ci},
        {s = handling .. "lp34_barrelclose.wav",        t = 130 / 30, c = ci},
    } },
}

SWEP.InstantSprintIdle = true

SWEP.DefaultBodygroups = "00000000"

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/c96/weapon_c96_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["cb_flare_red"] = {
        Skin = 0
    },
    ["cb_flare_green"] = {
        Skin = 1
    },
    ["cb_flare_yellow"] = {
        Skin = 2
    },
    ["cb_flare_blue"] = {
        Skin = 3
    },
    ["cb_flare_white"] = {
        Skin = 4
    },
    ["cb_warhead_wurfkorper361"] = {
        Hook_TranslateAnimation = function(self, anim)
            if anim == "reload_empty" then
                local firemode = self:GetFiremode()
                return "reload_empty_frag"
            end
        end,
        Bodygroups = {
            {1, 1}
        }
    },
    ["cb_warhead_wurfkorper358_frag"] = {
        Hook_TranslateAnimation = function(self, anim)
            if anim == "reload_empty" then
                local firemode = self:GetFiremode()
                return "reload_empty_frag"
            end
        end,
        Bodygroups = {
            {1, 3}
        }
    },

    ["cb_warhead_wurfkorper358_smoke"] = {
        Hook_TranslateAnimation = function(self, anim)
            if anim == "reload_empty" then
                local firemode = self:GetFiremode()
                return "reload_empty_frag"
            end
        end,
        Bodygroups = {
            {1, 4}
        }
    },

    ["cb_warhead_wurfgranate326"] = {
        Hook_TranslateAnimation = function(self, anim)
            if anim == "reload_empty" then
                local firemode = self:GetFiremode()
                return "reload_empty_wurfgranate"
            end
        end,
        Bodygroups = {
            {1, 2}
        }
    }
}

SWEP.Attachments = {
    {
        PrintName = "WARHEAD TYPE",
        Category = "cb_sturmpistole_types",
        Installed = "cb_warhead_panzerwurfkorper42",
        Integral = true,
        Bone = "wpn_body",
        Pos = Vector(5, 0, 3.3),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(0, 0, 0),
    },
}

--[[SWEP.Hook_TranslateAnimation = function(self, anim)
    -- We're only customizing the 'cycle' animation
    if anim == "firemode" then
        local firemode = self:GetFiremode()
        return "firemode_" .. firemode
    end

    if anim == "reload" then
        local firemode = self:GetFiremode()
        return "reload_empty_" .. firemode
    end

    -- Default behavior for other animations
    return anim
end]]

--[[function SWEP:IsPlayingFiremodeAnim()
    local owner = self:GetOwner()
    if not IsValid(owner) then return false end

    local vm = owner:GetViewModel()
    if not IsValid(vm) then return false end

    local seq = vm:GetSequence()
    local seqName = vm:GetSequenceName(seq)
    if not seqName then return false end

    -- Match your firemode animation names
    return string.find(seqName, "base_switch_ammo_signal") 
        or string.find(seqName, "base_switch_ammo")
end]]

function SWEP:DoProjectileAttack(pos, ang, spread)
    if SERVER then

        if self:GetElements()["cb_warhead_wurfkorper361"] or self:GetElements()["cb_warhead_wurfgranate326"] or self:GetElements()["cb_warhead_wurfkorper358_frag"] or self:GetElements()["cb_warhead_wurfkorper358_smoke"] then

            self:ShootRocket()

        else

        local owner = self:GetOwner()

        --local localOffset = Vector(50, -4, -5)
        local localOffset = Vector(40, -0, -3)

        local src = LocalToWorld(localOffset, Angle(0,0,0), pos, ang)

        local bullet = {}
        bullet.Src = src
        bullet.Dir = owner:EyeAngles():Forward()
        bullet.Spread = Vector(0, 0, 0)
		bullet.Force	= 80 * 102
		bullet.HullSize 	= 5
		bullet.Damage	= 700
		bullet.SplashDamage = 200
		bullet.SplashDamageRadius = 150
		bullet.SplashDamageEffect = "lvs_bullet_impact_panzerwurfkorper42"
		bullet.SplashDamageType = DMG_BLAST
		bullet.Velocity = 40 / 0.01905
		bullet.TracerName = "lvs_tracer_panzerwurfkorper42"
        bullet.Attacker = owner
        bullet.EnableBallistics = true
        bullet.Entity = owner

        --debugoverlay.Cross(src, 100, 10, Color(255, 0, 0), true)

        LVS:FireBullet(bullet)
        end
    end
end

--[[SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end

    local firemode = self:GetFiremode()

    --print(firemode)
    local vm = owner:GetViewModel(0)

    if firemode == 1 then
        timer.Simple(2, function()
            vm:SetBodygroup(1, 0) 
        end)
    else
        timer.Simple(2, function()
            vm:SetBodygroup(1, 1) 
        end)
    end
    -- Check if the weapon is reloading
    if self:GetReloading() or self:IsPlayingFiremodeAnim() then
        -- If HoldType isn't already changed, set it to the desired reload type
        if not self.ReloadingHoldTypeSet then
            self.OriginalHoldType = self.OriginalHoldType or self.HoldType
            self:SetHoldType("revolver") -- Replace with the desired reload hold type
            self.ReloadingHoldTypeSet = true
            self.TPIKnolefthand = false
        end
    else
        -- If reloading is finished, reset HoldType to the original
        if self.ReloadingHoldTypeSet then
            self:SetHoldType(self.OriginalHoldType)
            self.ReloadingHoldTypeSet = false
        end
    end
end]]