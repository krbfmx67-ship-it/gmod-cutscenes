AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Rifles"

SWEP.PrintName = "StG-44"

SWEP.Class = "Assault Rifle"

SWEP.Trivia = {
    Manufacturer = "C.G. Haenel Waffen und Fahrradfabrik",
    Calibre = "7.92x33mm Kurz",
    Mechanism = "Gas-Operated Long-Stroke Piston, Closed Tilting Bolt",
    Origin = "Germany",
    Year = "1944"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Sturmgewehr-44 or StG-44 for short, Is a closed bolt select fire early assualt rifle.
Though it is typically believed to be the first assault rifle, StG-44 has been a tested design throughout the war, starting as far back
as 1942 with the introduction of the MKb-42(H), Further evolving into the MP-43/I. Though many of these examples are similar, They are
not the final iteration that would become the StG-44.
Later on, They would introduce a rail system for StG-44's that allowed for the installation of the ZF-4 Marksman scope, and experimentally.
The ZG-1229 Vampir Infrared Night Scope.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_stg44.mdl"
SWEP.WorldModel = "models/weapons/w_rif_ak47.mdl"

SWEP.ViewModelFOVBase = 70

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-9, 3.5, -7),
    TPIKPos = Vector(-7, 4, -6),
    Ang = Angle(-10, 0, 170),
    Scale = 1,
    TPIKPosSightOffset = Vector(-1, 2, -1),
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "0000000000000000000000"
SWEP.DefaultSkin = 0

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 45 -- Damage done at point blank range
SWEP.DamageMin = 25 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 7000

SWEP.ImpactForce = 6 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 11 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- TRACERS

SWEP.NeverPhysBullet = false

SWEP.TracerNum = 5 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(113, 207, 128) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2250 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "smg1" -- What ammo type this gun uses.

SWEP.ChamberSize = 1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 30 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.SprintCancelsReload = true
SWEP.BashCancelsReload = true

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 525

SWEP.Firemodes = {
    {
        Mode = -1,
    },
    {
        Mode = 1,
    }
}

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 0.3 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.1 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilPatternDrift = 15

SWEP.RecoilAutoControl = 2

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.1 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 12 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 4, -2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 3 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

--SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 2
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 150 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.35 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.35 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.96

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 90
SWEP.ShootPitchVariation = 0.05

local handling = "/comradebear/wpn/ger/mp43/handling/"

SWEP.ShootSound = "comradebear/wpn/ger/mp43/stg44_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/mp43/mp43_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_dist.wav"

SWEP.DryFireSound = "comradebear/wpn/generic/trigger_empty_01.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_1" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x33kurz.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 4
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
     Pos = Vector(-2.26, -0, 1),
     Ang = Angle(0, 0, 0),
     Magnification = 1,
     SwitchToSound = "",
     ViewModelFOV = 35,
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(1, 0, -0.5)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(10, 0, -5)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(14.5, 30, 6)
SWEP.CustomizeRotateAnchor = Vector(15, -2, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "smg"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.Animations = {
    ["idle"] = {
        Source = "base_idle",
    },
    ["idle_empty"] = {
        Source = "base_idle_empty",
    },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["fire"] = {
        Source = "base_shoot",
        Time = 20 / 30,
        ShellEjectAt = 0.03,
        SoundTable = {{s = handling .. "mp43_bolt_forward.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_iron"] = {
        Source = "base_iron_shoot",
        Time = 20 / 30,
        ShellEjectAt = 0.03,
        SoundTable = {{s = handling .. "mp43_bolt_forward.wav",        t = 0 / 37, c = ci}},
    },
    ["fire_iron_empty"] = {
        Source = "base_iron_shoot_last",
        Time = 20 / 30,
        ShellEjectAt = 0.03,
        SoundTable = {{s = handling .. "mp43_bolt_forward.wav",        t = 4 / 37, c = ci}},
    },
    ["fire_empty"] = {
        Source = "base_shoot_last",
        Time = 20 / 30,
        ShellEjectAt = 0.03,
        SoundTable = {{s = handling .. "mp43_bolt_forward.wav",        t = 4 / 37, v = 0.25, c = ci}},
    },
	
    ["trigger_empty"] = {
        Source = "idle",
        Time = 0,
        SoundTable = nil,
    },
    ["bash"] = { Source = "base_stab" },
    ["bash_empty"] = { Source = "base_stab" },
    ["reload"] = {
        Source = "base_reload",
        TPAnim = ACT_HL2MP_GESTURE_RELOAD_SMG1,
        Time = 110 / 35,
        MinProgress = 0.8,
        LastClip1OutTime = 67 / 30,
        IKTimeLine = {
            {
                t = 0,
                lhik = 1,
                rhik = 0
            },
            {
                t = 0.45,
                lhik = 0,
                rhik = 0
            },
            {
                t = 0.7,
                lhik = 0,
                rhik = 0
            },
            {
                t = 0.9,
                lhik = 1,
                rhik = 1
            },
        },
        SoundTable = {
            {s = handling .. "mp43_magrelease.wav",        t = 30 / 34, c = ci},
            {s = handling .. "mp43_magout.wav",        t = 35 / 34, c = ci},
            {s = handling .. "mp43_magin.wav",         t = 67 / 34, c = ci},
        },
    },
    ["reload_empty"] = {
        Source = "base_reloadempty",
        TPAnim = ACT_HL2MP_GESTURE_RELOAD_SMG1,
        Time = 140 / 35,
        MinProgress = 0.8,
        LastClip1OutTime = 1.8,
        IKTimeLine = {
            {
                t = 0,
                lhik = 1,
                rhik = 0
            },
            {
                t = 0.35,
                lhik = 0,
                rhik = 0
            },
            {
                t = 0.8,
                lhik = 0,
                rhik = 0
            },
            {
                t = 0.9,
                lhik = 1,
                rhik = 1
            },
        },
		Checkpoints = { 35 / 35},
        SoundTable = {
            {s = handling .. "mp43_magrelease.wav",        t = 22 / 30, c = ci},
            {s = handling .. "mp43_magout.wav",        t = 25 / 30, c = ci},
            {s = handling .. "mp43_magin.wav",         t = 60 / 30, c = ci},
			{s = handling .. "mp43_bolt_back.wav",         t = 83 / 30, c = ci},
			{s = handling .. "mp43_bolt_forward.wav",         t = 92 / 30, c = ci},
        },
    },
    ["firemode"] = { Source = "base_firemode" },
    ["firemode_iron"] = { Source = "base_firemode" },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/stg44/weapon_stg_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {1, 1}
        }
    },
    ["cb_stg_rail"] = {
        Bodygroups = {
            {1, 1}
        }
    },
}

SWEP.Attachments = {
   --[[] {
        PrintName = "OPTIC",
        Category = "optic_zf4_rail",
        Bone = "wpn_body",
        Pos = Vector(0.0, 0.5, 3.6),
        Ang = Angle(0, -0, 0),
        RequireElements = {"cb_stg_rail"},
        CorrectiveAng = Angle(0, 90, 0),
        CorrectivePos = Vector(-0,0,0),
    },
]]
    {
        PrintName = "GRIP",
        Category = "cb_stg_maggrip",
        Bone = "wpn_body",
        Pos = Vector(-0.3, 6, 0),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(0, 0, 0),
    },

    --[[{
        PrintName = "RAIL",
        Category = "cb_stg_rail",
        Bone = "wpn_body",
        Pos = Vector(0, -0, 4),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(0, 0, 0),
    },]]
}
