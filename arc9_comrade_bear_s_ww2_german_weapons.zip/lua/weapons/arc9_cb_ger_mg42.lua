AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Machine Guns"

SWEP.PrintName = "MG 42[Placeholder]"

SWEP.Class = "Machine Gun"

SWEP.Trivia = {
    Manufacturer = "Rheinmetall",
    Calibre = "7.92x57mm Mauser",
    Mechanism = "Recoil-Operated Roller-Locked",
    Origin = "Nazi Germany",
    Year = "1942"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "New World Interactive",
}

SWEP.Description = [[The MG-42 is a belt feld Open bolt General purpose machine gun, Its most notible features is its extremely high
rate of fire of 1200 rounds per minute, as well as its easy to access and change on the fly barrel changing design. Allowing the weapon
to put down a vast amount of ammunition down onto a target while also allowing the crew to quickly change its heating barrels.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_mg42.mdl"
SWEP.WorldModel = "models/weapons/w_mach_m249para.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-7, 4, -7),
    TPIKPos = Vector(-7, 4, -7),
    TPIKAng = Angle(-15, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultSkin = 0
SWEP.DefaultBodygroups = "00000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 60 -- Damage done at point blank range
SWEP.DamageMin = 40 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 9500

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 17 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2428 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

    --Green - GER/USSR BZT
SWEP.TracerNum = 2 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(129, 201, 115) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1


-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 100 -- Self-explanatory.
SWEP.SupplyLimit = 1 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = false

SWEP.SprintCancelsReload = true
SWEP.BashCancelsReload = true

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 1200

SWEP.Firemodes = {
    {
        Mode = -1,
    },
}

SWEP.TriggerDelay = false
SWEP.TriggerDelayTime = 0.1
SWEP.TriggerDelayCancellable = true
SWEP.TriggerDelayRepeat = false
SWEP.TriggerStartFireAnim = false

-------------------------- RECOIL

SWEP.Recoil = 2

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 1 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.75
SWEP.RecoilRandomSide = 0.75

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 180
-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.05 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(-2, 20, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.2

SWEP.VisualRecoilMult = 1
SWEP.VisualRecoilADSMult = 0.5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.1
SWEP.VisualRecoilPositionBump = 1.2
SWEP.VisualRecoilPositionBumpUp = 0.6 -- its a mult


SWEP.VisualRecoilDampingConst = 200 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 1
SWEP.VisualRecoilSpringPunchDamping = 4 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0.01 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 15
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 3.5
SWEP.SwayMultSights = 1.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.55 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.55 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.88

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.IndoorShootVolume = 95
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.1

SWEP.ShootSound = "comradebear/wpn/ger/mg42/mg42_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/mg42/mg42_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "comradebear/wpn/generic/trigger_empty_01.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.MMGZoomin
SWEP.ExitSightsSound = CB.MMGZoomout

ARC9.HookP_TranslateSound = function(self, data)
    if data.name == "shoot" then
        data.channel = CHAN_STATIC
    end
    return data
end

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_minimi" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x57.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellCorrectAng = Angle(90, 0, 0)

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 3 -- QC Attachment for shell ejection.
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-3.06, -5, 1.2),
    Ang = Angle(0, 0.1, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(-1, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 10)
SWEP.CustomizePos = Vector(21, 36, 4)
SWEP.CustomizeRotateAnchor = Vector(14, -3, -2)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

--[[SWEP.BulletBones = {
    [0] = "MG42_BELT_MASTER",
    [1]  = "MG42_ROUND_01",
    [2]  = "MG42_ROUND_02",
    [3]  = "MG42_ROUND_03",
    [4]  = "MG42_ROUND_04",
    [5]  = "MG42_ROUND_05",
    [6]  = "MG42_ROUND_06",
    [7]  = "MG42_ROUND_07",
    [8]  = "MG42_ROUND_08",
    [9]  = "MG42_ROUND_09",
    [10] = "MG42_ROUND_10",
    [11] = "MG42_ROUND_11",
    [12] = "MG42_ROUND_12",
    [13] = "MG42_ROUND_13",
    [14] = "MG42_ROUND_14",
    [15] = "MG42_ROUND_15",
    [16] = "MG42_ROUND_16",
    [17] = "MG42_ROUND_17",
    [18] = "MG42_ROUND_18",
}]]

SWEP.HideBones = {"MG42_MENUROUNDS"}

-------------------------- Bipod

SWEP.Bipod = false
SWEP.RecoilUpMultBipod = 0.75
SWEP.SwayMultBipod = 0.1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "passive"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/mg42/handling/mg42_"
local path2 = "comradebear/wpn/ger/mg42/handling/mg42_"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle", RareSource = "base_idle_fidget", Time = 1.9 },
    ["idle_iron"] = { Source = "base_idle" },
    ["fire"] = { Source = {
        "base_fire_1",
        "base_fire_2"
    } },
    ["fire_iron"] = { Source = {
        "iron_fire_1",
        "iron_fire_2"
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["trigger"] = { Source = "base_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron"] = { Source = "iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["bash"] = { Source = "base_melee_bash" },
    ["firemode"] = { Source = "base_fireselect" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.4, MagSwapTime = 1.6, EventTable = {
        {t = 18 / 32.5, s = path .. "foley.wav"},
        {t = 20 / 32.5, s = path2 .. "lidopen.wav"},
        {t = 60 / 32.5, s = path2 .. "beltout.wav"},
        {t = 81 / 32.5, s = path .. "fetchmag.wav"},
        {t = 110 / 32.5, s = path2 .. "beltshift.wav"},
        {t = 125 / 32.5, s = path2 .. "beltin.wav"},
        {t = 190 / 32.5, s = path2 .. "lidclose.wav"},
        {t = 238 / 32.5, s = path .. "rattle.wav"},
        {t = 264 / 32.5, s = path .. "shoulder_weapon.wav"},
    } },
    ["reload_empty"] = { Source = "base_reload_empty", MinProgress = 0.5, MagSwapTime = 1.6, EventTable = {
        {t = 1 / 32.5, s = path .. "foley.wav"},
        {t = 33 / 32.5, s = path2 .. "boltback.wav"},
        {t = 43 / 32.5, s = path2 .. "boltrelease.wav"},
        {t = 67 / 32.5, s = path .. "rattle.wav"},
        {t = 95 / 32.5, s = path2 .. "lidopen.wav"},
        {t = 100 / 32.5, s = path .. "fetchmag.wav"},
        {t = 140 / 32.5, s = path2 .. "beltshift.wav"},
        {t = 155 / 32.5, s = path2 .. "beltin.wav"},
        {t = 220 / 32.5, s = path2 .. "lidclose.wav"},
        {t = 264 / 32.5, s = path .. "rattle.wav"},
        {t = 284 / 32.5, s = path .. "shoulder_weapon.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 25 / 30, s = path2 .. "boltback.wav"},
        {t = 40 / 30, s = path2 .. "boltrelease.wav"},
        {t = 41 / 30, s = CB.Foley},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["enter_bipod"] = { Source = "deployed_in", EventTable = {
        {t = 19 / 36, s = CB.MGDeploy},
    } },
    ["exit_bipod"] = { Source = "deployed_out", EventTable = {
        {t = 25 / 36, s = CB.Deploy},
    } },
    ["idle_bipod"] = { Source = "deployed_idle" },
    ["idle_iron_bipod"] = { Source = "deployed_iron_idle" },
    ["fire_bipod"] = { Source = {
        "deployed_fire_1",
        "deployed_fire_2"
    } },
    ["fire_iron_bipod"] = { Source = {
        "deployed_iron_fire_1",
        "deployed_iron_fire_2"
    } },
    ["dryfire_bipod"] = { Source = "deployed_dryfire" },
    ["dryfire_iron_bipod"] = { Source = "deployed_iron_dryfire" },
    ["firemode_bipod"] = { Source = "deployed_fireselect" },
    ["trigger_bipod"] = { Source = "deployed_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron_bipod"] = { Source = "deployed_iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["reload_bipod"] = { Source = "deployed_reload", MinProgress = 0.4, MagSwapTime = 3.6, EventTable = {
        {t = 18 / 32.5, s = path .. "foley.wav"},
        {t = 22 / 32.5, s = path2 .. "lidopen.wav"},
        {t = 60 / 32.5, s = path2 .. "beltout.wav"},
        {t = 81 / 32.5, s = path .. "fetchmag.wav"},
        {t = 110 / 32.5, s = path2 .. "beltshift.wav"},
        {t = 125 / 32.5, s = path2 .. "beltin.wav"},
        {t = 190 / 32.5, s = path2 .. "lidclose.wav"},
        {t = 238 / 32.5, s = path .. "rattle.wav"},
        {t = 264 / 32.5, s = path .. "shoulder_weapon.wav"},
    } },
    ["reload_bipod_empty"] = { Source = "deployed_reload_empty", MinProgress = 0.5, MagSwapTime = 1, EventTable = {
        {t = 1 / 32.5, s = path .. "foley.wav"},
        {t = 33 / 32.5, s = path2 .. "boltback.wav"},
        {t = 43 / 32.5, s = path2 .. "boltrelease.wav"},
        {t = 67 / 32.5, s = path .. "rattle.wav"},
        {t = 95 / 32.5, s = path2 .. "lidopen.wav"},
        {t = 100 / 32.5, s = path2 .. "emptybeltout.wav"},
        {t = 130 / 32.5, s = path2 .. "beltshift.wav"},
        {t = 155 / 32.5, s = path2 .. "beltin.wav"},
        {t = 229 / 32.5, s = path2 .. "lidclose.wav"},
        {t = 264 / 32.5, s = path .. "rattle.wav"},
        {t = 284 / 32.5, s = path .. "shoulder_weapon.wav"},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/mg34/weapon_mg34_dm"
SWEP.CustomCamoScale = 4
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.DefaultElements = {"belt"}

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_mag"] = {
        ClipSize = 150
    },
    ["cb_dply_bipod"] = {
        Bodygroups = {
            {2, 1}
        }
    }
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    local clip = self:Clip1()
    mdl:SetBodygroup(3, math.Clamp(18 - clip, 0, 35))

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Overheat = true -- Weapon will jam when it overheats, playing the "overheat" animation.
SWEP.HeatPerShot = 1
SWEP.HeatCapacity = 250 -- rounds that can be fired non-stop before the gun jams, playing the "fix" animation
SWEP.HeatDissipation = 3 -- rounds' worth of heat lost per second
SWEP.HeatLockout = false -- overheating means you cannot fire until heat has been fully depleted
SWEP.HeatDelayTime = 0.5 -- Amount of time that passes before heat begins to dissipate.
SWEP.HeatFix = false -- when the "overheat" animation is played, all heat is restored.

SWEP.Attachments = {
    {
        PrintName = "BIPOD",
        Category = "cb_dply_bipod",
        Bone = "weapon",
        Pos = Vector(-0.3, 21, -2),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(0, 0, 0),
    },
}
--[[
SWEP.Hook_Think = function(self)
    -- Check if overheating is enabled
    if not self.Overheat then return end

    local heat = self:GetHeatAmount() -- Assuming this function retrieves heat level between 0 and 1
    if not heat then return end

    -- Debugging
    -- print("Heat level:", heat)

    -- Ensure the sound object exists
    if not self.HeatSound then
        self.HeatSound = CreateSound(self, "hts/easternfront/weapons/mg42/mg42_overheat_loop.wav")
    end

    if heat > 0 then
        -- Start the sound if it isn't already playing
        if not self.HeatSound:IsPlaying() then
            self.HeatSound:SetSoundLevel(0)
            self.HeatSound:Play()
        end

        -- Adjust the volume proportional to the heat level
        self.HeatSound:ChangeVolume(heat / 750, 0.6) -- Smooth volume adjustment over 0.1 seconds
    else
        -- Stop the sound if heat is 0 or less
        if self.HeatSound:IsPlaying() then
            self.HeatSound:Stop()
        end
    end
end

SWEP.Hook_Holster = function(self)
	self.HeatSound:Stop()
end

SWEP.OnRemove = function(self)
    -- Clean up the sound when the weapon is removed
    if self.HeatSound then
        self.HeatSound:Stop()
        self.HeatSound = nil
    end
end
]]

--[[SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local ammo = self:Clip1()
    local deployed = self:GetBipod()

    -- Start with default (should match bodygroup count)
    local bgstr = self.DefaultBodygroups or "000000"
    local chars = string.ToTable(bgstr)

    -- Function to convert number to base36 char
    local function ToBase36Char(num)
        if num <= 9 then return tostring(num) end
        return string.char(87 + num) -- 87 + 10 = 97 = 'a'
    end

    -- Update ammo count at index 3 (Lua index, not bodygroup index)
    local ammoBG = math.Clamp(18 - ammo, 0, 35)
    chars[4] = ToBase36Char(ammoBG)

    -- Rebuild the string
    self.DefaultBodygroups = table.concat(chars)
end]]

function SWEP:EnterSights()
    local deployed = self:GetBipod()

    --print(deployed)
    -- Pimp'n!
    if deployed == true then 
        if self:GetSprintAmount() > 0.5 then return end
        if !self:GetProcessedValue("HasSights", true) then return end
        if self:GetCustomize() then return end
        if !self:GetProcessedValue("ReloadInSights", true) and self:GetReloading() then return end
        if self:GetHolsterTime() > 0 then return end
        if self:GetProcessedValue("UBGLInsteadOfSights", true) then return end
        if self:GetSafe() then return end
        if self.SightsInterruptInspect and self:GetInspecting() then self:CancelInspect() end
        if self:GetAnimLockTime() > CurTime() and !self:GetReloading() then return end -- i hope this won't cause any issues later
        if self:GetValue("UBGL") and self:GetOwner():KeyDown(IN_USE) then return end
        if self:GetIsNearWall() and math.abs(self:GetOwner():GetNW2Float("leaning_fraction", 0)) < 0.1 then return end -- leaning mod support
        if self:HasAnimation("bash") and self.SetNextAiming then
            if self.SetNextAiming > CurTime() then return end
        end

        -- self:ToggleBlindFire(false)
        self:SetInSights(true)
        if IsFirstTimePredicted() then
            local soundtab1 = {
                name = "entersights",
                sound = self:RandomChoice(self:GetProcessedValue("EnterSightsSound", true)),
                channel = ARC9.CHAN_FIDDLE,
            }

            self:PlayTranslatedSound(soundtab1)
        end

        if !self:StillWaiting() or self.NoFireDuringSighting then
            if !(self.SightIsAlsoBipodAnims and self:GetBipod()) then
                if self:GetProcessedValue("InstantSightIdle", true) then
                    self:PlayAnimation("idle")
                else
                    local anim = self:TranslateAnimation("enter_sights")
                    local mult = self:GetProcessedValue("AimDownSightsTime") -- Incorrectly uses a time as a multiplier! Preserved for legacy behavior
                    if self:GetAnimationEntry(anim).NoStatAffectors then
                        mult = 1
                    end
                    self:PlayAnimation(anim, mult, self.NoFireDuringSighting, nil, nil, true)
                end
            end
        end

        self:SetShouldHoldType()
    else
        return false
    end
end