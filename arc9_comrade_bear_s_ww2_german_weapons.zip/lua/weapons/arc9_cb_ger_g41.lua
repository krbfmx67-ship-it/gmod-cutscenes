AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Rifles"

SWEP.PrintName = "Gewehr-41"

SWEP.Class = "Rifle"

SWEP.Trivia = {
    Manufacturer = "Walther",
    Calibre = "7.92x57MM",
    Mechanism = "Gas-Operated Short-Stroke Piston",
    Origin = "Nazi Germany",
    Year = "1941"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Walther G41 is among one of the first couple of prototypes for a self-loading rifle to be issued to troops for
Nazi Germany. The G41 was a direct response to the Soviet's Self loading rifles, The SVT-38 and SVT-40. which allowed infantry to provide
prolonged and fast fire, as compared to bolt action rifles, obviously coming at the cost of control and accuracy with quickly firing the weapon.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_gewehr41.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 70

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -6),
    TPIKPos = Vector(-8, 4, -6),
    TPIKAng = Angle(-10, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,

    TPIKPosSightOffset = Vector(1, 1.5, -1), -- ironsights offset, disable NoTPIKVMPos
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultSkin = 1

SWEP.DefaultBodygroups = "00"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 40 -- Damage done at point blank range
SWEP.DamageMin = 35 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 17000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 17 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2450 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 10 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

    --OffWhite - USSR T-30
SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(235, 222, 164) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.RPM = 175

SWEP.Firemodes = {
    {
        Mode = 1,
    }
}

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.7

SWEP.RecoilAutoControl = 2 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 0.1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.03 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 15 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2.5, 20, -5) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 2.2
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 70 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 4
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.2
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.36 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.36 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/g43/g41_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/g43/g41_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/g43/handling/g43_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_ar" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x57.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.405, -4, 1.75),
    Ang = Angle(0, 0.1, 0),
    Magnification = 1,
    ViewModelFOV = 35
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -2)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 0)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(22, 35, 4)
SWEP.CustomizeRotateAnchor = Vector(21.5, -3.165, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.ShotgunReload = true
SWEP.HybridReload = false

SWEP.HideBones = {"clip", "clip_bullet1", "clip_bullet2", "clip_bullet3", "clip_bullet4", "clip_bullet5", "bullet1"}

local path = "comradebear/wpn/ger/g43/handling/"
local handling = "/hts/easternfront/weapons/mosin/handling/"

local bulletin = {
    path .. "insert1.wav",
    path .. "insert2.wav",
    path .. "insert3.wav",
    path .. "insert4.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_iron"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_iron_empty"] = { Source = "base_idle_empty" },
    ["fire"] = { Source = {
        "base_shoot"
    }, 
    EventTable = {
        {t = 0 / 32, s = path .. "boltrelease.wav", v = 0.25},
    } },
    ["fire_iron"] = { Source = {
        "base_shoot_iron"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "boltrelease.wav", v = 0.5},
    }  },
    ["fire_empty"] = { Source = {
        "base_shoot_last"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "boltrelease.wav", v = 0.5},
    } },
    ["fire_iron_empty"] = { Source = {
        "base_shoot_last_iron"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "boltrelease.wav", v = 0.75},
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_stab", Mult = 0.85 },
    ["bash_empty"] = { Source = "base_stab_empty", Mult = 0.85 },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = -1, MinProgress = 0.45, Mult = 1, EventTable = {
            {s = path .. "boltback.wav",        t = 12 / 30, c = ci},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", RestoreAmmo = 0, Mult = 1, EventTable = {
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
        {t = 20/35, s = bulletin},
    } },
    ["reload_insert_5"] = { Source = "base_reload_insert_5", Mult = 0.8, MinProgress = 0.65, MagSwapTime = 0.5, EventTable = {
        {s = path .. "stripperclip_insert.wav",        t = 14 / 30, c = ci},
        {s = path .. "stripperclip_bulletsin.wav",        t = 50 / 30, c = ci},
        {s = path .. "stripperclip_remove.wav",        t = 70 / 30, c = ci},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
        {s = path .. "boltrelease.wav",        t = 17 / 30, c = ci},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 25 / 30, s = path .. "bolt_back.wav"},
        {t = 35 / 30, s = path .. "bolt_release.wav"},
        {t = 41 / 30, s = CB.Foley},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/g43/weapon_g43_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 2
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {1, 1}
        }
    },
    ["cb_perk_kar98_bayonet"] = {
        Bodygroups = {
            {1, 1}
        }
    },
    ["cb_perk_usemag"] = {
        ShotgunReload = false
    },
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
    {
        PrintName = "SHORT OPTIC",
        Category = "optic_g41_zf41_1.5x",
        Bone = "wpn_body",
        Pos = Vector(0, 12.9, 1.94),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(-0, 0, 0),
    },
    {
        PrintName = "BARREL",
        Category = {"cb_perk_kar98_bayonet"},
        Bone = "wpn_body",
        Pos = Vector(0, 40, 1),
        Ang = Angle(0, -90, 0)
    },
}

SWEP.Hook_Think = function(self)
    -- Attempt to get the owner of the weapon
    local owner = self:GetOwner() -- Use self:GetOwner() for proper owner retrieval
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Get the viewmodel from the owner
    local vm = owner:GetViewModel(0)
    if not IsValid(vm) then return end

    -- Retrieve current ammo and maximum clip size
    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo, 0, 10)

    -- Print debugging information
     --print("Calculated Bodygroup Value:", bodygroupValue)
     --print("Viewmodel Bodygroups:", vm:GetBodyGroups())

    -- Apply the calculated bodygroup value to the viewmodel
    vm:SetBodygroup(2, bodygroupValue)
end