AddCSLuaFile()

SWEP.Base = "arc9_base"

if LVS then
SWEP.Spawnable = true
else
SWEP.Spawnable = false
end

SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Anti-Tank"

SWEP.PrintName = "Panzerbüchse 39"

SWEP.Class = "Anti-Tank Rifle"

SWEP.Trivia = {
    Manufacturer = "Gustloff Werke",
    Calibre = "7.92x94mm",
    Mechanism = "Singe shot, Falling block action",
    Origin = "Germany",
    Year = "1939"
}

SWEP.Credits = {
    Author = "Comrade Bear, CloakerSmoker",
    Animations = "Comrade Bear",
    Assets = "Darkflow Software",
}

SWEP.Description = [[The Panzerbüchse 39, or PzB 39 for short. Is a Falling block Anti-Tank rifle chambered in the unique
7.92x94 MM cartridge. The PzB 39 is a direct evolution from the PzB 38 in which served the same purpose, That being to provide
effective anti-tank potential to infantry units, allowing infantry to more readily take on armored targets without the need
for towed, heavier anti-tank field guns, such as the Pak-36 and Pak-38. Allowing for better mobility and convenience to infantry units.

The PzB-39 has an effective armor penetration of 33 MM of steel at 10 Meters.

However, By 1941 the PzB-39 would have significant challenges in Operation Barbarossa, As Soviet tanks had proved harder to kill with it.
As soviet armor was far more heavier and angled than that of Polish and French tanks a year prior. Though the PzB-39 would not be effective
against the Soviet's more common medium tank, the T-34. The Soviets still used many lighter tanks that the PzB-39 was more than capable of
penetrating, such as the BT-5 and BT-7 light tanks, The standard T-26 light tank, and T-40 and T-60 scout tanks.

Apart from tanks, The PzB-39 can easily disible and destroy halftracks, trucks and other light vehicles of the time. Making ideal as a
principle anti-material rifle. However, the success of the PzB 39 would only last for a couple years. Advances in rockets and chemical based
weapons made Rocket launchers, such as the Panzerfaust's and Panzerschrecks vastly more effective weaponery for infantry.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_pzb39.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

    --Green - GER/USSR BZT
SWEP.TracerNum = 1 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(129, 201, 115) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 0.4

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
	Pos = Vector(-4, 13, -16),
	TPIKPos = Vector(-10, 5, -7),
	TPIKAng = Angle(-15, 10, 180),
	Ang = Angle(4, 35, 180),
	Scale = 1,

    TPIKPosSightOffset = Vector(-2, 1, -1),
}
SWEP.NoTPIKVMPos = true
SWEP.DefaultSkin = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 115 -- Damage done at point blank range
SWEP.DamageMin = 50 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 19000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 20 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 3969 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 10 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 32

SWEP.ShotgunReload = false
SWEP.HybridReload = false

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 8 / 0.1

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "BOLT"
    }
}

SWEP.ManualAction = true

-------------------------- RECOIL

SWEP.Recoil = 40

SWEP.RecoilUp = 2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.2
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/ger/pzb39/"
local handling = "/comradebear/wpn/ger/pzb39/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

local handlingPTRD = "/comradebear/wpn/rus/ptrd41/handling/"

SWEP.ShootSound = "comradebear/wpn/ger/pzb39/pzb39_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/pzb39/pzb39_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/rus/ptrd41/ptrd41_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/rus/ptrd41/ptrd41_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/kar98/handling/kar98_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.LMGZoomin
SWEP.ExitSightsSound = CB.LMGZoomout

SWEP.EnterBipodSound = path .. "bipoddeploy.wav"
SWEP.ExitBipodSound = path .. "bipodretract.wav"

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_m79" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x94.mdl"
SWEP.ShellScale = 1

SWEP.ShellSmoke = true

SWEP.NoShellEject = true
SWEP.NoShellEjectManualAction = true

SWEP.ManualActionNoLastCycle = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.53, -4.5, 3.7),
    Ang = Angle(0, -0.15, 0),
    Magnification = 2.5,
    ViewModelFOV = 35
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 4)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(-0, 0, -0)
SWEP.RestAng = Angle(-0, 0, 0)

SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(55, 0, 0)
SWEP.CustomizePos = Vector(24, 28, 15)
SWEP.CustomizeRotateAnchor = Vector(21.5, -1.21, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(2, -5, 2)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- Bipod

SWEP.Bipod = true
SWEP.RecoilUpMultBipod = 0.1
SWEP.SwayMultBipod = 0.1

-------------------------- HoldTypes

SWEP.HoldType = "passive"
SWEP.HoldTypeSprint = "rpg"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.HideBones = {"bullet"}

local bulletin = {
    handling .. "PzB39_insertround.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_uncycled"] = { Source = "empty_idle" },
    ["fire"] = { Source = "base_fire_start" },
    ["fire_empty"] = { Source = "base_fire_last",},
    ["fire_iron"] = { Source = "iron_fire_start" },
    ["fire_iron_empty"] = { Source = "iron_fire_last" },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_end" },
    ["cycle_bipod"] = { Source = "deployed_fire_end_1", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_10"] = { Source = "deployed_fire_end_1", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_9"] = { Source = "deployed_fire_end_2", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_8"] = { Source = "deployed_fire_end_3", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_7"] = { Source = "deployed_fire_end_4", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_6"] = { Source = "deployed_fire_end_5", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_5"] = { Source = "deployed_fire_end_6", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_4"] = { Source = "deployed_fire_end_7", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_3"] = { Source = "deployed_fire_end_8", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_2"] = { Source = "deployed_fire_end_9", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_bipod_1"] = { Source = "deployed_fire_end_10", EjectAt = 0.5, MinProgress = 1, Mult = 0.8, EventTable = {
        {t = 5/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 80/35, s = bulletin},
        {t = 100/35, s = handling .. "PzB39_closelid.wav"},
        {t = 130/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["cycle_iron_bipod"] = { Source = "deployed_fire_end", EjectAt = 0.5, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35, s = handling .. "mosin_bolt_back.wav"},
        {t = 28/35, s = handling .. "mosin_bolt_forward.wav"},
        {t = 36/35, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["reload"] = { Source = "base_reload_clip_empty", EjectAt = 0.85, MinProgress = 0.75, EventTable = {
        {t = 19/33,  s = handling .. "mosin_bolt_open.wav"},
        {t = 27/33,  s = handling .. "mosin_bolt_back.wav"},
        {t = 68/33,  s = handling .. "mosin_bolt_clipinsert.wav"},
        {t = 83/33,  s = handling .. "mosin_bolt_bulletsin.wav"},
        {t = 110/33, s = handling .. "mosin_bolt_clipremove.wav"},
        {t = 144/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 150/33, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["reload_empty"] = { Source = "base_reload_clip_empty", EjectAt = 0.85, MinProgress = 0.75, EventTable = {
        {t = 19/33,  s = handling .. "mosin_bolt_open.wav"},
        {t = 27/33,  s = handling .. "mosin_bolt_back.wav"},
        {t = 68/33,  s = handling .. "mosin_bolt_clipinsert.wav"},
        {t = 83/33,  s = handling .. "mosin_bolt_bulletsin.wav"},
        {t = 110/33, s = handling .. "mosin_bolt_clipremove.wav"},
        {t = 144/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 150/33, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.65, FireASAP = true, EventTable = {
        {t = 0 / 33, s = CB.Foley},
        {t = 35/35, s = handling .. "PzB39_openlid.wav"},
        {t = 55/35, s = handling .. "PzB39_closelid.wav"},
    } },
	
    ["enter_bipod"] = { Source = "deployed_in", EventTable = {
        {t = 1 / 36, s = CB.Foley},
        {t = 20 / 36, s = CB.BipodDrop02},
        {t = 65 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["exit_bipod"] = { Source = "deployed_out", EventTable = {
        {t = 1 / 36, s = CB.BipodShift01},
        {t = 8 / 36, s = CB.BipodGrab01},
        {t = 15 / 36, s = CB.BipodPickup01},
    } },
	
    ["enter_bipod_empty"] = { Source = "deployed_in_empty", EventTable = {
        {t = 19 / 36, s = path .. "deploygroundhit.wav"},
        {t = 46 / 36, s = path .. "rattle.wav"},
        {t = 65 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["exit_bipod_empty"] = { Source = "deployed_out_empty", EventTable = {
        {t = 25 / 36, s = path .. "rattle.wav"},
        {t = 39 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["idle_bipod"] = { Source = "deployed_idle" },
    ["idle_iron_bipod"] = { Source = "deployed_iron_idle" },
    ["idle_bipod_empty"] = { Source = "deployed_idle_empty" },
    ["idle_iron_bipod_empty"] = { Source = "deployed_iron_idle_empty" },
    ["fire_bipod"] = { Source = {
        "deployed_fire_1",
        "deployed_fire_2"
    }, },
    ["fire_iron_bipod"] = { Source = {
        "deployed_iron_fire_1",
        "deployed_iron_fire_2"
    }, },
    ["fire_bipod_empty"] = { Source = {
        "deployed_iron_fire_last"
    } },
    ["fire_iron_bipod_empty"] = { Source = {
        "deployed_iron_fire_last"
    } },
    ["dryfire_bipod"] = { Source = "deployed_dryfire" },
    ["dryfire_iron_bipod"] = { Source = "deployed_iron_dryfire" },
    ["trigger_bipod"] = { Source = "deployed_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron_bipod"] = { Source = "deployed_iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["reload_bipod"] = { Source = "deployed_reload", MinProgress = 0.75, EventTable = {
        {t = 10/35, s = handling .. "PzB39_magout.wav"},
        {t = 55/35, s = handling .. "PzB39_magin.wav"},
    } },
    ["reload_bipod_empty"] = { Source = "deployed_reload_empty", MinProgress = 0.5, EventTable = {
        {t = 10/35, s = handling .. "PzB39_magout.wav"},
        {t = 55/35, s = handling .. "PzB39_magin.wav"},
        {t = 120/35, s = handling .. "PzB39_boltopen.wav"},
        {t = 145/35, s = handling .. "PzB39_openlid.wav"},
        {t = 165/35, s = handling .. "PzB39_takeshell.wav"},
        {t = 185/35, s = bulletin},
        {t = 210/35, s = handling .. "PzB39_closelid.wav"},
        {t = 235/35, s = handling .. "PzB39_boltclose.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = -1, Mult = 1, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", Mult = 1, EjectAt = 0.85, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
        {t = 14/37.2, s = bulletin},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
        {t = 14 / 35.5, s = path .. "boltforward.wav"},
        {t = 21 / 35.5, s = path .. "boltlatch.wav"},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 3
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {3, 1}
        }
    },
    ["doi_perk_stock"] = {
        Skin = 0
    },
    ["doi_perk_bayonet"] = {
        Bodygroups = {
            {4, 1}
        }
    },
    ["doi_perk_gl"] = {
        Bodygroups = {
            {5, 1}
        }
    },
    ["doi_optic_k98"] = {
        HybridReload = false
    },
    ["doi_optic_k98_4x"] = {
        HybridReload = false
    }
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
}

SWEP.Hook_TranslateAnimation = function(self, anim)
    -- We're only customizing the 'cycle' animation
    if anim == "cycle_bipod" then
        local clip = self:Clip1() -- Current ammo in the magazine

        -- Clamp or validate the ammo to match your animation set
        local max_cycle = 10 -- maximum number of cycle animations
        clip = math.Clamp(clip, 1, max_cycle)

        -- Return custom animation name like "cycle_9", "cycle_8", etc.
        return "cycle_bipod_" .. clip
    end

    -- Default behavior for other animations
    return anim
end

SWEP.LastBlockFireTime = 0 -- Initialize the cooldown tracker

SWEP.HookP_BlockFire = function(self)
    -- Check if the bipod is deployed
    local IsDeployed = self:GetBipod()

    if not IsDeployed then
        local curTime = CurTime()

        -- Only play the sound and message if enough time has passed
        if curTime > (self.LastBlockFireTime + 1) then -- 1-second delay
            self:EmitSound("hts/easternfront/weapons/dp27/handling/dp_empty.wav")
            self:GetOwner():PrintMessage(HUD_PRINTCENTER, "You need to deploy the bipod before shooting!")
            self.LastBlockFireTime = curTime -- Update the cooldown timer
        end

        -- Block firing explicitly
        return true
    end

    -- Allow firing if the bipod is deployed
    return false
end

SWEP.Hook_BlockTPIK = function(self)

    local IsDeployed = self:GetBipod()
    if IsDeployed then
        return false
    else
        return true
    end
end

SWEP.Hook_Think = function(self)

    if self:GetBipod() then
        self:SetHoldType("ar2")
    else
        self:SetHoldType("passive")
    end

    -- Attempt to get the owner of the weapon
    local owner = self:GetOwner() -- Use self:GetOwner() for proper owner retrieval
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Get the viewmodel from the owner
    local vm = owner:GetViewModel(0)
    if not IsValid(vm) then return end

    -- Retrieve current ammo and maximum clip size
    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo - 1, 0, 10)

    -- Print debugging information
    --rint("Calculated Bodygroup Value:", bodygroupValue)
    --print("Viewmodel Bodygroups:", vm:GetBodyGroups())

    -- Apply the calculated bodygroup value to the viewmodel
    vm:SetBodygroup(2, bodygroupValue)

	local IsDeployed = self:GetBipod()
end

SWEP.LastBlockReloadTime = 0 -- Initialize the cooldown tracker for reloading

function SWEP:DoProjectileAttack(pos, ang, spread)
    if SERVER then
        local owner = self:GetOwner()

        --local localOffset = Vector(50, -4, -5)
        local localOffset = Vector(40, -0, -3)

        local src = LocalToWorld(localOffset, Angle(0,0,0), pos, ang)

        local bullet = {}
        bullet.Src = src
        bullet.Dir = owner:EyeAngles():Forward()
        bullet.Spread = Vector(0, 0, 0)
        bullet.TracerName = "lvs_tracer_cannon_7mm_SMKH"
        bullet.Attacker = owner
        bullet.Force = 33 * 102
        bullet.Force1km = 10 * 102
        bullet.HullSize = 0
        bullet.Damage = 275
        bullet.Velocity = 1210 / 0.01905
        bullet.EnableBallistics = true
        bullet.Entity = owner

        --debugoverlay.Cross(src, 100, 10, Color(255, 0, 0), true)

        LVS:FireBullet(bullet)
    end
end

--[[if SERVER then
    util.AddNetworkString('use_this_to_cheat')

    net.Receive('use_this_to_cheat', function(length, ply)

        local pos = net.ReadVector()
        local ang = net.ReadAngle()

        local bullet = {}
        bullet.Src = pos
        bullet.Dir = ang:Forward()
        bullet.Spread = Vector(0, 0, 0)
        bullet.TracerName = "lvs_tracer_cannon_7mm_SMKH"
        bullet.Attacker = ply
        bullet.Force = 33 * 102
        bullet.HullSize = 0
        bullet.Damage = 275
        bullet.Velocity = 475 / 0.01905
		bullet.EnableBallistics = true
    
        -- Fire the LVS bullet manually
        LVS:FireBullet(bullet)
    
        -- Play muzzle effect for LVS bullet
        local effectdata = EffectData()
        effectdata:SetOrigin(pos)
        --effectdata:SetNormal(ang:Vector())
        --effectdata:SetEntity(vm)
        util.Effect("lvs_muzzle", effectdata)
    end)

end]]

function SWEP:CanReload()
	local IsDeployed = self:GetBipod()

	if IsDeployed then
		-- print("Okay, We can reload!")
		if self:GetOwner():KeyDown(IN_WALK) then return false end
		if self:StillWaiting() then return end
		if self:GetCapacity(self:GetUBGL()) <= 0 then return end
		-- if self:GetTraversalSprintAmount() >= 0 then return end
		local ammo = self:Ammo1()
		if self:GetUBGL() then
			ammo = self:Ammo2()
		end
		if ammo <= 0 and !self:GetInfiniteAmmo() then return end
		if !self:GetProcessedValue("ReloadWhileSprint", true) and self:GetSprintAmount() > 0 then
			return
		end
		if self:GetJammed() then return end
		if self:GetCustomize() then
			return
		end
	
		return true
	else
		-- print("No, We cannot reload!")
        local curTime = CurTime()

        -- Only play the sound and message if enough time has passed
        if curTime > (self.LastBlockReloadTime + 1) then -- 1-second delay to prevent spamming
            self:EmitSound("hts/easternfront/weapons/dp27/handling/dp_empty.wav")
            self:GetOwner():PrintMessage(HUD_PRINTCENTER, "You need to deploy the bipod before reloading!")
            self.LastBlockReloadTime = curTime -- Update the cooldown timer
        end
		return false
	end
end