AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Machine Guns"

SWEP.PrintName = "MG 34 [Placeholder]"

SWEP.Class = "Machine Gun"

SWEP.Trivia = {
    Manufacturer = "Rheinmetall",
    Calibre = "7.92x57mm Mauser",
    Mechanism = "Recoil-Operated Rotating Open Bolt",
    Origin = "Nazi Germany",
    Year = "1934"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "New World Interactive",
}

SWEP.Description = [[The MG34 is a belt fed machine gun, generally regarded as the first general purpose machine gun, It was initially designed with
the principle of increasing the mobility and firepower of infantry, This novel concept for a machine gun is what has made it so effective
during the war, and even continuing to be used until the end of the war.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_mg34_temp.mdl"
SWEP.WorldModel = "models/weapons/w_mach_m249para.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-6, 4, -8),
    Ang = Angle(-5, 0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "00900000"
SWEP.DefaultSkin = 0

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 60 -- Damage done at point blank range
SWEP.DamageMin = 40 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 7500

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 17 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2510 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 50 -- Self-explanatory.
SWEP.SupplyLimit = 4 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = false

SWEP.SprintCancelsReload = true
SWEP.BashCancelsReload = true


SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 750

SWEP.Firemodes = {
    {
        Mode = -1,
        PrintName = "Full-Trigger"
    },
    {
        Mode = 1,
        PrintName = "Half-Trigger",
    },
}

    --Green - GER/USSR BZT
SWEP.TracerNum = 2 -- Tracer every X
SWEP.TracerFinalMag = 5 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(129, 201, 115) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.TriggerDelay = false
SWEP.TriggerDelayTime = 0.1
SWEP.TriggerDelayCancellable = true
SWEP.TriggerDelayRepeat = false
SWEP.TriggerStartFireAnim = false

-------------------------- RECOIL

SWEP.Recoil = 2

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 1 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.75
SWEP.RecoilRandomSide = 0.75

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 180
-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.05 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(-2, 20, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.2

SWEP.VisualRecoilMult = 1
SWEP.VisualRecoilADSMult = 0.5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.1
SWEP.VisualRecoilPositionBump = 1.2
SWEP.VisualRecoilPositionBumpUp = 0.6 -- its a mult


SWEP.VisualRecoilDampingConst = 200 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 1
SWEP.VisualRecoilSpringPunchDamping = 4 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 15
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 2.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.5 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.5 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.90

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/mg34/mg34_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/mg34/mg34_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "comradebear/wpn/generic/trigger_empty_01.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.LMGZoomin
SWEP.ExitSightsSound = CB.LMGZoomout

SWEP.HookP_TranslateSound = function(self, data)
    if data.name == "shootsound" then
        data.channel = CHAN_AUTO
    end

    return data
end

SWEP.BulletBones = {
    [0] = "Ammo_00",
    [1]  = "Ammo_01",
    [2]  = "Ammo_02",
    [3]  = "Ammo_03",
    [4]  = "Ammo_04",
}

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_minimi" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x57.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-3.64, -5, 2.1),
    Ang = Angle(0, 0.1, 0),
    Magnification = 1,
    ViewModelFOV = 60
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(10, 0, -6)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 10)
SWEP.CustomizePos = Vector(21, 36, 4)
SWEP.CustomizeRotateAnchor = Vector(14, -6, 0)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- Bipod

SWEP.Bipod = false
SWEP.RecoilUpMultBipod = 0.1
SWEP.SwayMultBipod = 0.1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "passive"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "comradebear/wpn/ger/mg34/handling/"
local path1 = "comradebear/wpn/ger/mg42/handling/"

SWEP.EnterBipodSound = path .. "bipoddeploy.wav"
SWEP.ExitBipodSound = path .. "bipodretract.wav"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle", RareSource = "base_idle_fidget", Time = 1.9 },
    ["idle_iron"] = { Source = "base_idle" },
    ["fire"] = { Source = {
        "base_fire_1",
        "base_fire_2"
    } },
    ["fire_iron"] = { Source = {
        "iron_fire_1",
        "iron_fire_2"
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["trigger"] = { Source = "base_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron"] = { Source = "iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["bash"] = { Source = "base_melee_bash" },
    ["firemode"] = { Source = "base_fireselect" },
    ["reload"] = { Source = "base_reload_half", MinProgress = 0.8, MagSwapTime = 3.5, EventTable = {
        {t = 20 / 32.5, s = path .. "lidopen.wav"},
        {t = 70 / 32.5, s = path .. "drum_out.wav"},
        {t = 83 / 32.5, s = path .. "beltout.wav"},
        {t = 158 / 32.5, s = path .. "drum_in.wav"},
        {t = 190 / 32.5, s = path .. "beltshift.wav"},
        {t = 234 / 32.5, s = path .. "lidclose.wav"},
    } },
    ["reload_empty"] = { Source = "base_reload_empty", MinProgress = 0.85, MagSwapTime = 3.5, EventTable = {
        {t = 30 / 32.5, s = path .. "lidopen.wav"},
        {t = 68 / 32.5, s = path .. "bolt_back.wav"},
        {t = 76 / 32.5, s = path .. "bolt_forward.wav"},
        {t = 132 / 32.5, s = path .. "drum_out.wav"},
        {t = 213 / 32.5, s = path .. "drum_in.wav"},
        {t = 252 / 32.5, s = path .. "beltshift.wav"},
        {t = 288 / 32.5, s = path .. "lidclose.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 20 / 30, s = path .. "bolt_back.wav"},
        {t = 35 / 30, s = path .. "bolt_forward.wav"},
        {t = 41 / 30, s = CB.Foley},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["enter_bipod"] = { Source = "deployed_in", EventTable = {
        {t = 0 / 36, s = CB.Deploy},
        {t = 19 / 36, s = CB.MGDeploy},
    } },
    ["exit_bipod"] = { Source = "deployed_out", EventTable = {
        {t = 5 / 36, s = CB.Foley},
        {t = 39 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["idle_bipod"] = { Source = "deployed_idle" },
    ["idle_iron_bipod"] = { Source = "deployed_iron_idle" },
    ["fire_bipod"] = { Source = {
        "deployed_fire_1",
        "deployed_fire_2"
    } },
    ["fire_iron_bipod"] = { Source = {
        "deployed_iron_fire_1",
        "deployed_iron_fire_2"
    } },
    ["dryfire_bipod"] = { Source = "deployed_dryfire" },
    ["dryfire_iron_bipod"] = { Source = "deployed_iron_dryfire" },
    ["firemode_bipod"] = { Source = "deployed_fireselect" },
    ["trigger_bipod"] = { Source = "deployed_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron_bipod"] = { Source = "deployed_iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["reload_bipod"] = { Source = "deployed_reload_half", MinProgress = 0.85, EventTable = {
        {t = 30 / 32.5, s = path .. "lidopen.wav"},
        {t = 70 / 32.5, s = path .. "drum_out.wav"},
        {t = 75 / 32.5, s = path .. "belt_out.wav"},
        {t = 158 / 32.5, s = path .. "drum_in.wav"},
        {t = 198 / 32.5, s = path .. "beltshift.wav"},
        {t = 234 / 32.5, s = path .. "lidclose.wav"},
    } },
    ["reload_bipod_empty"] = { Source = "deployed_reload_empty", MinProgress = 0.85, EventTable = {
        {t = 30 / 32.5, s = path .. "lidopen.wav"},
        {t = 68 / 32.5, s = path .. "bolt_back.wav"},
        {t = 76 / 32.5, s = path .. "bolt_forward.wav"},
        {t = 125 / 32.5, s = path .. "drum_out.wav"},
        {t = 210 / 32.5, s = path .. "drum_in.wav"},
        {t = 252 / 32.5, s = path .. "beltshift.wav"},
        {t = 288 / 32.5, s = path .. "lidclose.wav"},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/mg34/weapon_mg34_dm"
SWEP.CustomCamoScale = 1.5
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_mag"] = {
        ClipSize = 75
    },
    ["cb_dply_bipod"] = {
        Bodygroups = {
            {3, 1}
        }
    }
}

SWEP.Attachments = {
    {
        PrintName = "BIPOD",
        Category = "cb_dply_bipod",
        Bone = "weapon",
        Pos = Vector(-0.3, 21, -2),
        Ang = Angle(0, -90, 0),
        CorrectiveAng = Angle(0, 0, 0),
    },
}

--[[SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local ammo = self:Clip1()
    local deployed = self:GetBipod()

    -- Start with default (should match bodygroup count)
    local bgstr = self.DefaultBodygroups or "000000"
    local chars = string.ToTable(bgstr)

    -- Function to convert number to base36 char
    local function ToBase36Char(num)
        if num <= 9 then return tostring(num) end
        return string.char(87 + num) -- 87 + 10 = 97 = 'a'
    end

    -- Update ammo count at index 3 (Lua index, not bodygroup index)
    local ammoBG = math.Clamp(ammo, 0, 12)
    chars[3] = ToBase36Char(ammoBG)

    -- Rebuild the string
    self.DefaultBodygroups = table.concat(chars)
end]]

function SWEP:EnterSights()
    local deployed = self:GetBipod()

    --print(deployed)
    -- Pimp'n!
    if deployed == true then 
        if self:GetSprintAmount() > 0.5 then return end
        if !self:GetProcessedValue("HasSights", true) then return end
        if self:GetCustomize() then return end
        if !self:GetProcessedValue("ReloadInSights", true) and self:GetReloading() then return end
        if self:GetHolsterTime() > 0 then return end
        if self:GetProcessedValue("UBGLInsteadOfSights", true) then return end
        if self:GetSafe() then return end
        if self.SightsInterruptInspect and self:GetInspecting() then self:CancelInspect() end
        if self:GetAnimLockTime() > CurTime() and !self:GetReloading() then return end -- i hope this won't cause any issues later
        if self:GetValue("UBGL") and self:GetOwner():KeyDown(IN_USE) then return end
        if self:GetIsNearWall() and math.abs(self:GetOwner():GetNW2Float("leaning_fraction", 0)) < 0.1 then return end -- leaning mod support
        if self:HasAnimation("bash") and self.SetNextAiming then
            if self.SetNextAiming > CurTime() then return end
        end

        -- self:ToggleBlindFire(false)
        self:SetInSights(true)
        if IsFirstTimePredicted() then
            local soundtab1 = {
                name = "entersights",
                sound = self:RandomChoice(self:GetProcessedValue("EnterSightsSound", true)),
                channel = ARC9.CHAN_FIDDLE,
            }

            self:PlayTranslatedSound(soundtab1)
        end

        if !self:StillWaiting() or self.NoFireDuringSighting then
            if !(self.SightIsAlsoBipodAnims and self:GetBipod()) then
                if self:GetProcessedValue("InstantSightIdle", true) then
                    self:PlayAnimation("idle")
                else
                    local anim = self:TranslateAnimation("enter_sights")
                    local mult = self:GetProcessedValue("AimDownSightsTime") -- Incorrectly uses a time as a multiplier! Preserved for legacy behavior
                    if self:GetAnimationEntry(anim).NoStatAffectors then
                        mult = 1
                    end
                    self:PlayAnimation(anim, mult, self.NoFireDuringSighting, nil, nil, true)
                end
            end
        end

        self:SetShouldHoldType()
    else
        return false
    end
end