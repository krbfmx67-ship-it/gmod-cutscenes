AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Pistols"

SWEP.PrintName = "Walther P38"

SWEP.Class = "Pistol"

SWEP.Trivia = {
    Manufacturer = "Walther",
    Calibre = "9x19mm Parabellum",
    Mechanism = "Blowback",
    Origin = "Nazi Germany",
    Year = "1938"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Walther P38 was the first and only unique service pistol that Nazi Germany would produce and field.
Though the Germans had many handguns, From as old as the C96 Mauser to the P08 Luger, and even the more rarer Browning HP from Belgium.
None was more reliable and trusted than the Walther P38, Which many of its designs still live in modern firearms today.
Although it is not as iconic as the P08 or C96, It was the most widely adopted in the German Armed Forces.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_p38.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 80

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-14, 3.5, -4),
    TPIKPos = Vector(-16, 8, -4),
    TPIKAng = Angle(-10, 0, -180),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(10, -4, 0),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.TPIKnolefthand = true

SWEP.DefaultSkin = 0

-------------------------- TRACERS

SWEP.NeverPhysBullet = false

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(113, 207, 128) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 30 -- Damage done at point blank range
SWEP.DamageMin = 20 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 3700

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 3.5,
    [HITGROUP_CHEST] = 1.55,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1150 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = 1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 8 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 300

SWEP.Firemodes = {
    {
        Mode = 1,
    }
}

SWEP.ShotgunReload = false
SWEP.HybridReload = false

-------------------------- RECOIL

SWEP.Recoil = 1

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.5

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.3 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 4, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 2 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 1

-- SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 120 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.25
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.28 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.28 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/p38/p38_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/p38/p38_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/p08/handling/p08_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.PistolZoomIn
SWEP.ExitSightsSound = CB.PistolZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol_red" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/9x19.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.55, -1, 1.9),
    Ang = Angle(0, 0.8, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(4, -2, -15)
SWEP.RestAng = Angle(7, 60, -2)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(16, 20, 4.5)

SWEP.CustomizeRotateAnchor = Vector(16, -2.4, -4)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "pistol"
SWEP.HoldTypeSprint = "pistol"
SWEP.HoldTypeHolstered = "normal"
SWEP.HoldTypeSights = "pistol"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/p08/handling/p08_"
local handling = ")comradebear/wpn/ger/p38/handling/"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_iron"] = { Source = "iron_idle" },
    ["idle_iron_emtpty"] = { Source = "iron_empty" },
    ["fire"] = { Source = {
        "base_shoot",
    } },
    ["fire_empty"] = { Source = "base_shoot_last" },
    ["fire_iron"] = { Source = {
        "base_shoot_iron",
    } },
    ["enter_sights"] = { Source = "iron_idle" },
    ["enter_sights_empty"] = { Source = "iron_empty" },
    ["fire_iron_empty"] = { Source = "base_shoot_iron_last" },
    ["dryfire"] = { Source = "empty_idle" },
    ["dryfire_iron"] = { Source = "empty_idle" },
    ["bash"] = { Source = "base_melee_bash" },
    ["bash_empty"] = { Source = "empty_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.9,  EventTable = {
        {s = handling .. "p38_magout.wav",        t = 15 / 37, c = ci},
        {s = handling .. "p38_magin.wav",        t = 65 / 37, c = ci},
        {s = handling .. "p38_maghit.wav",        t = 70 / 37, c = ci},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 1, EventTable = {
        {s = handling .. "p38_magout.wav",        t = 15 / 37, c = ci},
        {s = handling .. "p38_magin.wav",        t = 65 / 37, c = ci},
        {s = handling .. "p38_maghit.wav",        t = 70 / 37, c = ci},
        {s = handling .. "p38_boltrelease.wav",        t = 100 / 37, c = ci},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "empty_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "empty_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["idle_sprint"] = { Source = "base_sprint" },
    ["idle_sprint_empty"] = { Source = "base_sprint_empty" },
}

SWEP.InstantSprintIdle = true

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/c96/weapon_c96_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
}

SWEP.Attachments = {
}
SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Check if the weapon is reloading
    if self:GetReloading() then
        -- If HoldType isn't already changed, set it to the desired reload type
        if not self.ReloadingHoldTypeSet then
            self.OriginalHoldType = self.OriginalHoldType or self.HoldType
            self:SetHoldType("revolver") -- Replace with the desired reload hold type
            self.ReloadingHoldTypeSet = true
        end
    else
        -- If reloading is finished, reset HoldType to the original
        if self.ReloadingHoldTypeSet then
            self:SetHoldType(self.OriginalHoldType)
            self.ReloadingHoldTypeSet = false
        end
    end
end