AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Wacky Made-up Weapons"

SWEP.PrintName = "StKb 98K/I"

SWEP.Class = "Rifle"

SWEP.Trivia = {
    Manufacturer = "Unknown",
    Calibre = "7.92x57MM",
    Mechanism = "Self Loading Bolt Action",
    Origin = "Nazi Germany",
    Year = "1944~",
    Model = "Prototype"
}

SWEP.Credits = {
    Authors = "ComradeBear, William",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[A modified Mauser Kar98K with a gas piston self loading mechanism on top of the existing bolt mechanism. Along with a magazine well cutout to accept MG-13 magazines, This weapon is an attempt to effectly modify an existing firearm to increase rate of fire and speed of reload.
Despite how crude the firearm appears to be, It does atleast succeeds in both goals, Though at the cost of reliability of the weapon.

The unofficial designation of this firearm is the Sturm-Karabiner 98 Kurz/I.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_stk98_44.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

    --Red - US/USSR T-46
SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(202, 107, 83) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-8, 3, -6),
    TPIKAng = Angle(-10, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,

    TPIKPosSightOffset = Vector(1, 1, -2),
}
SWEP.NoTPIKVMPos = true
SWEP.DefaultSkin = 1
SWEP.DefaultBodygroups = "0000000000000000000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 115 -- Damage done at point blank range
SWEP.DamageMin = 50 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 19000

SWEP.ImpactForce = 0 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 20 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2838 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 20 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.BarrelLength = 54

SWEP.ShotgunReload = false
SWEP.HybridReload = false

SWEP.DryFireDelay = 0.25

-------------------------- JAMMING

SWEP.Malfunction = true
SWEP.MalfunctionJam = true -- After a malfunction happens, the gun will dryfire until reload is pressed. If unset, instead plays animation right after.  -- are you sure? doesnt seem to work
SWEP.MalfunctionNeverLastShoot = true -- Last round will never cause malfunctions (so guns with empty animations wont be fucky)
SWEP.MalfunctionCycle = false -- ManualAction = true only: Roll malfunction roullete not after shoot but before every cycle anim
SWEP.MalfunctionWait = 0 -- The amount of time to wait before playing malfunction animation (or can reload)
SWEP.MalfunctionMeanShotsToFail = 40 -- The mean number of shots between malfunctions, will be autocalculated if nil

-------------------------- FIREMODES

SWEP.RPM = 200

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "SEMI"
    }
}

SWEP.ManualAction = false

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.7

SWEP.RecoilAutoControl = 2 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 0.1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.03 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 15 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2.5, 20, -5) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 2.2
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 70 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 4
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.3
SWEP.SwayMultSights = 0.8
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

local path = "comradebear/wpn/ger/kar98/"
local handling = "comradebear/wpn/ger/kar98/handling/"

SWEP.ShootSound = "comradebear/wpn/ger/kar98/kar98_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/kar98/kar98_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "comradebear/wpn/generic/trigger_empty_01.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomIn
SWEP.ExitSightsSound = CB.RifleZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_ar" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/792x57.mdl"
SWEP.ShellScale = 1

SWEP.ShellSmoke = true

SWEP.NoShellEject = false
SWEP.NoShellEjectManualAction = false

SWEP.ManualActionNoLastCycle = false

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.15, -1, 1.4),
    Ang = Angle(0, -0.2, 0),
    Magnification = 1,
    ViewModelFOV = 40
}

SWEP.IronSightsUBGL = {
    Pos = Vector(-1.21, -5, 5),
    Ang = Angle(0, 0.45, 0),
    Magnification = 1,
    ViewModelFOV = 60
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(2, 2, -6)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)

SWEP.SprintVerticalOffset = true

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

SWEP.OneHandedSprint = false

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(17, 32, 4)
SWEP.CustomizeRotateAnchor = Vector(17, -0, -4)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.HideBones = {"stripper", "bullet_reload", "bullet1", "bullet2", "bullet3", "bullet4", "bullet5"}

SWEP.BulletBones = { -- the bone that represents bullets in gun/mag
    [1] = "Bullet_R",
    [2] = "Bullet_L"
}

local bulletin = {
    handling .. "mosin_bullet_insert_1.wav",
    handling .. "mosin_bullet_insert_2.wav",
    handling .. "mosin_bullet_insert_3.wav",
    handling .. "mosin_bullet_insert_4.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_openbolt"] = { Source = "base_idle_openbolt" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_jam"] = { Source = "base_idle" },
    ["idle_empty_openbolt"] = { Source = "base_idle_empty" },
    ["idle_uncycled"] = { Source = "base_idle_empty" },
    ["fire"] = { Source = "base_shoot", Mult = 1, MinProgress = 1, EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["fire_openbolt"] = { Source = "base_shoot_openbolt", Mult = 1, MinProgress = 1, EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["fire_empty"] = { Source = "base_shoot", EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["fire_jam"] = { Source = "base_shoot_jam" },
    ["jam"] = { Source = "base_shoot" },
    ["fire_iron"] = { Source = "base_shoot", EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["fire_iron_openbolt"] = { Source = "base_shoot_openbolt", EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["fire_iron_empty"] = { Source = "base_shoot", EventTable = {
        {s = handling .. "kar98_boltback.wav",        t = 3 / 35, v = 0.5, c = ci},
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_stab" },
    ["cycle"] = { Source = "base_cycle", Mult = 0.8, EjectAt = 0.75, MinProgress = 1, EventTable = {
            {s = handling .. "kar98_boltup.wav",        t = 15 / 35, c = ci},
            {s = handling .. "kar98_boltback.wav",        t = 20 / 35, c = ci},
            {s = handling .. "kar98_boltforward.wav",        t = 25 / 35, c = ci},
            {s = handling .. "kar98_boltdown.wav",        t = 35 / 35, c = ci},
    } },
    ["cycle_iron"] = { Source = "base_cycle", Mult = 0.8, EjectAt = 0.75, MinProgress = 1, EventTable = {
            {s = handling .. "kar98_boltup.wav",        t = 15 / 35, c = ci},
            {s = handling .. "kar98_boltback.wav",        t = 20 / 35, c = ci},
            {s = handling .. "kar98_boltforward.wav",        t = 25 / 35, c = ci},
            {s = handling .. "kar98_boltdown.wav",        t = 35 / 35, c = ci},
    } },

    ["fix"] = { Source = "base_cycle", EjectAt = 25/32, RestoreAmmo = -1, MinProgress = 0.4, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_boltfidget.wav",        t = 15 / 32, c = ci},
        {s = handling .. "stk98_boltback.wav",        t = 25 / 32, c = ci},
        {s = handling .. "kar98_boltback.wav",        t = 27 / 32, c = ci},
        {s = handling .. "kar98_boltforward.wav",        t = 40 / 32, c = ci},
    } },

    ["fix_openbolt"] = { Source = "base_cycle_openbolt", EjectAt = 25/32, RestoreAmmo = -1, MinProgress = 1, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_boltfidget.wav",        t = 15 / 32, c = ci},
        {s = handling .. "stk98_boltback.wav",        t = 25 / 32, c = ci},
        {s = handling .. "kar98_boltback.wav",        t = 27 / 32, c = ci},
    } },

    ["fix_empty"] = { Source = "base_cycle", MinProgress = 1, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_boltfidget.wav",        t = 15 / 32, c = ci},
        {s = handling .. "stk98_boltback.wav",        t = 25 / 32, c = ci},
        {s = handling .. "kar98_boltback.wav",        t = 27 / 32, c = ci},
        {s = handling .. "kar98_boltforward.wav",        t = 40 / 32, c = ci},
    } },

    ["reload"] = { Source = "base_reload", MinProgress = 0.7, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_magout.wav",        t = 20 / 32, c = ci},
        {s = handling .. "stk98_magin.wav",        t = 70 / 32, c = ci},
    } },

    ["reload_openbolt"] = { Source = "base_reload_openbolt", MinProgress = 1, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_magout.wav",        t = 20 / 32, c = ci},
        {s = handling .. "stk98_magin.wav",        t = 70 / 32, c = ci},
    } },
    ["reload_empty"] = { Source = "base_reload_empty", MinProgress = 0.85, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_magout.wav",        t = 20 / 32, c = ci},
        {s = handling .. "stk98_magin.wav",        t = 70 / 32, c = ci},
        
        {s = handling .. "stk98_boltfidget.wav",        t = 115 / 32, c = ci},
        {s = handling .. "stk98_boltback.wav",        t = 125 / 32, c = ci},
        {s = handling .. "kar98_boltback.wav",        t = 130 / 32, c = ci},
        {s = handling .. "kar98_boltforward.wav",        t = 135 / 32, c = ci},
    } },
    ["reload_empty_openbolt"] = { Source = "base_reload_empty_openbolt", MinProgress = 1, MagSwapTime = 2.75, EventTable = {
        {s = handling .. "stk98_magout.wav",        t = 20 / 32, c = ci},
        {s = handling .. "stk98_magin.wav",        t = 70 / 32, c = ci},
        
        {s = handling .. "stk98_boltfidget.wav",        t = 115 / 32, c = ci},
        {s = handling .. "stk98_boltback.wav",        t = 125 / 32, c = ci},
        {s = handling .. "kar98_boltback.wav",        t = 130 / 32, c = ci},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_openbolt"] = { Source = "base_draw_openbolt", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_openbolt"] = { Source = "base_holster_openbolt", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty_openbolt"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty_openbolt"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = 0, Mult = 1, EventTable = {
            {s = handling .. "kar98_boltup.wav",        t = 20 / 32, c = ci},
            {s = handling .. "kar98_boltback.wav",        t = 25 / 32, c = ci},
			{s = handling .. "kar98k_bulletcatch.wav",        t = 30 / 32, c = ci},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", RestoreAmmo = 0, Mult = 1, EjectAt = 0.85, EventTable = {
            {s = handling .. "kar98_boltup.wav",        t = 20 / 32, c = ci},
            {s = handling .. "kar98_boltback.wav",        t = 25 / 32, c = ci},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
			{s = { handling .. "kar98_insert1.wav", handling .. "kar98_insert2.wav", handling .. "kar98_insert3.wav"}, t = 10 / 35, c = ci},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
            {s = handling .. "kar98_boltforward.wav",        t = 10 / 35, c = ci},
            {s = handling .. "kar98_boltdown.wav",        t = 20 / 35, c = ci},
    } }
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 3
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {3, 1}
        }
    },
    ["doi_perk_stock"] = {
        Skin = 0
    },
    ["cb_perk_bayonet"] = {
        Bodygroups = {
            {1, 1}
        }
    },
    ["optic_kar98_zf39_12x"] = {
        HybridReload = false
    },

    ["cb_stkb_fullauto"] = {
        Hook_TranslateAnimation = function(self, anim)
            return anim .. "_openbolt"
        end
    },
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
    {
        PrintName = "RECIEVER",
        Category = {"cb_stkb_fullauto"},
        Bone = "wpn_body",
        Pos = Vector(0, 40, 1),
        Ang = Angle(0, -90, 0)
    },
}