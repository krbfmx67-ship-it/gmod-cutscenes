AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - SMGs"

SWEP.PrintName = "MP-40"

SWEP.Class = "Submachine Gun"

SWEP.Trivia = {
    Manufacturer = "Erma Werke",
    Calibre = "9x19MM",
    Mechanism = "Straight Blow Back",
    Origin = "Nazi Germany",
    Year = "1940"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The MP-40 is a Open bolt Submachine gun used by Tankers, Squad leaders and Officers to provide extra firepower to the squad or crew
It has a folding stock allowing for the weapon to be more portable and compact]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_mp40.mdl"
SWEP.WorldModel = "models/weapons/w_rif_ak47.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-9, 3.5, -7),
    TPIKPos = Vector(-7, 4, -6),
    Ang = Angle(-10, 0, 170),
    Scale = 1,
    
    TPIKPosSightOffset = Vector(-2, 1, -1),
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "0000000000000000000000"
SWEP.DefaultSkin = 0

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(129, 201, 115) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 45 -- Damage done at point blank range
SWEP.DamageMin = 25 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 7000

SWEP.ImpactForce = 6 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 11 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2250 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "smg1" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 32 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.SprintCancelsReload = true
SWEP.BashCancelsReload = true

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 500

SWEP.Firemodes = {
    {
        Mode = -1,
    },
}

-------------------------- RECOIL

SWEP.Recoil = 2.1

SWEP.RecoilUp = 0.3 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.3 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.3
SWEP.RecoilRandomSide = 0.4

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 15

SWEP.RecoilAutoControl = 2

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 0.2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.1 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 10, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

--SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 150 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default


-------------------------- SPREAD

SWEP.Spread = 0.01 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.2
SWEP.SwayMultSights = 0.4
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.35 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.35 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.96

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/ger/mp40/"
local handling = "/comradebear/wpn/ger/mp40/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "comradebear/wpn/ger/mp40/mp40_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/mp40/mp40_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/stg44/handling/stg44_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.SMGZoomin
SWEP.ExitSightsSound = CB.SMGZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_1" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/9x19.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.44, -1.1, 1.4),
    Ang = Angle(0, 0.35, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(15, 30, 8)
SWEP.CustomizeRotateAnchor = Vector(15, -3.01, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
	["idle_empty"] = { Source = "base_idle_empty" },
    ["fire"] = { Mult = 0.9, Source = {
        "base_shoot"
    },
    EventTable = {
        {s = handling .. "mp40_hifi.wav",        t = 0 / 32, v = .5}
    } },
    ["fire_iron"] = { Mult = 0.9, Source = {
        "base_shoot_iron"
    },
    EventTable = {
        {s = handling .. "mp40_hifi.wav",        t = 0 / 32, v = 1}
    } },
    ["fire_empty"] = { Mult = 0.9, Source = {
        "base_shoot_last",
    },
    EventTable = {
        {s = handling .. "mp40_hifi.wav",        t = 0 / 32, v = .5}
    } },
    ["fire_iron_empty"] = { Mult = 0.9, Source = {
        "base_shoot_iron_last",
    },
    EventTable = {
        {s = handling .. "mp40_hifi.wav",        t = 0 / 32, v = 1}
    }
    },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.6, Mult = 0.9, EventTable = {
            {s = handling .. "mp40_magout.wav",        t = 15 / 32, v = 125, c = ci},
            {s = handling .. "mp40_magin.wav",         t = 40 / 32, v = 125, c = ci},
    } },
    ["reload_empty"] = { Source = "base_reload_empty", MinProgress = 0.8, Mult = 1.1, EventTable = {
            {s = handling .. "mp40_bolt_back.wav",        t = 15 / 37, c = ci},
            {s = handling .. "mp40_magout.wav",        t = 45 / 37, c = ci},
            {s = handling .. "mp40_magin.wav",        t = 75 / 37, c = ci},
            {s = handling .. "mp40_bolt_forward.wav",        t = 100 / 37, c = ci},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["firemode"] = { Source = "base_firemode" },
    ["firemode_iron"] = { Source = "iron_fireselect" },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/stg44/weapon_stg_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {1, 1}
        }
    },
    ["doi_perk_stock"] = {
        Bodygroups = {
            {2, 1}
        }
    }
}

SWEP.Attachments = {
}