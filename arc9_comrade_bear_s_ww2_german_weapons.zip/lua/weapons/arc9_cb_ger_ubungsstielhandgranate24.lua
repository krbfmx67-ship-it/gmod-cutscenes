AddCSLuaFile()

SWEP.Base = "arc9_base_nade"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Explosives"

SWEP.PrintName = "Übungs-Stielhandgranate Model 24 Trainig Grenade [Placeholder]"

SWEP.Class = "Grenade"

SWEP.Trivia = {
    Manufacturer = "Richard Rinker GmbH and Others.",
    Mechanism = "Pull cord Fuze",
    Origin = "Nazi Germany",
    Year = "1939"
}

SWEP.Credits = {
    Author = "Arctic",
    Assets = "New World Interactive",
}

SWEP.Description = [[A training or dummy version of the Stielhandgranate Model 24 grenade, When pulling the fuze cord, Will light a 4.5 second delayed fuse
in which will ignite a loud blank.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_ubungsstielhandgranate24.mdl"
SWEP.WorldModel = "models/weapons/comradebear/ww2/w_ubungsstielhandgranate24.mdl"

SWEP.Slot = 4

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-12, 4, -7),
    Ang = Angle(0, -0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.NoTPIK = false

SWEP.EntitySelectIcon = false

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "doi_nade_cb_ubungsstielhandgranate24" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 100
SWEP.ShootEntInheritPlayerVelocity = true

SWEP.Throwable = true
SWEP.Tossable = true
SWEP.ThrowAnimSpeed = 1

SWEP.FuseTimer = -1

SWEP.ThrowForceMin = 400
SWEP.ThrowForceMax = 1500
SWEP.TossForce = 350

SWEP.ThrowChargeTime = 3

SWEP.ThrowTumble = false

-------------------------- MAGAZINE

SWEP.Ammo = "grenade" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 0 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.
SWEP.SecondarySupplyLimit = 0 -- Amount of reserve UBGL magazines you can take.

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "THROW"
        -- add other attachment modifiers
    },
}

-------------------------- HANDLING

SWEP.FreeAimRadius = 0

SWEP.SprintToFireTime = 0.15 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 1
SWEP.SpeedMultCrouch = 1
SWEP.SpeedMultBlindFire = 1

SWEP.ShootWhileSprint = true

-------------------------- POSITIONS

SWEP.HasSights = false

SWEP.SprintAng = Angle(0, -45, 0)
SWEP.SprintPos = Vector(0, 0, 0)

SWEP.ViewModelFOVBase = 55
SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.CrouchPos = Vector(0, 0, -1)
SWEP.CrouchAng = Angle(0, 0, 0)

SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(16, 50, 5.5)
SWEP.CustomizeRotateAnchor = Vector(15.5, -5, -5)

SWEP.CustomizeSnapshotFOV = 45
SWEP.CustomizeSnapshotPos = Vector(0, 0, -0)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

-------------------------- HoldTypes

SWEP.HoldType = "rpg"
SWEP.HoldTypeSprint = "normal"
SWEP.HoldTypeHolstered = "slam"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_PISTOL
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_PISTOL
SWEP.AnimDraw = false

-------------------------- SOUNDS

local path2 = "comradebear/wpn/generic/explosives/"

local throw = {
    path2 .. "gen_grenade_throw_1.wav",
    path2 .. "gen_grenade_throw_2.wav",
    path2 .. "gen_grenade_throw_3.wav",
    path2 .. "gen_grenade_throw_4.wav",
}

local lowthrow = {
    path2 .. "gen_grenade_underthrow_1.wav",
    path2 .. "gen_grenade_underthrow_2.wav",
    path2 .. "gen_grenade_underthrow_3.wav",
}

SWEP.Animations = {
    ["idle"] = {
        Source = "idle"
    },
    ["idle_primed"] = {
        Source = "bakethrow",
        Mult = math.huge
    },
    ["idle_primed_toss"] = {
        Source = "lowthrow",
        Mult = math.huge
    },
    ["draw"] = {
        Source = "draw",
        EventTable = {
            {s = CB.Deploy, t = 0}
        }
    },
    ["holster"] = {
        Source = "holster",
        EventTable = {
            {s = CB.Deploy, t = 0}
        }
    },
    ["pullpin"] = {
        Source = "pullbackhigh",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = path2 .. "m24_screwcap.wav", t = 10 / 38.2},
            {s = path2 .. "m24_capoff.wav", t = 25 / 38.2},
            {s = CB.Foley, t = 30 / 38.2}
        }
    },
    ["pullpin_toss"] = {
        Source = "pullbacklow",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = path2 .. "m24_screwcap.wav", t = 10 / 38.2},
            {s = path2 .. "m24_capoff.wav", t = 15 / 38.2},
            {s = CB.Foley, t = 18 / 38.2}
        }
    },
    ["throw"] = {
        Source = "throw",
        MinProgress = 0.8,
        EventTable = {
            {s = path2 .. "m24_fuse_start.wav", t = 12 / 38.2},
            {s = throw, t = 23 / 38.2},
        }
    },
    ["toss"] = {
        Source = "lowthrow",
        MinProgress = 0.8,
        EventTable = {
            {s = path2 .. "m24_fuse_start.wav", t = 12 / 38.2},
            {s = lowthrow, t = 23 / 38.2},
        }
    },
}

function SWEP:Hook_GrenadeThrown(data)
    -- Add a 1.5 second delay before the grenade is spawned and thrown
    data.delay = 0.8

    -- Optional: You can also modify force if you want
    -- data.force = data.force * 0.8
end