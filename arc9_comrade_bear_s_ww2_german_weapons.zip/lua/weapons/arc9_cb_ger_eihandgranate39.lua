AddCSLuaFile()

SWEP.Base = "arc9_base_nade"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Explosives"

SWEP.PrintName = "Eihandgranate Model 39 Grenade"

SWEP.Class = "Grenade"

SWEP.Trivia = {
    Manufacturer = "Richard Rinker GmbH and Others.",
    Mechanism = "Pull cord Fuze",
    Origin = "Nazi Germany",
    Year = "1939"
}

SWEP.Credits = {
    Authors = "Comrade Bear, William",
    Animations = "Comrade Bear",
    Assets = "William",
}

SWEP.Description = [[Despite popular belief that the Stielhandgranate Model 24 made up the majority of the hand grenades used by the Germans, 
The Eihandgranate Model 39 was among Germany's most mass produced and used hand grenade of the war, 
Though the Stielhandgranate Model 24 was among the most iconic hand grenades, The Eihandgranate Model 39 was simply cheaper to produce and easier to use.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_eihandgranate39.mdl"
SWEP.WorldModel = "models/weapons/comradebear/ww2/w_eihandgranate39.mdl"

SWEP.Slot = 4

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-12, 5, -5),
    Ang = Angle(0, -0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.NoTPIK = false

SWEP.EntitySelectIcon = false

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "doi_nade_cb_eihandgranate39" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 5000
SWEP.ShootEntInheritPlayerVelocity = true

SWEP.Throwable = true
SWEP.Tossable = true
SWEP.ThrowAnimSpeed = 1

SWEP.FuseTimer = -1

SWEP.ThrowForceMin = 350
SWEP.ThrowForceMax = 1250
SWEP.TossForce = 275

SWEP.ThrowChargeTime = 3

SWEP.ThrowTumble = false

-------------------------- MAGAZINE

SWEP.Ammo = "grenade" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 1 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.
SWEP.SecondarySupplyLimit = 0 -- Amount of reserve UBGL magazines you can take.

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "THROW"
        -- add other attachment modifiers
    },
}

-------------------------- HANDLING

SWEP.FreeAimRadius = 0

SWEP.SprintToFireTime = 0.15 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 1
SWEP.SpeedMultCrouch = 1
SWEP.SpeedMultBlindFire = 1

SWEP.ShootWhileSprint = true

SWEP.DefaultBodygroups = "0000000000000000000000"

-------------------------- POSITIONS

SWEP.HasSights = false

SWEP.SprintAng = Angle(0, -45, 0)
SWEP.SprintPos = Vector(0, 0, 0)

SWEP.ViewModelFOVBase = 55
SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.CrouchPos = Vector(0, 0, -1)
SWEP.CrouchAng = Angle(0, 0, 0)

SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(17.8, 40, 6.3)
SWEP.CustomizeRotateAnchor = Vector(17.8, -2, -6)

SWEP.CustomizeSnapshotFOV = 30
SWEP.CustomizeSnapshotPos = Vector(0, 0, -0)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

-------------------------- HoldTypes

SWEP.HoldType = "rpg"
SWEP.HoldTypeSprint = "normal"
SWEP.HoldTypeHolstered = "slam"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_PISTOL
SWEP.AnimDraw = false

-------------------------- SOUNDS

local path2 = "comradebear/wpn/generic/explosives/"

local throw = {
    path2 .. "gen_grenade_throw_1.wav",
    path2 .. "gen_grenade_throw_2.wav",
    path2 .. "gen_grenade_throw_3.wav",
    path2 .. "gen_grenade_throw_4.wav",
}

local lowthrow = {
    path2 .. "gen_grenade_underthrow_1.wav",
    path2 .. "gen_grenade_underthrow_2.wav",
    path2 .. "gen_grenade_underthrow_3.wav",
}

SWEP.Animations = {
    ["idle"] = {
        Source = "base_idle"
    },
    ["idle_primed"] = {
        Source = "bakethrow",
        Mult = math.huge
    },
    ["idle_primed_toss"] = {
        Source = "lowthrow",
        Mult = math.huge
    },
    ["draw"] = {
        Source = "base_draw",
        EventTable = {
            {s = CB.Foley, t = 0}
        }
    },
    ["holster"] = {
        Source = "base_holster",
        EventTable = {
            {s = CB.Foley, t = 0}
        }
    },
    ["pullpin"] = {
        Source = "pullbackhigh",
        MinProgress = 1,
        FireASAP = true,
        Mult = 0.7,
        EventTable = {
            {s = path2 .. "m24_screwcap.wav", t = 10 / 38.2},
            {s = CB.Deploy, t = 50 / 38.2}
        }
    },
    ["pullpin_toss"] = {
        Source = "pullbacklow",
        MinProgress = 1,
        FireASAP = true,
        Mult = 0.7,
        EventTable = {
            {s = path2 .. "m24_screwcap.wav", t = 10 / 38.2},
            {s = path2 .. "m24_capoff.wav", t = 15 / 38.2},
            {s = CB.Deploy, t = 18 / 38.2},
            {ind = 1, bg = 1, t = 0}
        }
    },
    ["throw"] = {
        Source = "throw",
        MinProgress = 0.8,
        EventTable = {
            {s = CB.Foley, t = 0 / 38.2},
            {s = path2 .. "m24_fuse_start.wav", t = 3 / 38.2},
            {s = throw, t = 15 / 38.2},
        }
    },
    ["toss"] = {
        Source = "throwlow",
        MinProgress = 0.8,
        EventTable = {
            {s = CB.Foley, t = 0 / 38.2},
            {s = path2 .. "m24_fuse_start.wav", t = 3 / 38.2},
            {s = lowthrow, t = 15 / 38.2},
        }
    },
}