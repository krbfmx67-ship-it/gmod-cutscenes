AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Anti-Tank"

SWEP.PrintName = "Panzerfaust 30 Klein"

SWEP.Class = "Disposable Anti-Tank Launcher"

SWEP.Trivia = {
    Manufacturer = "Werk Schlieben",
    Calibre = "43MM",
    Mechanism = "Striker fired, Rocket Propelled",
    Origin = "Germany",
    Year = "1943"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "Comrade Bear",
}

SWEP.Description = [[Among one of the first iterations of the Panzerfaust line of anti-tank weapons.
The Panzerfaust 30 series, much like their later counterparts that would be known as the Panzerfast 60 and 100, etc.
These used a older and more complicated firing system.

This weapon series came in two different versions, Klein(Small) and Gross(Big), The Klein warhead can penetrate up to 140MM of RHA while the Gross
could penetrate up to 200MM of RHA.

The Panzerfaust 30 Requires a few steps before the weapon can be utilized, Unlike the newer models which would redesign this firing mechanism and sight post,
along with using the Gross version of warheads. Although heavier, they achieve higher penetrative power than that of the smaller Klein warheads.
]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_panzerfaust_klein.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 75

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-14, 3.5, -4),
    TPIKPos = Vector(-14, 4, -4),
    TPIKAng = Angle(-10, -5, -180),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(10, -2, -2),
    Scale = 1,

    TPIKPosSightOffset = Vector(5, 3, -2), -- ironsights offset, disable NoTPIKVMPos
}
SWEP.NoTPIKVMPos = true
SWEP.TPIKnolefthand = false

SWEP.DefaultSkin = 0

-------------------------- TRACERS

SWEP.NeverPhysBullet = false

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(113, 207, 128) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 25 -- Damage done at point blank range
SWEP.DamageMin = 15 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 3700

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 3.5,
    [HITGROUP_CHEST] = 1.55,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1150 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 50

SWEP.Firemodes = {
    {
        Mode = 1,
    },
}

SWEP.Disposable = true
SWEP.BottomlessClip = false
SWEP.ReloadInSights = false

SWEP.DoFireAnimation = false -- own correct anim later
SWEP.Throwable = true -- throwable but overriding throwable stuff
SWEP.NoFireDuringSighting = true

SWEP.ShotgunReload = false
SWEP.HybridReload = false
SWEP.FiremodeAnimLock = true

-------------------------- RECOIL

SWEP.Recoil = 2

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 1 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.1
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 2 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 0.2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.1 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 15 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2.5, 20, 5) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.2 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 5
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 1
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 70 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 4
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.25
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.28 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.28 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/panzerfaust/panzerfaust_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/panzerfaust/panzerfaust_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/ger/panzerfaust/panzerfaust_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/ger/panzerfaust/panzerfaust_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/p08/handling/p08_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.PistolZoomIn
SWEP.ExitSightsSound = CB.PistolZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "ins_weapon_rpg_frontblast" -- Used for some muzzle effects.

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/36mm_signal_shell.mdl"
SWEP.ShellScale = 1.3
SWEP.NoShellEject = true
SWEP.ShellVelocity = 0.4
SWEP.ShellCorrectAng = Angle(0, 0, 90)

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 4
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "cb_signalflare_red" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 3500
SWEP.ShootEntInheritPlayerVelocity = false -- Set to true to inherit velocity
SWEP.ShootEntInheritPlayerVelocityLimit = 0 -- Upper limit of velocity to inherit. 0 - no limit.
SWEP.ShootEntData = {} -- Extra data that can be given to a projectile. Sets ENT.ShootEntData with this table.

SWEP.ShouldDropMag = false
SWEP.ShouldDropMagEmpty = false

local handling = "comradebear/wpn/ger/panzerfaust/handling/"

SWEP.DropMagazineModel = "models/weapons/comradebear/ww2/spent_panzerfaust30klein.mdl" -- Set to a string or table to drop this magazine when reloading.
SWEP.DropMagazineSounds = {handling .. "panzerfaust_impact1.wav",handling .. "panzerfaust_impact2.wav",handling .. "panzerfaust_impact3.wav",handling .. "panzerfaust_impact4.wav",handling .. "panzerfaust_impact5.wav",} -- Table of sounds a dropped magazine should play.
SWEP.DropMagazineAmount = 1 -- Amount of mags to drop.
SWEP.DropMagazineSkin = 0 -- Model skin of mag.
SWEP.DropMagazineTime = 0
SWEP.DropMagazineQCA = 3 -- QC Attachment drop mag from, would drop from shell port if not defined
SWEP.DropMagazinePos = Vector(0, 0, 0) -- offsets
SWEP.DropMagazineAng = Angle(90, 90, 90)
SWEP.DropMagazineVelocity = Vector(60, -0, -0) -- Put something here if your anim throws the mag with force
SWEP.DropMagazineEffect = "arc9_magdropeffect"

SWEP.AutoReload = false

SWEP.BulletBones = {
    [0] = "warhead",
    [1] = "warhead",
}
-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-3.245, -0, -3.3),
    Ang = Angle(0, 11, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(15, -2, -12)
SWEP.RestAng = Angle(75, 15, 25)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(8.5, 31, 7)

SWEP.CustomizeRotateAnchor = Vector(22, -4, -4)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

SWEP.AimDownSightsTime = 0.8

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "passive"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "rpg"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.ReloadHideBoneTables = { -- works only with TPIK
    [1] = {"warhead", "backblast_cap"},
    [2] = {"warhead", "wpn_body", "sight", "backblast_cap", "pin", "pin_loop", "cocking_mech", "firing_pin", "trigger"},
    -- [2] = {"list", "of", "bones"}
}

SWEP.HideBones = {"pin", "pin_loop"}

local path = "weapons/arc9_doi/p08/handling/p08_"
local handling = "comradebear/wpn/ger/panzerfaust/handling/"
local gen_exp = "comradebear/wpn/generic/explosives/"

local panzerfaust_deploy = {
    handling .. "panzerfaust_deploy1.wav",
    handling .. "panzerfaust_deploy2.wav",
    handling .. "panzerfaust_deploy3.wav",
}

local panzerfaust_sight = {
    handling .. "panzerfaust_flipsight1.wav",
    handling .. "panzerfaust_flipsight2.wav",
    handling .. "panzerfaust_flipsight3.wav",
}

local gren_pin_pull = {
    gen_exp .. "mk2_pullpin_01.wav",
    gen_exp .. "mk2_pullpin_02.wav",
    gen_exp .. "mk2_pullpin_03.wav",
    gen_exp .. "mk2_pullpin_04.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_iron"] = { Source = "base_idle_iron" },
    ["idle_iron_empty"] = { Source = "base_idle_empty_iron" },
    ["fire"] = { Source = "base_shoot_alt",  Mult = 1, MinProgress = 1, DropMagAt = 30 / 30, EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 30, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
        {hide = 1, t = 1 / 30},
        {hide = 2, t = 30 / 30},
    } },
    ["fire_iron"] = { Source = "base_shoot_iron",  Mult = 0.8, MinProgress = 1, DropMagAt = 32 / 30, EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 30, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
        {hide = 1, t = 1 / 30},
        {hide = 2, t = 32 / 30},
    } },
    ["enter_sights"] = { Source = "base_sight_in",  Mult = 1, },
    ["exit_sights"] = { Source = "base_sight_in",  Mult = 1, Reverse = true, },
    ["enter_sights_empty"] = { Source = "base_sight_in" },
    ["fire_iron_empty"] = { Source = "base_shoot_iron" },
    ["draw"] = { Source = "base_draw",  Mult = 0.9, EventTable = {
        {s = handling .. "panzerfaust_safety.wav",        t = 20 / 30, c = ci},

        {t = 0, s = CB.PistolDraw},
    } },
    ["ready"] = { Source = "base_ready",  Mult = 1.2, EventTable = {
        {s = panzerfaust_deploy,        t = 0 / 30, c = ci},
        {s = gren_pin_pull,        t = 35 / 30, c = ci},
        {s = panzerfaust_sight,        t = 50 / 30, c = ci},
        {s = handling .. "panzerfaust_cocking.wav",        t = 90 / 30, c = ci},
        {s = handling .. "panzerfaust_safety.wav",        t = 120 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
    } },
    ["reload"] = { Source = "base_draw",  Mult = 0.9, EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 35, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
    } },
    ["reload_empty"] = { Source = "base_draw",  Mult = 0.9, EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 30, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster"] = { Source = "base_holster",  Mult = 0.8, EventTable = {
        {s = handling .. "panzerfaust_safety.wav",        t = 12 / 30, c = ci},
        {t = 5 / 30, s = CB.PistolHolster},
    } },
    ["draw_empty"] = { Source = "base_draw", Mult = 0.9, EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", Mult = 0.8, EventTable = {
        {t = 0 / 30, s = CB.PistolHolster},
    } },
}

SWEP.InstantSprintIdle = true

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasAmmoInClip() then
        mdl:SetSkin(0)
    else
        mdl:SetSkin(1)
    end
end

SWEP.DefaultBodygroups = "00000000"

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/c96/weapon_c96_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
}

SWEP.Attachments = {
}

--[[SWEP.Hook_TranslateAnimation = function(self, anim)
    -- We're only customizing the 'cycle' animation
    if anim == "firemode" then
        local firemode = self:GetFiremode()
        return "firemode_" .. firemode
    end

    if anim == "reload" then
        local firemode = self:GetFiremode()
        return "reload_empty_" .. firemode
    end

    -- Default behavior for other animations
    return anim
end]]

--[[function SWEP:IsPlayingFiremodeAnim()
    local owner = self:GetOwner()
    if not IsValid(owner) then return false end

    local vm = owner:GetViewModel()
    if not IsValid(vm) then return false end

    local seq = vm:GetSequence()
    local seqName = vm:GetSequenceName(seq)
    if not seqName then return false end

    -- Match your firemode animation names
    return string.find(seqName, "base_switch_ammo_signal") 
        or string.find(seqName, "base_switch_ammo")
end]]

local singleusebehaviour = GetConVar("arc9_eft_singleuse_behaviour")

function SWEP:ThinkGrenade()
    local owner = self:GetOwner()

	if self:GetSafe() and owner:KeyPressed(IN_ATTACK) then self:ToggleSafety(false) return end
    
    if self:GetAnimLockTime() > CurTime() then return end

    if !self:GetGrenadePrimed() then
        if self:GetGrenadeRecovering() then
            if (self:GetProcessedValue("Disposable", true) and !self:HasAmmoInClip()) and SERVER then
                self:Remove()
                owner:ConCommand("lastinv") -- switch to prev weapon
            else
                self:PlayAnimation("draw", 1, true)
                self:SetGrenadeRecovering(false)
            end
        elseif owner:KeyDown(IN_ATTACK) and self:HasAmmoInClip() and (!owner:KeyDown(IN_USE) or !self:GetProcessedValue("PrimaryBash", true)) then
            self:SetGrenadePrimed(true)
            self:SetGrenadePrimedTime(CurTime())
        end
    else
        if owner:KeyDown(IN_ATTACK) and self:HasAmmoInClip() and (!owner:KeyDown(IN_USE) or !self:GetProcessedValue("PrimaryBash", true)) and !self:StillWaiting() then
            self:DoPrimaryAttack()
            
        end

        self:SetGrenadeRecovering(true)
    end
end


SWEP.Hook_PrimaryAttack = function(self)
    self:PlayAnimation("fire", 1, true, true)
    
    self:SetGrenadePrimed(false)

    -- self:ExitSights() -- sights out anim too bad


    -- backblast
    local owner = self:GetOwner()

    if IsValid(owner) and owner:IsPlayer() then
        local tr = util.TraceLine( {
            start = owner:EyePos(),
            endpos = owner:EyePos() + owner:EyeAngles():Forward() * -64,
            filter = owner
        } )

        debugoverlay.Line(owner:EyePos(), tr.HitPos)
        if tr.Hit then
            timer.Simple(0, function() 
                local d = DamageInfo()
                d:SetDamage( 105 )
                d:SetAttacker( owner )
                d:SetDamageType( DMG_SLOWBURN ) 

                owner:TakeDamageInfo( d )

                if IsValid(tr.Entity) and (tr.Entity:IsNPC() or tr.Entity:IsPlayer() or tr.Entity:IsNextBot()) then
                    tr.Entity:TakeDamageInfo( d )
                end
            end)

            ParticleEffect( "m79_smoke_e", tr.HitPos, Angle( 0, 0, 0 ) )
        end
    end

    local muzzle = self:GetOwner():GetViewModel():GetAttachment(3)
    local muzzle2 = self:GetAttachment(self:GetQCAMuzzle())

    local vm = self:GetOwner():GetViewModel()
    if not IsValid(vm) then return end

    local boneIndex = vm:LookupBone("backblast") -- e.g. "ValveBiped.Wep_Bone"
    if not boneIndex then return end

    local pos, ang = vm:GetBonePosition(boneIndex)

    -- second muzzleflash
    local data = EffectData()
    data:SetEntity(self)
    data:SetAttachment(1)
    data:SetSurfaceProp(1)

    local muzzle = "arc9_muzzleeffect"

    ParticleEffect( "ins_weapon_rpg_backblast", pos + Vector(0, 0, 60), ang)
end

function SWEP:DoProjectileAttack(pos, ang, spread)
    if SERVER then

        local owner = self:GetOwner()

        --local localOffset = Vector(50, -4, -5)
        local localOffset = Vector(40, -0, -3)

        local src = LocalToWorld(localOffset, Angle(0,0,0), pos, ang)

        local bullet = {}
        bullet.Src = src
        bullet.Dir = owner:EyeAngles():Forward()
        bullet.Spread = Vector(0, 0, 0)
		bullet.Force	= 140 * 102
		bullet.HullSize 	= 5
		bullet.Damage	= 700
		bullet.SplashDamage = 200
		bullet.SplashDamageRadius = 150
		bullet.SplashDamageEffect = "lvs_bullet_impact_panzerwurfkorper42"
		bullet.SplashDamageType = DMG_BLAST
		bullet.Velocity = 65 / 0.01905
		bullet.TracerName = "lvs_tracer_panzerfaust30_klein"
        bullet.Attacker = owner
        bullet.EnableBallistics = true
        bullet.Entity = owner

        --debugoverlay.Cross(src, 100, 10, Color(255, 0, 0), true)

        LVS:FireBullet(bullet)
    end
end

--[[SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end

    local firemode = self:GetFiremode()

    --print(firemode)
    local vm = owner:GetViewModel(0)

    if firemode == 1 then
        timer.Simple(2, function()
            vm:SetBodygroup(1, 0) 
        end)
    else
        timer.Simple(2, function()
            vm:SetBodygroup(1, 1) 
        end)
    end
    -- Check if the weapon is reloading
    if self:GetReloading() or self:IsPlayingFiremodeAnim() then
        -- If HoldType isn't already changed, set it to the desired reload type
        if not self.ReloadingHoldTypeSet then
            self.OriginalHoldType = self.OriginalHoldType or self.HoldType
            self:SetHoldType("revolver") -- Replace with the desired reload hold type
            self.ReloadingHoldTypeSet = true
            self.TPIKnolefthand = false
        end
    else
        -- If reloading is finished, reset HoldType to the original
        if self.ReloadingHoldTypeSet then
            self:SetHoldType(self.OriginalHoldType)
            self.ReloadingHoldTypeSet = false
        end
    end
end]]