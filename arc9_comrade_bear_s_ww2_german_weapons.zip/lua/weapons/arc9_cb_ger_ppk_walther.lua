AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear"
SWEP.SubCategory = "German - Pistols"

SWEP.PrintName = "Walther PPK"

SWEP.Class = "Pistol"

SWEP.Trivia = {
    Manufacturer = "Walther",
    Calibre = ".32 ACP",
    Mechanism = "Blowback",
    Origin = "Germany",
    Year = "1938"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Walther PPK (Polizei Pistole Kriminal) was a pistol designed by Carl Walther designed as a compact, easily concealable pistol for the Kriminalpolizei in the early 1930s.
It was primarily chambered in 32 ACP.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_waltherppk.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 75

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-14, 3.5, -4),
    TPIKPos = Vector(-16, 4, -4),
    TPIKAng = Angle(-10, -5, -180),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(10, -4, 0),
    Scale = 1,

    TPIKPosSightOffset = Vector(1, 4, -4), -- ironsights offset, disable NoTPIKVMPos
}
SWEP.NoTPIKVMPos = true
SWEP.TPIKnolefthand = true

SWEP.DefaultSkin = 0

-------------------------- TRACERS

SWEP.NeverPhysBullet = false

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(113, 207, 128) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 25 -- Damage done at point blank range
SWEP.DamageMin = 15 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 3700

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 4.2,
    [HITGROUP_CHEST] = 1.55,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1150 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = 1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 7 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 300

SWEP.Firemodes = {
    {
        Mode = 1,
    }
}

SWEP.ShotgunReload = false
SWEP.HybridReload = false

-------------------------- RECOIL

SWEP.Recoil = 1

SWEP.RecoilUp = 0.55 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.15 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.3
SWEP.RecoilRandomSide = 0.4

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.3 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 4, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 2 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 1

-- SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 120 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.25
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.28 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.28 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 110
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/ger/waltherppk/ppk_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/ger/waltherppk/ppk_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/p08/handling/p08_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.PistolZoomIn
SWEP.ExitSightsSound = CB.PistolZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol_red" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/9x19.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 3
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-1.95, -1, 1.5),
    Ang = Angle(0, 0.0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(4, -2, -15)
SWEP.RestAng = Angle(7, 60, -2)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(16, 20, 3.5)

SWEP.CustomizeRotateAnchor = Vector(16, -2, -4)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "pistol"
SWEP.HoldTypeSprint = "pistol"
SWEP.HoldTypeHolstered = "normal"
SWEP.HoldTypeSights = "pistol"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/p08/handling/p08_"
local handling = ")comradebear/wpn/ger/waltherppk/handling/"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_iron"] = { Source = "iron_idle" },
    ["idle_iron_emtpty"] = { Source = "iron_empty" },
    ["fire"] = { Source = {
        "base_shoot",
    } },
    ["fire_empty"] = { Source = "base_shoot_last" },
    ["fire_iron"] = { Source = {
        "base_shoot_iron",
    } },
    ["enter_sights"] = { Source = "iron_idle" },
    ["enter_sights_empty"] = { Source = "iron_empty" },
    ["fire_iron_empty"] = { Source = "base_shoot_iron_last" },
    ["dryfire"] = { Source = "empty_idle" },
    ["dryfire_iron"] = { Source = "empty_idle" },
    ["bash"] = { Source = "base_melee_bash" },
    ["bash_empty"] = { Source = "empty_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.9,  EventTable = {
        {s = handling .. "magout.wav",        t = 20 / 30, c = ci},
        {s = handling .. "magin.wav",        t = 65 / 30, c = ci},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.8, EventTable = {
        {s = handling .. "magout.wav",        t = 20 / 30, c = ci},
        {s = handling .. "magin.wav",        t = 65 / 30, c = ci},
        {s = handling .. "slide_back.wav",        t = 100 / 30, c = ci},
        {s = handling .. "slide_release.wav",        t = 110 / 30, c = ci},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {s = handling .. "safety.wav",        t = 15 / 30, c = ci},
        {s = handling .. "cock.wav",        t = 25 / 30, c = ci},
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {s = handling .. "decock.wav",        t = 10 / 30, c = ci},
        {t = 5 / 30, s = CB.PistolHolster},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 5 / 30, s = CB.PistolHolster},
    } },
    ["inspect"] = { Source = "base_inspect" },
    ["inspect_empty"] = { Source = "base_inspect_empty" },
}

SWEP.InstantSprintIdle = true

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/c96/weapon_c96_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
}

SWEP.Attachments = {
}
SWEP.Hook_Think = function(self)
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Check if the weapon is reloading
    if self:GetReloading() then
        -- If HoldType isn't already changed, set it to the desired reload type
        if not self.ReloadingHoldTypeSet then
            self.OriginalHoldType = self.OriginalHoldType or self.HoldType
            self:SetHoldType("revolver") -- Replace with the desired reload hold type
            self.ReloadingHoldTypeSet = true
        end
    else
        -- If reloading is finished, reset HoldType to the original
        if self.ReloadingHoldTypeSet then
            self:SetHoldType(self.OriginalHoldType)
            self.ReloadingHoldTypeSet = false
        end
    end
end