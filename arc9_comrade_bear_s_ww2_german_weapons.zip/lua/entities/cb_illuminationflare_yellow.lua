AddCSLuaFile()

ENT.Type 				= "anim"
ENT.Base 				= "base_entity"
ENT.PrintName 			= "Base Projectile"

ENT.Spawnable 			= false
ENT.CollisionGroup = COLLISION_GROUP_PROJECTILE

ENT.Model = "models/Items/AR2_Grenade.mdl"
ENT.Ticks = 0
ENT.FuseTime = 0
ENT.Exploded = false
ENT.SphereSize = nil
ENT.PhysMat = "grenade"
ENT.SmokeTrail = false
ENT.SmokeTrailMat = "trails/smoke"
ENT.SmokeTrailSize = 1
ENT.SmokeTrailTime = 0.2

-- Flare Stuff
ENT.Flare = true
ENT.FlareDuration = 20
ENT.FlareShouldDrag = true
ENT.FlareDampening = {0, 0}
ENT.FlareSpriteSize = 250
ENT.FlareColor = Color(224,192,83) -- Pick the main color of the Flare
ENT.FlareLightRadius = 600
ENT.FlareDragCoefficient = 1000

ENT.IsSignalFlare = false
ENT.SignalFlareLightRadius = 100

local signalflarepath = "comradebear/wpn/generic/flaregun/"

ENT.SignalFlareIgnite = {
    signalflarepath .. "signalflare_ignite_01.wav",
    signalflarepath .. "signalflare_ignite_02.wav",
    signalflarepath .. "signalflare_ignite_03.wav",
    signalflarepath .. "signalflare_ignite_04.wav",
    signalflarepath .. "signalflare_ignite_05.wav",
}

ENT.FlareSpriteSize = 400
ENT.FlareMat = Material("sprites/light_glow02_add") -- your flare texture

ENT.IsIllumination = true -- This gives our flare a projected texture pointed downwards; Illuminating the area with light!
ENT.IlluminationIntensity = 5 -- Brightness of our illumination
ENT.IlluminationRadius = 130 -- How wide our projected texture is(FOV more specifically)
ENT.IlluminationRange = 4000 -- How far our projected texture can go
ENT.IlluminationColor = Color(237,245,123) -- Pick the color for illumination projected texture

ENT.IlluminationIgnite = {
    signalflarepath .. "illumination_ignite_01.wav",
    signalflarepath .. "illumination_ignite_02.wav",
    signalflarepath .. "illumination_ignite_03.wav",
    signalflarepath .. "illumination_ignite_04.wav",
    signalflarepath .. "illumination_ignite_05.wav",
}

ENT.LifeTime = 1.5

ENT.Drag = true
ENT.Gravity = true
ENT.DragCoefficient = 0.25
ENT.Boost = 0
ENT.Lift = 0
ENT.GunshipWorkaround = true
ENT.HelicopterWorkaround = true

ENT.Damage = 150
ENT.Radius = 300
ENT.ImpactDamage = nil
ENT.ExplodeOnImpact = false

ENT.Scorch = true
ENT.ExplosionEffect = "explosion"

ENT.Dead = false
ENT.DieTime = 0
ENT.BounceSounds = {""}

ENT.SteerSpeed = 60 -- The maximum amount of degrees per second the missile can steer.
ENT.SeekerAngle = math.cos(35) -- The missile will lose tracking outside of this angle.
ENT.SuperSeeker = false
ENT.SACLOS = false -- This missile is manually guided by its shooter.
ENT.SemiActive = false -- This missile needs to be locked on to the target at all times.
ENT.FireAndForget = false -- This missile automatically tracks its target.
ENT.TopAttack = false -- This missile flies up above its target before going down in a top-attack trajectory.
ENT.TopAttackHeight = 5000
ENT.SuperSteerBoostTime = 5 -- Time given for this projectile to adjust its trajectory from top attack to direct
ENT.NoReacquire = false -- F&F target is permanently lost if it cannot reacquire

ENT.ShootEntData = {}

ENT.IsProjectile = true

ENT.LastHitNormal = Vector(0, 0, 0)

ENT.LoopingSound = nil
ENT.FlareDeployed = false



if CLIENT then
    local flaremat = Material("effects/arc9_lensflare")

    function ENT:Initialize()
        self.FlareActive = false
        self.Projector = nil

        self.SpawnTime = CurTime()
    end

    function ENT:OnRemove()
        if IsValid(self.Projector) then
            self.Projector:Remove()
            self.Projector = nil
        end
    end

    function ENT:Draw()
        self:DrawModel()

        -- Draw flare + light only when activated
        if self:GetNWBool("FlareActive", false) then

            if self.IsSignalFlare then

                FlareFadeInTime = self.FlareDuration / 3.5     -- time to grow to full size
                FlareLifeTime = self.FlareDuration / 2      -- how long it stays full-sized before shrinking
                FlareFadeOutTime = self.FlareDuration / 3.5     -- time to shrink back down

                local t = CurTime()
                local elapsed = t - self.SpawnTime
                local totalTime = self.DieTime - self.SpawnTime

                local sizeMul = 1

                -- grow
                    if elapsed < FlareFadeInTime then
                        sizeMul = Lerp(elapsed / FlareFadeInTime, 0, 1)

                -- shrink
                elseif elapsed > (FlareFadeInTime + FlareLifeTime) then
                    local fadeElapsed = elapsed - (FlareFadeInTime + FlareLifeTime)
                    sizeMul = Lerp(fadeElapsed / FlareFadeOutTime, 1, 0)
                end

                -- final size
                local size = self.FlareSpriteSize * sizeMul

                -- slight flicker
                size = size * math.Rand(0.95, 1.05)

                render.SetMaterial(flaremat)
                render.DrawSprite(self:GetPos(), size, size, self.FlareColor)
            end

            -- ✳️ Optional projected texture (only if entity is flagged)
            if self.IsIllumination then

            -- ✳️ Draw the sprite
            FlareFadeInTime = 2    -- time to grow to full size
                FlareLifeTime = self.FlareDuration - 2.5      -- how long it stays full-sized before shrinking
                FlareFadeOutTime = 4     -- time to shrink back down

                local t = CurTime()
                local elapsed = t - self.SpawnTime
                local totalTime = self.DieTime - self.SpawnTime

                local sizeMul = 1

                -- grow
                    if elapsed < FlareFadeInTime then
                        sizeMul = Lerp(elapsed / FlareFadeInTime, 0, 1)

                -- shrink
                elseif elapsed > (FlareFadeInTime + FlareLifeTime) then
                    local fadeElapsed = elapsed - (FlareFadeInTime + FlareLifeTime)
                    sizeMul = Lerp(fadeElapsed / FlareFadeOutTime, 1, 0)
                end

                -- final size
                local size = self.FlareSpriteSize * sizeMul

                -- slight flicker
                size = size * math.Rand(0.95, 1.05)

                render.SetMaterial(flaremat)
                render.DrawSprite(self:GetPos(), size, size, self.FlareColor)

                if not IsValid(self.Projector) then
                    local proj = ProjectedTexture()
                    if not proj then return end

                    proj:SetTexture("effects/flashlight001")
                    proj:SetFarZ(self.IlluminationRange)
                    proj:SetNearZ(8)
                    proj:SetFOV(self.IlluminationRadius)
                    proj:SetBrightness(self.IlluminationIntensity)
                    proj:SetColor(self.IlluminationColor)
                    proj:SetEnableShadows(false)
                    proj:Update()

                    self.Projector = proj
                end

                -- Update projector position + force down angle
                if IsValid(self.Projector) then
                    self.Projector:SetPos(self:GetPos() + Vector(0, 0, 10))
                    self.Projector:SetAngles(Angle(90, 0, 0)) -- always face downward
                    self.Projector:Update()
                end
            else
                -- Cleanup projector if not using it
                if IsValid(self.Projector) then
                    self.Projector:Remove()
                    self.Projector = nil
                end
            end
        else
            -- Turn off when flare inactive
            if IsValid(self.Projector) then
                self.Projector:Remove()
                self.Projector = nil
            end
        end
    end
end

if SERVER then
    local gunship = {["npc_combinegunship"] = true, ["npc_combinedropship"] = true}

    if ENT.IsSignalFlare then
        function ENT:CreateDynamicLight()
            if IsValid(self.DynamicLight) then self.DynamicLight:Remove() end

            local dyn = ents.Create("light_dynamic")
            if not IsValid(dyn) then return end

            local col = self.FlareColor
            local colStr = string.format("%d %d %d %d", col.r, col.g, col.b, col.a)

            dyn:SetPos(self:GetPos() + Vector(0, 0, 5))
            dyn:SetParent(self)
            dyn:SetKeyValue("distance", tostring(self.SignalFlareLightRadius))
            dyn:SetKeyValue("brightness", "3")
            dyn:SetKeyValue("style", "12")
            dyn:SetKeyValue("_light", colStr) -- Warm orange light
            dyn:Spawn()
            dyn:Activate()
            dyn:Fire("TurnOn", "", 0)

            self.DynamicLight = dyn
        end
    end

    if ENT.IsIllumination then
        function ENT:CreateDynamicLight()
            if IsValid(self.DynamicLight) then self.DynamicLight:Remove() end

            local dyn = ents.Create("light_dynamic")
            if not IsValid(dyn) then return end

            local col = self.FlareColor
            local colStr = string.format("%d %d %d %d", col.r, col.g, col.b, col.a)

            dyn:SetPos(self:GetPos() + Vector(0, 0, 5))
            dyn:SetParent(self)
            dyn:SetKeyValue("distance", tostring(self.FlareLightRadius))
            dyn:SetKeyValue("brightness", "3")
            dyn:SetKeyValue("style", "12")
            dyn:SetKeyValue("_light", colStr) -- Warm orange light
            dyn:Spawn()
            dyn:Activate()
            dyn:Fire("TurnOn", "", 0)

            self.DynamicLight = dyn
        end
    end

    function ENT:Initialize()
        self:SetModel(self.Model)
        if self.PhysBoxSize then
            self:PhysicsInitBox(-self.PhysBoxSize, self.PhysBoxSize)
        elseif self.SphereSize then
            self:PhysicsInitSphere(self.SphereSize, self.PhysMat)
        else
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
        end

        self.SpawnTime = CurTime()

        local phys = self:GetPhysicsObject()
        if phys:IsValid() then
            phys:Wake()
            phys:EnableDrag(self.Drag)
            phys:SetDragCoefficient(self.DragCoefficient)
            phys:EnableGravity(true)
            phys:SetMass(0)
            phys:SetBuoyancyRatio(0.4)
        end

        self.SpawnTime = CurTime()

        --print(self.FlareDeployed)

        if self.SmokeTrail then
            util.SpriteTrail(self, 0, Color( 255 , 255 , 255 ), false, self.SmokeTrailSize, 0, self.SmokeTrailTime, 1 / self.SmokeTrailSize * 0.5, self.SmokeTrailMat)
        end

        if self.LoopingSound then
            self.Sound = CreateSound(self, self.LoopingSound)
            self.Sound:Play()
        end
    end

    function ENT:OnRemove()
        if self.Sound then
            self.Sound:Stop()
        end
    end

    function ENT:Think()
        if self.Defused then return end

        --[[self.NextSpark = 0

        if self.NextSpark < CurTime() then
            local effectdata = EffectData()
            effectdata:SetOrigin(self:GetPos())
            effectdata:SetNormal(Vector(0,0,90))
            effectdata:SetMagnitude(3)
            effectdata:SetScale(0.5)
            effectdata:SetRadius(4)
            util.Effect("Sparks", effectdata, true, true)

            self.NextSpark = CurTime() + math.Rand(0.05, 0.15) -- how often sparks happen
        end]]

        ParticleEffectAttach("hd_flare_01_red_initial_sparks_03", PATTACH_POINT_FOLLOW, self, 0)

        timer.Create("FlareTimer", self.LifeTime, 0, function() self.FlareDeployed = true end)
        timer.Start("FlareTimer")

        if self.SpawnTime + self.LifeTime < CurTime() then
            self:Detonate()
            return
        end

        if self:WaterLevel() > 0 then
            self:Detonate()
            return
        end

        local drunk = false

        if self.FireAndForget or self.SemiActive then
            if self.SemiActive then
                if IsValid(self.Weapon) then
                    self.ShootEntData = self.Weapon:RunHook("Hook_GetShootEntData", {})
                end
            end

            if self.ShootEntData.Target and IsValid(self.ShootEntData.Target) then
                local target = self.ShootEntData.Target
                if target.UnTrackable then self.ShootEntData.Target = nil end

                -- if self.TopAttack then
                --     local tpos = target:GetPos() + Vector(0, 0, 5000)
                --     if self.SpawnTime + self.TopAttackTime - 1 < CurTime() or self.TopAttackReached then
                --         tpos = target:GetPos()
                --     end
                --     local dir = (tpos - self:GetPos()):GetNormalized()
                --     local dist = (tpos - self:GetPos()):Length()
                --     local ang = dir:Angle()

                --     local p = self:GetAngles().p
                --     local y = self:GetAngles().y

                --     p = math.ApproachAngle(p, ang.p, FrameTime() * self.SteerSpeed)
                --     y = math.ApproachAngle(y, ang.y, FrameTime() * self.SteerSpeed)

                --     self:SetAngles(Angle(p, y, 0))

                --     if dist <= 1024 then
                --         self.TopAttackReached = true
                --     end
                -- else
                local tpos = target:EyePos()
                if self.TopAttack and !self.TopAttackReached then
                    tpos = tpos + Vector(0, 0, self.TopAttackHeight)

                    local dist = (tpos - self:GetPos()):Length()

                    if dist <= 2000 then
                        self.TopAttackReached = true
                        self.SuperSteerTime = CurTime() + self.SuperSteerBoostTime
                    end
                end
                local dir = (tpos - self:GetPos()):GetNormalized()
                local dot = dir:Dot(self:GetAngles():Forward())
                local ang = dir:Angle()

                if self.SuperSeeker or dot >= self.SeekerAngle or !self.TopAttackReached or (self.SuperSteerTime and self.SuperSteerTime >= CurTime()) then
                    local p = self:GetAngles().p
                    local y = self:GetAngles().y

                    p = math.ApproachAngle(p, ang.p, FrameTime() * self.SteerSpeed)
                    y = math.ApproachAngle(y, ang.y, FrameTime() * self.SteerSpeed)

                    self:SetAngles(Angle(p, y, 0))
                    -- self:SetVelocity(dir * 15000)
                elseif self.NoReacquire then
                    self.ShootEntData.Target = nil
                    drunk = true
                end
                -- end
            else
                drunk = true
            end
        elseif self.SACLOS then
            if self:GetOwner():IsValid() then
                local tpos = self:GetOwner():GetEyeTrace().HitPos
                local dir = (tpos - self:GetPos()):GetNormalized()
                local dot = dir:Dot(self:GetAngles():Forward())
                local ang = dir:Angle()

                if dot >= self.SeekerAngle then
                    local p = self:GetAngles().p
                    local y = self:GetAngles().y

                    p = math.ApproachAngle(p, ang.p, FrameTime() * self.SteerSpeed)
                    y = math.ApproachAngle(y, ang.y, FrameTime() * self.SteerSpeed)

                    self:SetAngles(Angle(p, y, 0))
                else
                    drunk = true
                end
            else
                drunk = true
            end
        end

        if drunk then
            self:SetAngles(self:GetAngles() + (AngleRand() * FrameTime() * 1000 / 360))
        end

        self:GetPhysicsObject():AddVelocity(Vector(0, 0, self.Lift) + self:GetForward() * self.Boost)

        -- Gunships have no physics collection, periodically trace to try and blow up in their face
        if self.GunshipWorkaround and (self.GunshipCheck or 0 < CurTime()) then
            self.GunshipCheck = CurTime() + 0.33
            local tr = util.TraceLine({
                start = self:GetPos(),
                endpos = self:GetPos() + (self:GetVelocity() * 6 * engine.TickInterval()),
                filter = self,
                mask = MASK_SHOT
            })
            if IsValid(tr.Entity) and gunship[tr.Entity:GetClass()] then
                self:SetPos(tr.HitPos)
                self:Detonate()
            end
        end
    end

    function ENT:Detonate()
        if !self:IsValid() then return end
        if self.Defused then return end
        local effectdata = EffectData()
        effectdata:SetOrigin( self:GetPos() )

        --[[local effectdata = EffectData() -- Explode effect for flare, doesn't look great so I'm commenting it out.
        effectdata:SetOrigin(self:GetPos())
        effectdata:SetMagnitude(2)
        effectdata:SetScale(4)
        effectdata:SetRadius(0)
        util.Effect("sparks", effectdata)]]

        if self:WaterLevel() > 0 then
            --util.Effect( "WaterSurfaceExplosion", effectdata )
            --self:EmitSound("weapons/underwater_explode3.wav", 125, 100, 1, CHAN_AUTO)
        else
            --util.Effect( self.ExplosionEffect, effectdata)
            --self:EmitSound("phx/kaboom.wav", 125, 100, 1, CHAN_AUTO)
        end

        self:SetNWBool("FlareActive", true)

        self:Defuse()

        self:CreateDynamicLight()

        --util.BlastDamage(self, IsValid(self:GetOwner()) and self:GetOwner() or self, self:GetPos(), self.Radius, self.DamageOverride or self.Damage)

        --[[if SERVER then
            local dir = self.HitVelocity or self:GetVelocity()

            if self.Boost <= 0 then
                dir = Vector(0, 0, -1)
            end

            self:FireBullets({
                Attacker = self,
                Damage = 0,
                Tracer = 0,
                Distance = 256,
                Dir = dir,
                Src = self:GetPos(),
                Callback = function(att, tr, dmg)
                    if self.Scorch then
                        util.Decal("Scorch", tr.StartPos, tr.HitPos - (tr.HitNormal * 16), self)
                    end
                end
            })
        end]]

        if self.IsSignalFlare then
            self:EmitSound(self.SignalFlareIgnite[math.random(1, #self.SignalFlareIgnite)], 140, 100, 0.5, nil, nil, 0, ARC9.EveryoneRecipientFilter)
        end

        if self.IsIllumination then
            self:EmitSound(self.IlluminationIgnite[math.random(1, #self.IlluminationIgnite)], 140, 100, 0.5, nil, nil, 0, ARC9.EveryoneRecipientFilter)
        end

        local phys = self:GetPhysicsObject()
        if phys:IsValid() and self.FlareShouldDrag then
            phys:Wake()
            phys:SetDragCoefficient(self.FlareDragCoefficient)
        end
        self.Defused = true
        self.Exploded = true
        -- self:Remove()

        SafeRemoveEntityDelayed(self, self.FlareDuration)
        --self:SetRenderMode(RENDERMODE_NONE)
        --self:SetMoveType(MOVETYPE_NONE)
        --self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    end

    function ENT:PhysicsCollide(colData, physobj)
        if !self:IsValid() then return end

        self.LastHitNormal = colData.HitNormal

        local tgt

        if self.ExplodeOnImpact then
            if CurTime() - self.SpawnTime < self.FuseTime then
                if IsValid(colData.HitEntity) then
                    local v = colData.OurOldVelocity:Length() ^ 0.5
                    local dmg = DamageInfo()
                    dmg:SetAttacker(IsValid(self:GetOwner()) and self:GetOwner() or self)
                    dmg:SetInflictor(self)
                    dmg:SetDamageType(DMG_CRUSH)
                    dmg:SetDamage(v)
                    dmg:SetDamagePosition(colData.HitPos)
                    dmg:SetDamageForce(colData.OurOldVelocity)
                    colData.HitEntity:TakeDamageInfo(dmg)
                    self:EmitSound("weapons/rpg/shotdown.wav", 80, math.random(90, 110))
                end
                self:Defuse()
                return
            end

            timer.Simple(0, function()  -- to prevent "Changing collision rules within a callback is likely to cause crashes!" errors
                if !self:IsValid() then return end
                self:EmitSound("")

                self:GetPhysicsObject():EnableMotion(false)

                if self:IsValid() then
                    self:SetCollisionGroup(COLLISION_GROUP_WEAPON)
                end
            end)

            local effectdata = EffectData()
                effectdata:SetOrigin( self:GetPos() )

            -- simulate AP damage on vehicles, mainly simfphys
            tgt = colData.HitEntity
            while IsValid(tgt) do
                if tgt.GetParent and IsValid(tgt:GetParent()) then
                    tgt = tgt:GetParent()
                elseif tgt.GetBaseEnt and IsValid(tgt:GetBaseEnt()) then
                    tgt = tgt:GetBaseEnt()
                else
                    break
                end
            end
        else
            if colData.DeltaTime > 0.1 then
                self:EmitSound(self.BounceSounds[math.random(1, #self.BounceSounds)], 75)
            end
        end

        if self.ImpactDamage and IsValid(tgt) then
            local dmg = DamageInfo()
            dmg:SetAttacker(IsValid(self:GetOwner()) and self:GetOwner() or self)
            dmg:SetInflictor(self)
            dmg:SetDamageType(DMG_BLAST) -- helicopters
            dmg:SetDamage(self.ImpactDamage)
            dmg:SetDamagePosition(colData.HitPos)
            dmg:SetDamageForce(self:GetForward() * self.ImpactDamage)

            if IsValid(tgt:GetOwner()) and tgt:GetOwner():GetClass() == "npc_helicopter" then
                tgt = tgt:GetOwner()
                dmg:ScaleDamage(0.1)
                dmg:SetDamageType(DMG_BLAST + DMG_AIRBOAT)
                dmg:SetDamageForce(self:GetForward() * 100)
            end

            tgt:TakeDamageInfo(dmg)
        end

        if self.ExplodeOnImpact then
            self.HitPos = colData.HitPos
            self.HitVelocity = colData.OurOldVelocity
            self:Detonate()
        end
    end

    -- Combine Helicopters are hard-coded to only take DMG_AIRBOAT damage
    hook.Add("EntityTakeDamage", "ARC9_HelicopterWorkaround", function(ent, dmginfo)
        if IsValid(ent:GetOwner()) and ent:GetOwner():GetClass() == "npc_helicopter" then ent = ent:GetOwner() end
        if ent:GetClass() == "npc_helicopter" and dmginfo:GetInflictor().HelicopterWorkaround then
            dmginfo:SetDamageType(bit.bor(dmginfo:GetDamageType(), DMG_AIRBOAT))
        end
    end)
end

function ENT:Defuse()
    print(self.Defused)
    self.Defused = true
end

local flaremat = Material("effects/arc9_lensflare")
--[[function ENT:Draw()

    if self.Flare and timer.Simple(self.LifeTime, function() return false end) then
        render.SetMaterial(flaremat)
        render.DrawSprite(self:GetPos(), math.Rand(170, 350), math.Rand(200, 400), Color(255, 24, 24))
    else
        self:DrawModel()
    end
end]]