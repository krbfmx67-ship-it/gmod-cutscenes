-- USSR Flag (ARC9) - ConVars + ARC9 settings page
-- Runs on both client and server (lua/autorun is shared).
-- NOTE: ARC9's settings menu prepends "arc9_" to the convar names listed in the settings table.

-------------------------- SERVER CONVARS (replicated so client prediction matches the server)

local SV_FLAGS = bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY)

CreateConVar("arc9_ussrflag_enabled", "1", SV_FLAGS, "Enable/Disable effects/boosts entirely from the Flag Swep.", 0, 1)

CreateConVar("arc9_ussrflag_duration",  "60",   SV_FLAGS, "How long the charge (speed boost + music) lasts, in seconds.", 1, 600)
CreateConVar("arc9_ussrflag_cooldown",  "10",   SV_FLAGS, "Cooldown in seconds AFTER the charge ends before the flag can be used again.", 0, 600)
CreateConVar("arc9_ussrflag_radius",    "1000", SV_FLAGS, "Radius (Hammer units) of players affected by the charge.", 100, 10000)
CreateConVar("arc9_ussrflag_speedmult", "1.5",  SV_FLAGS, "Walk/run speed multiplier applied during the charge. 1 = no boost.", 1, 5)
CreateConVar("arc9_ussrflag_voices_enabled",        "1", SV_FLAGS, "Server-wide switch for the voice lines.", 0, 1)
CreateConVar("arc9_ussrflag_collective_enabled",    "1", SV_FLAGS, "Enable the big distant battle cry when enough players are charging.", 0, 1)
CreateConVar("arc9_ussrflag_collective_minplayers", "5", SV_FLAGS, "Players needed in radius to trigger the collective battle cry.", 1, 128)

-------------------------- CLIENT CONVARS (each player's own)

if CLIENT then
    CreateClientConVar("arc9_ussrflag_cl_music",        "1", true, false, "Play the charge music.", 0, 1)
    CreateClientConVar("arc9_ussrflag_cl_voices",       "1", true, false, "Hear the charge voice lines.", 0, 1)
    CreateClientConVar("arc9_ussrflag_cl_collective",   "1", true, false, "Hear the collective battle cry.", 0, 1)
end

-------------------------- ARC9 SETTINGS PAGE

if CLIENT then
    -- Delay so ARC9.SettingsTable exists before we add to it.
    timer.Simple(1, function()
        if not ARC9 or not ARC9.SettingsTable then return end

        local ussrflagsettings = {
            TabName = "Addon - USSR Flag",

            {
                type = "label",
                text = "ARC9 - USSR Flag: Client Settings"
            },
            {
                type = "bool",
                text = "Play Charge Music",
                convar = "ussrflag_cl_music",
                desc = "Plays the charge music (and the death sting) for you.\n\nOnly affects you, not other players."
            },
            {
                type = "bool",
                text = "Hear Voice Lines",
                convar = "ussrflag_cl_voices",
                desc = "Hear the voice lines when a charge is called."
            },
            {
                type = "bool",
                text = "Hear Collective Battle Cry",
                convar = "ussrflag_cl_collective",
                desc = "Hear the big distant battle cry when many players charge together."
            },

            {
                type = "label",
                text = "ARC9 - USSR Flag: Server Settings"
            },
            {
                type = "bool",
                text = "Enable/Disable Flag Functionality and Effects",
                convar = "ussrflag_enabled",
                desc = "This enables or disables the functionality of the Flag Swep entirely."
            },
            {
                sv = true,
                type = "slider",
                text = "Charge Duration (s)",
                convar = "ussrflag_duration",
                min = 1,
                max = 600,
                decimals = 0,
                desc = "How long the speed boost and music last."
            },
            {
                sv = true,
                type = "slider",
                text = "Cooldown After Charge (s)",
                convar = "ussrflag_cooldown",
                min = 0,
                max = 600,
                decimals = 0,
                desc = "Time before the flag can be used again, counted from the END of the charge."
            },
            {
                sv = true,
                type = "slider",
                text = "Charge Radius",
                convar = "ussrflag_radius",
                min = 100,
                max = 10000,
                decimals = 0,
                desc = "Players within this distance (Hammer units) get the boost."
            },
            {
                sv = true,
                type = "slider",
                text = "Speed Multiplier",
                convar = "ussrflag_speedmult",
                min = 1,
                max = 5,
                decimals = 2,
                desc = "Walk/run speed multiplier during the charge. 1 = no boost."
            },
            {
                sv = true,
                type = "bool",
                text = "Enable Voice Lines",
                convar = "ussrflag_voices_enabled",
                desc = "Server-wide switch for the voice lines."
            },
            {
                sv = true,
                type = "bool",
                text = "Enable Collective Battle Cry",
                convar = "ussrflag_collective_enabled",
                desc = "Big distant battle cry when enough players charge together."
            },
            {
                sv = true,
                type = "slider",
                text = "Players Needed For Battle Cry",
                convar = "ussrflag_collective_minplayers",
                min = 1,
                max = 128,
                decimals = 0,
                desc = "Number of players in the radius needed to trigger the collective battle cry."
            },
        }

        table.insert(ARC9.SettingsTable, 500, ussrflagsettings)
    end)
end