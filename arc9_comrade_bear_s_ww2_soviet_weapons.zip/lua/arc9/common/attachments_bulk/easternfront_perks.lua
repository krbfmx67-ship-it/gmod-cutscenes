local ATT = {}

ATT.PrintName = [[Bayonet]]
ATT.CompactName = "BAYONET"
ATT.Description = [[Provides close-range melee option with excellent lunge range.]]
ATT.Icon = Material("entities/bayo_mn9130.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_bayonet"}

ATT.Bash = true
ATT.BashWhileSprint = true
ATT.BashDamage = 100
ATT.BashRange = 64
ATT.BashLungeRange = 0
ATT.PreBashTime = 0.1
ATT.PostBashTime = 0.75
ATT.BashDamageType = DMG_SLASH

ARC9.LoadAttachment(ATT, "cb_perk_bayonet")

ATT = {}

ATT.PrintName = [[Fold Stock]]
ATT.CompactName = "FOLD STOCK"
ATT.Description = [[Folding the stock will allow you to use the weapon in more compact and close quarter situations at the cost of decrease recoil control.]]
ATT.Icon = Material("entities/arc9_att_doi_perk_stock.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_foldstock"}

ATT.IKAnimationProxy = {
    ["ready"] = {
        -- All standard animation stuff works
        Source = "base_draw",
        Priority = 1, -- Like _Priority, this determines whether a proxy should override other identical animations.
    }
} -- When an animation event plays, override it with one based on this LHIK model.

ARC9.LoadAttachment(ATT, "cb_perk_foldstock")

ATT = {}

ATT.PrintName = [[Thpmpson 50 Round Drum]]
ATT.CompactName = "50RND DRUM"
ATT.Description = [[A large 50 round drum magazine designed for the 1921 and 1928 versions of the Thompson Submachine gun.]]
ATT.Icon = Material("entities/arc9_att_doi_perk_mag.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_50rnddrum"}

ARC9.LoadAttachment(ATT, "cb_perk_50rnddrum")

ATT = {}

ATT.PrintName = [[Use Magazines]]
ATT.CompactName = "USE MAG"
ATT.Description = [[Some self loading rifles have the capability of quick change box magazines; though it is the standard, sometimes the supply of these magazines are sparse if not rare. Fortunately for you, you have plenty of them!]]
ATT.Icon = Material("entities/perk_use_mag_svt40.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_usemag"}

ARC9.LoadAttachment(ATT, "cb_perk_usemag")

ATT = {}

ATT.PrintName = [[M1895 Bramit Suppressor]]
ATT.CompactName = "M1895 BRAMIT"
ATT.Description = [[An experimental muzzle suppressor device designed for the Nagant M1895 Revolvers, Does a decent job of suppressing your muzzle flash and sound, but not fully.]]
ATT.Icon = Material("entities/supp_m1895_bramit.png", "mips smooth")

ATT.SortOrder = 0

ATT.Silencer = true
ATT.NoFlash = true
ATT.MuzzleParticle = "muzzleflash_suppressed_1p"
ATT.MuzzleEffectQCA = 3
ATT.ShootVolume = 90

ATT.Category = {"cb_m1895_bramit"}

ARC9.LoadAttachment(ATT, "cb_m1895_bramit")

ATT = {}

ATT.PrintName = [[PPSh-41 71 Round Drum]]
ATT.CompactName = "71RND DRUM"
ATT.Description = [[A large 71 round drum magazine designed for the PPSh-41 Submachine gun.]]
ATT.Icon = Material("entities/att_ppsh41_71drum.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_71rnddrum"}

ARC9.LoadAttachment(ATT, "cb_perk_71rnddrum")

ATT = {}

ATT.PrintName = [[Fabric wrap]]
ATT.CompactName = "FABRIC WRAP"
ATT.Description = [[Adds a fabric wrapping to the Mosin Nagant rifle to obscure its reflectiveness and shine. Plus, It looks cool.]]
ATT.Icon = Material("entities/perk_mosin_clothwrap.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"cb_perk_mosinclothwrap"}

ARC9.LoadAttachment(ATT, "cb_perk_mosinclothwrap")