local ATT = {}

ATT.PrintName = [[PU Scope]]
ATT.CompactName = "3.5x PU"
ATT.Description = [[Short to medium range optic for the Mosin Sniper rifle varient.]]
ATT.Icon = Material("entities/optic_pu_4.5x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_pu_4.5x", "sov_optic_mosinsniper"}

ATT.Model = "models/weapons/comradebear/ww2/att/a_optic_mn9130_4x.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0.01, 12, -2.41),
        Ang = Angle(0, 0, 0),
        Magnification = 1.5,
		-- KeepBaseIrons = true,
        ViewModelFOV = 25,
        Blur = false
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 3
ATT.RTScopeMagnification = 3.5
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 1
ATT.RTScopeReticleScale = 1.3

ATT.RTScopeNew_ShadowScale = 2 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.5 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 1
ATT.RTScopeNew_ShaderDistorsionMult = 2

ATT.ScopeScreenRatio = 0.5

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_pu_4.5x")

ATT = {}

ATT.PrintName = [[PU Scope w/ Fabric Wrapping]]
ATT.CompactName = "3.5x PU WRAPPED"
ATT.Description = [[Short to medium range optic for the Mosin Sniper rifle varient, wrapped in a drab fabric to obscure any shine or reflections. and it looks cool.]]
ATT.Icon = Material("entities/optic_pu_4.5x_clothwrap.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_pu_4.5x", "sov_optic_mosinsniper"}

ATT.Model = "models/weapons/comradebear/ww2/att/a_optic_mn9130_4x.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0.01, 12, -2.41),
        Ang = Angle(0, 0, 0),
        Magnification = 1.5,
		-- KeepBaseIrons = true,
        ViewModelFOV = 25,
        Blur = false
    }
}

ATT.ModelBodygroups = "01"

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 3
ATT.RTScopeMagnification = 3.5
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 1
ATT.RTScopeReticleScale = 1.3

ATT.RTScopeNew_ShadowScale = 2 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 0.5 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 0.2
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 1
ATT.RTScopeNew_ShaderDistorsionMult = 2

ATT.ScopeScreenRatio = 0.5

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_pu_4.5x_clothwrap")

ATT = {}

ATT.PrintName = [[Pre-1942]]
ATT.CompactName = "Pre-1942"
ATT.Description = [[The era of which is determined for certain optics and modifications.]]
ATT.Icon = Material("hts/easternfront/arc9_icons/era_pre_1942.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"era_pre_1942", "mod_eras"}

ARC9.LoadAttachment(ATT, "era_pre_1942")

ATT = {}

ATT.PrintName = [[Post-1942]]
ATT.CompactName = "Post-1942"
ATT.Description = [[The era of which is determined for certain optics and modifications.]]
ATT.Icon = Material("hts/easternfront/arc9_icons/era_post_1942.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"era_post_1942", "mod_eras"}

ARC9.LoadAttachment(ATT, "era_post_1942")

ATT = {}

ATT.PrintName = [[PEM Scope]]
ATT.CompactName = "3.9x PEM"
ATT.Description = [[Short to medium range optic for the Mosin Sniper rifle varient.]]
ATT.Icon = Material("entities/optic_pe_3.5x.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_pe_3.5x", "sov_optic_mosinsniper"}

ATT.Model = "models/weapons/comradebear/ww2/att/a_optic_mn9130_pe_3x.mdl"
ATT.ModelOffset = Vector(1.45, -0, 0)

ATT.Sights = {
    {
        Pos = Vector(0.01, 13, -2.22),
        Ang = Angle(0, 0, 0),
		KeepBaseIrons = true,
        ViewModelFOV = 35,
        Blur = false
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 3
ATT.RTScopeMagnification = 3.9
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 1.5
ATT.RTScopeReticleScale = 1.5

ATT.RTScopeNew_ShadowScale = 0.45
ATT.RTScopeNew_ShadowIntensity = 1
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 1
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1

ATT.AimDownSightsTimeMult = 1.8

ARC9.LoadAttachment(ATT, "optic_pe_3.5x")

ATT = {}

ATT.PrintName = [[PU Scope]]
ATT.CompactName = "3.5x PU"
ATT.Description = [[Short to medium range optic for the Mosin Sniper rifle varient.]]
ATT.Icon = Material("entities/optic_pu_4.5x_svt40.png", "mips smooth")

ATT.SortOrder = 0

ATT.Category = {"optic_svt_pu_4.5x", "sov_optic_svt40"}

ATT.Model = "models/weapons/comradebear/ww2/att/a_optic_svt40_3x.mdl"
ATT.ModelOffset = Vector(0, 0, 0)

ATT.Sights = {
    {
        Pos = Vector(0.02, 12, -2.42),
        Ang = Angle(0, 0, 0),
		-- KeepBaseIrons = true,
        Blur = false,
        ViewModelFOV = 20
    }
}

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 1
ATT.RTScopeMagnification = 3.5
ATT.RTScopeReticle = Material("reticles/germancross#1.vmt")
ATT.RTScopeColorable = false
ATT.RTScopeShadowIntensity = 1.5
ATT.RTScopeReticleScale = 1.5

ATT.RTScopeNew_ShadowScale = 0.55
ATT.RTScopeNew_ShadowIntensity = 1
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 1
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1

ATT.ScopeScreenRatio = 0.5

ATT.AimDownSightsTimeMult = 1.2

ARC9.LoadAttachment(ATT, "optic_svt_pu_4.5x")