AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Pistols"

SWEP.PrintName = "TT"

SWEP.Class = "Pistol"

SWEP.Trivia = {
    Manufacturer = "Tula Arms Plant",
    Calibre = "7.62x25mm Tokarev",
    Mechanism = "Short-Recoil Operated Tilting Barrel",
    Origin = "Soviet Union",
    Year = "1931"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "New World Interactive",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[TT or as it is often referred to as the Tokarev, or TT-30/33. Is the standard issue
semi automatic handgun of the Red Army during the second world war. An improvement from the earlier Nagant M1895 revolvers.
The TT uses the higher velocity 7.62x25mm tokarev cartridge, much like the PPSh-41 machineguns. Apart from an improved
cartridge, handgun was also relatively cheap to produce, and easy to operate. It shares many design similarities to the US made
Colt M1911.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_tt33.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 75

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-12.5, 4, -4),
    TPIKPos = Vector(-6, 3.5, -4),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(2, 1, 0),
    Scale = 1,

    TPIKPosSightOffset = Vector(1, 1.5, -4), -- ironsights offset, disable NoTPIKVMPos
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "01000"
SWEP.DefaultSkin = 0

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 35 -- Damage done at point blank range
SWEP.DamageMin = 10 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 4000

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0.1 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1100 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

    --OffWhite - USSR T-30
SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(235, 222, 164) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = 1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 8 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 300

SWEP.Firemodes = {
    {
        Mode = 1,
    }
}

SWEP.ShotgunReload = false
SWEP.HybridReload = false

-------------------------- RECOIL

SWEP.Recoil = 1.2

SWEP.RecoilUp = 1.2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.4 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 12

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 1.2 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 12, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 1.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 1

-- SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 120 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 7.5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.5
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.36 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.36 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/rus/tt33/tt33_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/tt33/tt33_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/browninghp/handling/browning_hp_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.PistolZoomIn
SWEP.ExitSightsSound = CB.PistolZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol_red" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x25tokarev.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 3 -- QC Attachment for shell ejection.
SWEP.CamQCA = 0
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.55, 0, 0.93),
    Ang = Angle(0, -0, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(0, 0, -12)
SWEP.RestAng = Angle(0, 45, 0)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(16.5, 20, 3.3)

SWEP.CustomizeRotateAnchor = Vector(16, -2.50, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "normal"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/browninghp/handling/browning_hp_"
local handling = "/comradebear/wpn/rus/tt33/handling/"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_iron"] = { Source = "iron_idle" },
    ["idle_iron_emtpty"] = { Source = "iron_empty" },
    ["fire"] = { Source = {
        "base_fire",
        "base_fire2",
        "base_fire3"
    },
    EventTable = {
        {t = 0 / 31.5, s = handling .. "tt33_hifi.wav", v = 0.1},
    }  },
    ["fire_empty"] = { Source = "base_firelast",
    EventTable = {
        {t = 0 / 31.5, s = handling .. "tt33_hifi.wav", v = 0.6},
    }  },
    ["fire_iron"] = { Source = {
        "iron_fire",
        "iron_fire2",
        "iron_fire3"
    },
    EventTable = {
        {t = 0 / 31.5, s = handling .. "tt33_hifi.wav", v = 0.3},
    }  },
    ["enter_sights"] = { Source = "iron_idle" },
    ["enter_sights_empty"] = { Source = "iron_empty" },
    ["fire_iron_empty"] = { Source = "iron_firelast",
    EventTable = {
        {t = 0 / 31.5, s = handling .. "tt33_hifi.wav", v = 0.6},
    }  },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_bash" },
    ["bash_empty"] = { Source = "empty_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, FireASAP = 1, Mult = 0.9,  EventTable = {
        {t = 10 / 31.5, s = handling .. "tt33_magrelease.wav"},
        {t = 12 / 31.5, s = handling .. "tt33_magout.wav"},
        {t = 49 / 31.5, s = handling .. "tt33_magin.wav"},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.6, FireASAP = 1, Mult = 0.9, EventTable = {
        {t = 10 / 31.5, s = handling .. "tt33_magrelease.wav"},
        {t = 12 / 31.5, s = handling .. "tt33_magout.wav"},
        {t = 49 / 31.5, s = handling .. "tt33_magin.wav"},
        {t = 77 / 31.5, s = handling .. "tt33_slide_release.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 1, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.PistolDraw},
        {t = 22 / 30, s = handling .. "tt33_slide_back.wav"},
        {t = 30 / 30, s = handling .. "tt33_slide_release.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.PistolHolster},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.PistolHolster},
    } },
}

SWEP.InstantSprintIdle = true

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "vgui/black"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_reload"] = {
        Bodygroups = {
            {1, 0}
        },
        IronSights = {
            Pos = Vector(-2.75, 0, 0.75),
            Ang = Angle(0, 0.75, 0),
            Magnification = 1,
            ViewModelFOV = 60
        }
    },
    ["doi_perk_pistolstock"] = {
        Bodygroups = {
            {2, 1}
        }
    }
}

SWEP.Attachments = {
}