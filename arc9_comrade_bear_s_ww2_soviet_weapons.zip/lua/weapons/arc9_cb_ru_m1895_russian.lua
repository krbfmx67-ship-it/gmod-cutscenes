AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Rifles"

SWEP.PrintName = "7.62mm Vintovka Obr. 95g"

SWEP.Class = "Rifle"

SWEP.Trivia = {
    Manufacturer = "Winchester",
    Calibre = "7.62x54R",
    Mechanism = "Lever Action",
    Origin = "USA",
    Year = "1916"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Winchester Model 1895 Russian, or as officially designated by the russian military, The 7,62MM Rifle model 95.
These lever action rifles had been exclusively manufactured by Winchester as a contract for the Russian Empire during the first world war.
Unlike other Winchester M1895's, the Winchester M1895 Russian was chambered in the commonly used Russian 7.62x54mmR.
After the October revolution, Many of these rifles would later be phased out for the Mosin Nagant M1891/30 as the standard
rifle to the Red Army, However, During the second world war, these rifles would see service once again in limited use within reserve units.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_win_m1985_rus.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

    --Red - US/USSR T-46
SWEP.TracerNum = 1 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(202, 107, 83) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-8, 4, -6),
    TPIKAng = Angle(-10, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,

    TPIKPosSightOffset = Vector(2, 1, -3),
    TPIKHolsterOffset = Vector(7, 0, 5),
}

SWEP.NoTPIKVMPos = true
SWEP.DefaultSkin = 1
SWEP.DefaultBodygroups = "0300000000000000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 115 -- Damage done at point blank range
SWEP.DamageMin = 50 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 19000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 20 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2838 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 5 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.BarrelLength = 54

SWEP.ShotgunReload = true
SWEP.HybridReload = false

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 40 / 0.1

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "LEVER ACTION"
    },

    {
        Mode = -1,
        PrintName = "LEVERING",
        Hook_TranslateAnimation = function(self, anim)
            if anim == "fire" or anim == "fire_iron" then
                return anim .. "_rapid"
            end
        end,
        ManualAction = false,
        RPM = 125
    }
}

SWEP.ManualAction = true

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0
SWEP.RecoilRandomSide = 0

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.2 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 12.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(-2, 12, -20) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 2
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 5 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.IndoorShootVolume = 110
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 95
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/rus/mosin/handling/"
local handling = "/comradebear/wpn/rus/winm1895/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "/comradebear/wpn/rus/winm1895/win_m1895_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/mosin/mn91_30_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/kar98/handling/kar98_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_ar" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x54r.mdl"
SWEP.ShellScale = 1

SWEP.ShellSmoke = true

SWEP.NoShellEject = true
SWEP.NoShellEjectManualAction = true

SWEP.ManualActionNoLastCycle = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

SWEP.ReloadHideBoneTables = { -- works only with TPIK
    [0] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [1] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [2] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [3] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [4] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [5] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    -- [2] = {"list", "of", "bones"}
}

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.62, -3.5, 1.9),
    Ang = Angle(0, -0.05, 0),
    Magnification = 1,
    ViewModelFOV = 35
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 2, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -2)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)

SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(20, 42, 4)
SWEP.CustomizeRotateAnchor = Vector(21.5, -1.21, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.TPIKNoSprintAnim = true

SWEP.HideBones = {"bullet1", "bullet2", "bullet3", "bullet4", "bullet5", "bullet6", "stripperclip"}

local bulletin = {
    handling .. "bullet_insert_01.wav",
    handling .. "bullet_insert_02.wav",
    handling .. "bullet_insert_03.wav",
    handling .. "bullet_insert_04.wav",
    handling .. "bullet_insert_05.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_uncycled"] = { Source = "base_idle_empty" },
    ["fire"] = { Source = "base_shoot" },
    ["fire_rapid"] = { Source = "base_shoot_rapid", EjectAt = 0.42, Mult = 0.6, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "bolt_cycle.wav"},
    } },
    ["fire_empty_rapid"] = { Source = "base_shoot", EjectAt = 0.42, Mult = 0.6, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "bolt_cycle.wav"},
    } },
    ["fire_empty"] = { Source = "base_shoot" },
    ["fire_iron"] = { Source = "base_shoot_iron" },
    ["fire_iron_empty"] = { Source = "base_shoot_iron" },
    ["fire_iron_rapid"] = { Source = "base_shoot_iron_rapid", EjectAt = 0.42, Mult = 0.6, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "bolt_cycle.wav"},
    } },
    ["fire_iron_empty_rapid"] = { Source = "base_shoot_iron_rapid" },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "base_dryfire_iron" },
    ["bash"] = { Source = "base_melee_end" },
    ["cycle"] = { Source = "base_cycle", EjectAt = 0.42, Mult = 0.85, MinProgress = 1, EventTable = {
        {t = 9/35, s = handling .. "bolt_cycle.wav"},
    } },
    ["cycle_iron"] = { Source = "base_cycle_iron", EjectAt = 0.42, Mult = 1, MinProgress = 1, EventTable = {
        {t = 5/35, s = handling .. "bolt_cycle.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
        {t = 17/33,  s = handling .. "hammer_cock.wav"},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
        {t = 13/33,  s = handling .. "hammer_decock.wav"},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["reload_start"] = { Source = "base_reload_start", MinProgress = 0.5, RestoreAmmo = -1, Mult = 0.95, EventTable = {
        {t = 25/35,  s = handling .. "bolt_open.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", RestoreAmmo = 0, Mult = 0.95, EjectAt = 0.9, EventTable = {
        {t = 20/35,  s = handling .. "bolt_open.wav"},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 0.9, MinProgress = 0.5, FireASAP = 1, MagSwapTime = 0.5, EventTable = {
        {t = 14/37.2, s = bulletin},
    } },
    ["reload_insert_5"] = { Source = "base_reload_insert_5", Mult = 0.9, MinProgress = 0.6, FireASAP = 1, MagSwapTime = 0.5, EventTable = {
        {t = 10/33,  s = handling .. "bullet_clip_foley.wav"},
        {t = 50/33,  s = handling .. "bullet_insert_stripperclip.wav"},
        {t = 65/33,  s = handling .. "bullet_insert_stripperclip_bullets1.wav"},
        {t = 100/33, s = path .. "mosin_bolt_clipremove.wav"},
    } },
    ["reload_finish"] = { Source = "base_reload_end", Mult = 0.9, EventTable = {
        {t = 10/33, s = handling .. "bolt_close.wav"},
        {t = 20/33, s = handling .. "mosin_bolt_close.wav"},
    } }
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 3
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {3, 1}
        }
    },
    ["doi_perk_stock"] = {
        Skin = 0
    },
    ["cb_perk_bayonet"] = {
        Bodygroups = {
            {4, 1}
        }
    },
    ["doi_perk_gl"] = {
        Bodygroups = {
            {5, 1}
        }
    },
    ["doi_optic_k98"] = {
        HybridReload = false
    },
    ["doi_optic_k98_4x"] = {
        HybridReload = false
    }
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    local clip = self:Clip1()
    mdl:SetBodygroup(1, math.Clamp( clip, 0, 5))

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
}