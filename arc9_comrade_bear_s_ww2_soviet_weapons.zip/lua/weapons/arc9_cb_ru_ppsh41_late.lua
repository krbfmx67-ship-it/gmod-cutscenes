AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - SMGs"

SWEP.PrintName = "PPSh-41"

SWEP.Class = "Assault Rifle"

SWEP.Trivia = {
    Manufacturer = "Factory No. 367",
    Calibre = "7.62x25MM Tokarev",
    Mechanism = "Open bolt, blow back",
    Origin = "Soviet Union",
    Year = "1942~"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The legendary PPSh-41 submachine gun, Nicknamed the 'Papasha'. Infamous for its extreme high rate of fire,
crazy simple stamped design allowing for high volume of production, and its compatibility with 71 round drum magazines.
This would be the main submachine gun for the red army until towards the end of the war when the PPS-43 would replace it
in its production.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_ppsh41_late.mdl"
SWEP.WorldModel = "models/weapons/w_rif_ak47.mdl"

SWEP.ViewModelFOVBase = 55

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-10, 4, -6),
    TPIKAng = Angle(-15, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,
    TPIKPosSightOffset = Vector(-1, 1, -1),
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "0000000000000000000000"
SWEP.DefaultSkin = 1

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 45 -- Damage done at point blank range
SWEP.DamageMin = 25 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 7000

SWEP.ImpactForce = 6 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 11 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 25 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.3 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2250 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

SWEP.TracerNum = 0 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(255, 255, 255) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

-------------------------- MAGAZINE

SWEP.Ammo = "smg1" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 35 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 1100

SWEP.Firemodes = {
    {
        Mode = -1,
    },
    {
        Mode = 1,
    }
}

-------------------------- RECOIL

SWEP.Recoil = 2.2

SWEP.RecoilUp = 0.2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.3 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.1
SWEP.RecoilRandomSide = 0.0

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 15

SWEP.RecoilAutoControl = 1

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.1 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 12, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

-- SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 120 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0.011 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.35 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.35 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.96

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 110
SWEP.ShootPitchVariation = 1

local path = "/comradebear/wpn/rus/ppsh41/"
local handling = "/comradebear/wpn/rus/ppsh41/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "comradebear/wpn/rus/ppsh41/ppsh41_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/ppsh41/ppsh41_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/rus/ppsh41/ppsh41_int_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/stg44/handling/stg44_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_1" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x25tokarev.mdl"
SWEP.ShellScale = 1
SWEP.ShellCorrectAng = Angle(0, 180, 0)

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 4
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.
SWEP.EjectDelay = 0.05

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.39, -2, 1.72),
    Ang = Angle(0, -0.15, 0),
    Magnification = 1,
    ViewModelFOV = 35
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, -2, -4)
SWEP.RestAng = Angle(55, 15, -10)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(20, 42, 4)
SWEP.CustomizeRotateAnchor = Vector(15, -3.01, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
	["idle_empty"] = { Source = "base_idle_empty" },
    ["fire"] = { Mult = 0.9, Source = {
        "base_fire",
        "base_fire2",
        "base_fire3"
    }, EventTable = {
        {t = 0, s = handling .. "ppsh_hifi.wav" },
    } },
    ["fire_iron"] = { Mult = 0.9, Source = {
        "iron_fire",
        "iron_fire2",
        "iron_fire3",
    }, EventTable = {
        {t = 0, s = handling .. "ppsh_hifi.wav" },
    } },
    ["fire_empty"] = { Mult = 0.9, Source = {
        "base_firelast",
    }, EventTable = {
        {t = 0, s = handling .. "ppsh_hifi.wav" },
    } },
    ["fire_iron_empty"] = { Mult = 0.9, Source = {
        "iron_firelast",
    }, EventTable = {
        {t = 0, s = handling .. "ppsh_hifi.wav" },
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_bash" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 14/30, s = handling .. "ppsh_magrelease.wav"},
        {t = 20/30, s = handling .. "ppsh_box_magout.wav"},
        {t = 48/30, s = handling .. "ppsh_box_magin.wav"},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 17/30,s = handling .. "ppsh_boltback.wav"},
        {t = 52/30,s = handling .. "ppsh_magrelease.wav"},
        {t = 56/30,s = handling .. "ppsh_box_magout.wav"},
        {t = 86/30, s = handling .. "ppsh_box_magin.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 0 / 32, s = CB.Foley},
        {t = 20/30, s = handling .. "ppsh_boltback.wav"},
        {t = 55 / 32, s = CB.Foley},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["firemode"] = { Source = "base_fireselect" },
    ["firemode_empty"] = { Source = "base_fireselect_empty" },
    ["firemode_iron"] = { Source = "iron_fireselect" },



    ["idle_drum"] = { Source = "base_idle_drum" },
	["idle_empty_drum"] = { Source = "base_idle_empty_drum" },
    ["firemode_drum"] = { Source = "base_firemode_drum" },
    ["fire_drum"] = { Mult = 0.9, Source = {
        "base_fire_drum",
        "base_fire2_drum",
        "base_fire3_drum"
    } },
    ["fire_iron_drum"] = { Mult = 0.9, Source = {
        "iron_fire_drum",
        "iron_fire2_drum",
        "iron_fire3_drum",
    } },
    ["fire_empty_drum"] = { Mult = 0.9, Source = {
        "base_firelast_drum",
    } },
    ["fire_iron_empty_drum"] = { Mult = 0.9, Source = {
        "iron_firelast_drum",
    } },
    ["dryfire_drum"] = { Source = "base_dryfire_drum" },
    ["dryfire_iron_drum"] = { Source = "iron_dryfire_drum" },
    ["bash_drum"] = { Source = "base_melee_bash_drum" },
    ["reload_drum"] = { Source = "base_reload_drum", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 25/30,  s = handling .. "ppsh_magrelease.wav"},
        {t = 35/30,  s = handling .. "ppsh_drum_magout.wav"},
        {t = 78/30,  s = handling .. "ppsh_drum_pullout.wav"},
        {t = 85/30,  s = handling .. "ppsh_drum_pullout_stop.wav"},
        {t = 110/30, s = handling .. "ppsh_drum_magin.wav"},
        {t = 135/30, s = handling .. "ppsh_drum_pullout_stop.wav"},
    } },
    ["reload_empty_drum"] = { Source = "base_reloadempty_drum", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 17/30,  s = handling .. "ppsh_boltback.wav"},
        {t = 50/30,  s = handling .. "ppsh_magrelease.wav"},
        {t = 60/30,  s = handling .. "ppsh_drum_magout.wav"},
        {t = 105/30, s = handling .. "ppsh_drum_pullout.wav"},
        {t = 112/30, s = handling .. "ppsh_drum_pullout_stop.wav"},
        {t = 132/30, s = handling .. "ppsh_drum_magin.wav"},
        {t = 162/30, s = handling .. "ppsh_drum_pullout_stop.wav"},
    } },
    ["ready_drum"] = { Source = "base_ready_drum", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 0 / 32, s = CB.Foley},
        {t = 20/30, s = handling .. "ppsh_boltback.wav"},
        {t = 55 / 32, s = CB.Foley},
    } },
    ["draw_drum"] = { Source = "base_draw_drum", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_drum"] = { Source = "base_holster_drum", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["firemode_drum"] = { Source = "base_fireselect_drum" },
    ["firemode_empty_drum"] = { Source = "base_fireselect_empty_drum" },
    ["firemode_iron_drum"] = { Source = "iron_fireselect_drum" },

}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/stg44/weapon_stg_dm"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["cb_perk_71rnddrum"] = {
        Bodygroups = {
            {2, 1}
        },
        ClipSize = 71,
        Hook_TranslateAnimation = function(self, anim)
            return anim .. "_drum"
        end
    },
}

SWEP.Attachments = {
    {
        PrintName = "MAGAZINE",
        Category = {"cb_perk_71rnddrum"},
        Bone = "wpn_body",
        Pos = Vector(0, 10.5, 0),
        Ang = Angle(0, -90, 0)
    },
}