AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Rifles"

SWEP.PrintName = "Mosin M38"

SWEP.Class = "Rifle"

SWEP.Trivia = {
    Manufacturer = "Tula",
    Calibre = "7.62x54R",
    Mechanism = "Bolt Action",
    Origin = "USSR",
    Year = "1938"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Mosin M38 is a carbine version of the standard Mosin rifle, Typically issued to infantry that may be required
to operate in more close quarters combat, or in non frontline duties, like vehicle crews, logistics, and artilery.
The M38 retains much of the power of the standard rifles, at the reduced range and increased recoil. It is also capable of using the standard
bayonet in the case one would need to close the distance with cold steel.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_m38.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

    --Red - US/USSR T-46
SWEP.TracerNum = 1 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(202, 107, 83) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-10, 4, -4),
    TPIKAng = Angle(-10, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,
    
    TPIKPosSightOffset = Vector(2, 2, -3),
}
SWEP.NoTPIKVMPos = true
SWEP.DefaultSkin = 1
SWEP.DefaultBodygroups = "0000000000000000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 115 -- Damage done at point blank range
SWEP.DamageMin = 50 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 19000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 20 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2838 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 5 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = true

SWEP.BarrelLength = 32

SWEP.ShotgunReload = true
SWEP.HybridReload = false

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 40 / 0.1

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "BOLT"
    }
}

SWEP.ManualAction = true
SWEP.SlamFire = false

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.3
SWEP.RecoilRandomSide = 0.5

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.1 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 5.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(-2, 12, -20) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 2
SWEP.VisualRecoilMultSights = 0.6
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 5 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 135
SWEP.IndoorShootVolume = 95
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 85
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/rus/mosin/mosin/"
local handling = "/comradebear/wpn/rus/mosin/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "comradebear/wpn/rus/mosin/mn91_30_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/mosin/mn91_30_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/kar98/handling/kar98_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_ar" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x54r.mdl"
SWEP.ShellScale = 1

SWEP.ShellSmoke = true

SWEP.NoShellEject = true
SWEP.NoShellEjectManualAction = true

SWEP.ManualActionNoLastCycle = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

SWEP.ReloadHideBoneTables = { -- works only with TPIK
    [0] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [1] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [2] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [3] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [4] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    [5] = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02","ammo_bullet_03","ammo_bullet_04","ammo_bullet_05"},
    -- [2] = {"list", "of", "bones"}
}

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.53, -3, 1.32),
    Ang = Angle(0, -0.15, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.IronSightsUBGL = {
    Pos = Vector(-1.21, -5, 5),
    Ang = Angle(0, 0.45, 0),
    Magnification = 1,
    ViewModelFOV = 60
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -2)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(20, 42, 4)
SWEP.CustomizeRotateAnchor = Vector(21.5, -1.21, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "shotgun"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.HideBones = {"ammo_clip", "ammo_bullet_01", "ammo_bullet_02", "ammo_bullet_03", "ammo_bullet_04", "ammo_bullet_05", "ammo_chamberedround_r"}

local bulletin = {
    handling .. "mosin_bullet_insert_1.wav",
    handling .. "mosin_bullet_insert_2.wav",
    handling .. "mosin_bullet_insert_3.wav",
    handling .. "mosin_bullet_insert_4.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_idle_empty" },
    ["idle_uncycled"] = { Source = "base_idle_empty" },
    ["fire"] = { Source = "base_fire_start" },
    ["fire_empty"] = { Source = "base_fire_last" },
    ["fire_iron"] = { Source = "iron_fire_start" },
    ["fire_iron_empty"] = { Source = "iron_fire_last" },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_end" },
    ["cycle"] = { Source = "base_fire_end", EjectAt = 0.5, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35, s = handling .. "mosin_bolt_back.wav"},
        {t = 28/35, s = handling .. "mosin_bolt_forward.wav"},
        {t = 36/35, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["cycle_iron"] = { Source = "iron_fire_end", EjectAt = 0.5, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35, s = handling .. "mosin_bolt_back.wav"},
        {t = 28/35, s = handling .. "mosin_bolt_forward.wav"},
        {t = 36/35, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["reload_empty"] = { Source = "base_reload_clip_empty", EjectAt = 0.85, MinProgress = 1, EventTable = {
        {t = 19/33,  s = handling .. "mosin_bolt_open.wav"},
        {t = 27/33,  s = handling .. "mosin_bolt_back.wav"},
        {t = 68/33,  s = handling .. "mosin_bolt_clipinsert.wav"},
        {t = 83/33,  s = handling .. "mosin_bolt_bulletsin.wav"},
        {t = 110/33, s = handling .. "mosin_bolt_clipremove.wav"},
        {t = 144/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 150/33, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 65, FireASAP = 1,EventTable = {
        {t = 0 / 33, s = CB.Foley},
        {t = 33/33, s = handling .. "mosin_hammer_open.wav"},
        {t = 38/33, s = handling .. "mosin_hammer_close.wav"},
        {t = 70/33, s = handling .. "mosin_bolt_open.wav"},
        {t = 78/33, s = handling .. "mosin_bolt_back.wav"},
        {t = 91/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 98/33, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = -1, MinProgress = 0.55, Mult = 1, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", RestoreAmmo = 0, Mult = 1, EjectAt = 0.85, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, FireASAP = 1, EventTable = {
        {t = 14/37.2, s = bulletin},
    } },
    ["reload_insert_5"] = { Source = "base_reload_insert_5", Mult = 1, MinProgress = 0.5, FireASAP = 1, EventTable = {
        {t = 25/33,  s = handling .. "mosin_bolt_clipinsert.wav"},
        {t = 45/33,  s = handling .. "mosin_bolt_bulletsin.wav"},
        {t = 75/33, s = handling .. "mosin_bolt_clipremove.wav"},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
        {t = 10/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 20/33, s = handling .. "mosin_bolt_close.wav"},
    } }
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 3
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {3, 1}
        }
    },
    ["doi_perk_stock"] = {
        Skin = 0
    },
    ["cb_perk_bayonet"] = {
        Bodygroups = {
            {4, 1}
        }
    },
    ["doi_perk_gl"] = {
        Bodygroups = {
            {5, 1}
        }
    },
    ["doi_optic_k98"] = {
        HybridReload = false
    },
    ["doi_optic_k98_4x"] = {
        HybridReload = false
    }
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    local clip = self:Clip1()
    mdl:SetBodygroup(2, math.Clamp( clip, 0, 5))

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
    {
        PrintName = "BARREL",
        Category = {"cb_perk_bayonet"},
        Bone = "wpn_body",
        Pos = Vector(0, -2, -30),
        Ang = Angle(0, -90, 0)
    },
}

--[[SWEP.HookP_TranslateSound = function(self, data)
    if data.name == "shootsound" then
        -- Suppress default sound
        data.sound = ""
    end

    if data.name == "shootdistant" then
        -- Suppress default sound
        data.sound = ""
    end

    --self:EmitSound("garrysmod/save_load1.wav", 125)

    return data
end]]

--[[SWEP.Hook_PrimaryAttack = function(self)
        local shooter = self:GetOwner()
        if not IsValid(shooter) then return end

        local shootPos = shooter:GetPos() -- Or self:GetPos() if more accurate
        local vol = 1
        local pitch = 100

        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) or ply == shooter then continue end

            local plyPos = ply:EyePos()
            local distUnits = plyPos:Distance(shootPos)
            local distMeters = distUnits / 52.49

            -- Only play for that client
            if ply == LocalPlayer() then
                if distMeters <= 75 then
                    shootPos:EmitSound(self.ShootSound, 100, pitch, vol)
                    print("[Client] Close: ", distMeters)
                elseif distMeters < 300 then
                    local fade = 1 - math.Clamp((distMeters - 75) / 225, 0, 1)
                    sound.Play(self.DistantShootSound, shootPos, 125, pitch, fade)
                    print("[Client] Far: ", distMeters)
                end
            end
        end
end]]

--[[SWEP.Hook_Think = function(self)
    -- Attempt to get the owner of the weapon
    local owner = self:GetOwner() -- Use self:GetOwner() for proper owner retrieval
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Get the viewmodel from the owner
    local vm = owner:GetViewModel(0)
    if not IsValid(vm) then return end

    -- Retrieve current ammo and maximum clip size
    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo, 0, 47)

    -- Print debugging information
    -- print("Calculated Bodygroup Value:", bodygroupValue)
    -- print("Viewmodel Bodygroups:", vm:GetBodyGroups())

    -- Apply the calculated bodygroup value to the viewmodel
    vm:SetBodygroup(1, bodygroupValue)
end]]