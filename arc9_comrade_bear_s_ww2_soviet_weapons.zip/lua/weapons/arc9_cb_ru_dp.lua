AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Machine Guns"

SWEP.PrintName = "DP"

SWEP.Class = "Machine Gun"

SWEP.Trivia = {
    Manufacturer = "Kovrov Arms Plant",
    Calibre = "7.62x54mmR",
    Mechanism = "Gas Operated blow back",
    Origin = "Soviet Union",
    Year = "1928"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The DP or Degtyaryov Machine gun; Alternatively also known as either the DP-27 or DP-28.
This unique machine gun utilized by the Red Army features a 47 round detachable pan magazine, Unlike other nations at the time.
the soviets did not adopt a crew carried belt fed machine gun, instead opting for a lighter machine gun, while still using their heavier
machine guns, Like the SG-43, Maxim PM1910 and DShK to provide more traditional crew served machine gun roles.
The DP does include a relatively quick barrel change design, along with a simple gas operated bolt making the weapon reliable and
cheaper to manufacture.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_dp27.mdl"
SWEP.WorldModel = "models/weapons/w_mach_m249para.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -8),
    TPIKPos = Vector(-10, 4, -4),
    TPIKAng = Angle(-15, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1,
    TPIKPosSightOffset = Vector(2, 0, -4),
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultSkin = 0

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 60 -- Damage done at point blank range
SWEP.DamageMin = 40 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 7500

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 17 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2755 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 47 -- Self-explanatory.
SWEP.SupplyLimit = 4 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = false -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BashWhileSprint = true
SWEP.ShootWhileSprint = false

SWEP.SprintCancelsReload = true
SWEP.BashCancelsReload = true


SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 500

SWEP.Firemodes = {
    {
        Mode = -1,
        PrintName = "AUTO"
    },
}

SWEP.TriggerDelay = false
SWEP.TriggerDelayCancellable = true
SWEP.TriggerDelayRepeat = false
SWEP.TriggerStartFireAnim = false

-------------------------- RECOIL

SWEP.Recoil = 2

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.26 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.2
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 180

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.05 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 5.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(-20, 3, 20) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.2

SWEP.VisualRecoilMult = 1
SWEP.VisualRecoilADSMult = 0.5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 2
SWEP.VisualRecoilMultSights = 0.1
SWEP.VisualRecoilPositionBump = 1.2
SWEP.VisualRecoilPositionBumpUp = 0.6 -- its a mult


SWEP.VisualRecoilDampingConst = 200 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 1
SWEP.VisualRecoilSpringPunchDamping = 4 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0.01 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 15
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 2.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.5 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.5 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.90

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.IndoorShootVolume = 95
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 90
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/rus/dp27/"
local handling = "/comradebear/wpn/rus/dp27/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "comradebear/wpn/rus/dp27/dp_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/dp27/dp_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_rifle_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/mg34/handling/mg34_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

SWEP.HookP_TranslateSound = function(self, data)
    if data.name == "shootsound" then
        data.channel = CHAN_AUTO
    end

    return data
end

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_minimi" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x54r.mdl"
SWEP.ShellScale = 1
SWEP.ShellCorrectAng = Angle(270, 0, 360)

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 5
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.
SWEP.EjectDelay = 0.05

-------------------------- TRACERS

SWEP.TracerNum = 3 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(235, 222, 164) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 0.8

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.065, -2, 1.42) * 1.3,
    Ang = Angle(0, -0.1, 0),
    Magnification = 1,
    ViewModelFOV = 40
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(20, 32, 10)
SWEP.CustomizeRotateAnchor = Vector(21.5, -3.165, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

SWEP.BulletBones = {
    [0] = "Ammo_00",
    [1] = "Ammo_01",
    [2] = "Ammo_02",
    [3] = "Ammo_03",
    [4] = "Ammo_04",
}

-- SWEP.BulletBodygroups = {[47] = {ind = 1, bg = 1}}

-------------------------- Bipod

SWEP.Bipod = true
SWEP.RecoilUpMultBipod = 0.1
SWEP.SwayMultBipod = 0.1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "passive"
SWEP.HoldTypeHolstered = "passive"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.EnterBipodSound = path .. "bipoddeploy.wav"
SWEP.ExitBipodSound = path .. "bipodretract.wav"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle", RareSource = "base_idle_fidget", Time = 1.9 },
    ["idle_iron"] = { Source = "base_idle" },
	
    ["idle_empty"] = { Source = "base_idle_empty", RareSource = "base_idle_fidget", Time = 1.9 },
    ["idle_iron_empty"] = { Source = "base_idle_empty" },
	
    ["fire"] = { Source = {
        "base_fire_1",
        "base_fire_2"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_empty"] = { Source = {
        "base_fire_last"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_iron"] = { Source = {
        "iron_fire_1",
        "iron_fire_2"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_iron_empty"] = { Source = {
        "iron_fire_1",
        "iron_fire_2"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["trigger"] = { Source = "base_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron"] = { Source = "iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["bash"] = { Source = "base_melee_bash" },
    ["firemode"] = { Source = "base_fireselect" },
    ["reload"] = { Source = "base_reload", MinProgress = 0.45, FireASAP = 1, EventTable = {
        {t = 26/33, s = handling .. "dp_magrelease.wav"},
        {t = 48/33, s = handling .. "dp_magout.wav"},
        {t = 75/33, s = handling .. "magout_rattle.wav"},
        {t = 110/33, s = handling .. "dp_magrattle.wav"},
        {t = 125/33, s = handling .. "dp_magin.wav"},
        {t = 150/33, s = handling .. "dp_magslap.wav"},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.45, FireASAP = 1, EventTable = {
        {t = 26/33, s = handling .. "dp_magrelease.wav"},
        {t = 48/33, s = handling .. "dp_magout.wav"},
        {t = 75/33, s = handling .. "magout_rattle.wav"},
        {t = 110/33, s = handling .. "dp_magrattle.wav"},
        {t = 125/33, s = handling .. "dp_magin.wav"},
        {t = 150/33, s = handling .. "dp_magslap.wav"},
        {t = 186/33, s = handling .. "dp_bolt_back.wav"},
        {t = 200/33, s = handling .. "dp_magrattle.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 15/33, s = handling .. "dp_magrattle.wav"},
        {t = 40/33, s = handling .. "dp_bipod_open.wav"},
        {t = 90/33, s = handling .. "dp_bolt_back.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["enter_bipod"] = { Source = "deployed_in", EventTable = {
        {t = 19 / 36, s = path .. "deploygroundhit.wav"},
        {t = 46 / 36, s = path .. "rattle.wav"},
        {t = 65 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["exit_bipod"] = { Source = "deployed_out", EventTable = {
        {t = 25 / 36, s = path .. "rattle.wav"},
        {t = 39 / 36, s = path .. "shoulder_weapon.wav"},
    } },
	
    ["enter_bipod_empty"] = { Source = "deployed_in_empty", EventTable = {
        {t = 19 / 36, s = path .. "deploygroundhit.wav"},
        {t = 46 / 36, s = path .. "rattle.wav"},
        {t = 65 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["exit_bipod_empty"] = { Source = "deployed_out_empty", EventTable = {
        {t = 25 / 36, s = path .. "rattle.wav"},
        {t = 39 / 36, s = path .. "shoulder_weapon.wav"},
    } },
    ["idle_bipod"] = { Source = "deployed_idle" },
    ["idle_iron_bipod"] = { Source = "deployed_iron_idle" },
    ["idle_bipod_empty"] = { Source = "deployed_idle_empty" },
    ["idle_iron_bipod_empty"] = { Source = "deployed_iron_idle_empty" },
    ["fire_bipod"] = { Source = {
        "deployed_fire_1",
        "deployed_fire_2"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_iron_bipod"] = { Source = {
        "deployed_iron_fire_1",
        "deployed_iron_fire_2"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.5, c = ci}},
    },
    ["fire_bipod_empty"] = { Source = {
        "deployed_fire_last"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.25, c = ci}},
    },
    ["fire_iron_bipod_empty"] = { Source = {
        "deployed_iron_fire_last"
    },
    SoundTable = {{s = handling .. "dp_hifi.wav",        t = 0 / 37, v = 0.5, c = ci}},
    },
    ["dryfire_bipod"] = { Source = "deployed_dryfire" },
    ["dryfire_iron_bipod"] = { Source = "deployed_iron_dryfire" },
    ["firemode_bipod"] = { Source = "deployed_fireselect" },
    ["trigger_bipod"] = { Source = "deployed_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["trigger_iron_bipod"] = { Source = "deployed_iron_dryfire", EventTable = {
        {t = 0, s = path .. "empty.wav"}
    } },
    ["reload_bipod"] = { Source = "deployed_reload", MinProgress = 0.60, EventTable = {
        {t = 26/33, s = handling .. "dp_magrelease.wav"},
        {t = 65/33, s = handling .. "dp_magout.wav"},
        {t = 75/33, s = handling .. "magout_rattle.wav"},
        {t = 145/33, s = handling .. "dp_magrattle.wav"},
        {t = 155/33, s = handling .. "dp_magin.wav"},
        {t = 165/33, s = handling .. "dp_magslap.wav"},
    } },
    ["reload_bipod_empty"] = { Source = "deployed_reload_empty", MinProgress = 0.55, EventTable = {
        {t = 26/33, s = handling .. "dp_magrelease.wav"},
        {t = 65/33, s = handling .. "dp_magout.wav"},
        {t = 75/33, s = handling .. "magout_rattle.wav"},
        {t = 145/33, s = handling .. "dp_magrattle.wav"},
        {t = 155/33, s = handling .. "dp_magin.wav"},
        {t = 165/33, s = handling .. "dp_magslap.wav"},
        {t = 200/33, s = handling .. "dp_bolt_back.wav"},
        {t = 210/33, s = handling .. "dp_magrattle.wav"},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/mg34/weapon_mg34_dm"
SWEP.CustomCamoScale = 1.5
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
}

SWEP.Attachments = {
}

SWEP.CustomPoseParamsHandler = function(self, vm, delta)
    if not IsValid(vm) then return end

    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo, 0, 47)

    vm:SetPoseParameter("magazine", bodygroupValue)
end

SWEP.Hook_Think = function(self)
    -- Attempt to get the owner of the weapon
    local owner = self:GetOwner() -- Use self:GetOwner() for proper owner retrieval
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Get the viewmodel from the owner
    local vm = owner:GetViewModel(0)
    if not IsValid(vm) then return end

    -- Retrieve current ammo and maximum clip size
    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo, 0, 47)

    -- Print debugging information
    -- print("Calculated Bodygroup Value:", bodygroupValue)
    -- print("Viewmodel Bodygroups:", vm:GetBodyGroups())

    -- Apply the calculated bodygroup value to the viewmodel

    --vm:SetBodygroup(2, bodygroupValue)
    --vm:SetPoseParameter("magazine", 10)
end