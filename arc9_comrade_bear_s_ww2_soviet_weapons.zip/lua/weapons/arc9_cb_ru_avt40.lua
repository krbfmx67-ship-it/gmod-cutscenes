AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Rifles"

SWEP.PrintName = "AVT-40"

SWEP.Class = "Rifle"

SWEP.Trivia = {
    Manufacturer = "Tula",
    Calibre = "7.62x54Rmm",
    Mechanism = "Gas-Operated Short-Stroke Piston",
    Origin = "Soviet Union",
    Year = "1942"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The AVT-40 is the Automatic version of the SVT-40 self loading rifle, It is virtually identical
to its semi auto counterpart, apart from its select fire features. The purpose of this rifle was to experiment with the
idea of creating an assault rifle, a select fire rifle that can engage targets are a far greater range,
similar to Germany's MkB42(H) assault rifles.
The weapon was generally a failure, Being so heavy, having a high rate of fire with relatively low magazine capacity,
along with the far too recoil intense 7.62x54mmR cartridge.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_svt40.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-6, 4, -6),
    TPIKPos = Vector(-8, 4, -6),
    TPIKAng = Angle(-10, 0, 180),
    Ang = Angle(-5, 0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultSkin = 1

SWEP.DefaultBodygroups = "0000000000000000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 80 -- Damage done at point blank range
SWEP.DamageMin = 40 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 14000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 17 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.15,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2450 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 10 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 32

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

    --OffWhite - USSR T-30
SWEP.TracerNum = 1 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(235, 222, 164) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 1

SWEP.RPM = 750

SWEP.Firemodes = {
    {
        Mode = -1,
    }
}

-------------------------- RECOIL

SWEP.Recoil = 3

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.7

SWEP.RecoilAutoControl = 2 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 0.3 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.03 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 15 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2.5, 20, -5) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 0.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 2.2
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 70 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 4
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.75
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.36 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.36 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "comradebear/wpn/rus/svt40/svt40_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/svt40/svt40_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_semirifle_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/g43/handling/g43_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_ar" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x54r.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-2.9, -5, 1.55),
    Ang = Angle(0, 0.1, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 0),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(-1, -2, 1)
SWEP.CrouchAng = Angle(0, 0, -2)

-- Position when sprinting or safe
SWEP.RestPos = Vector(12, 0, -7)
SWEP.RestAng = Angle(55, 25, -5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(20, 42, 4)
SWEP.CustomizeRotateAnchor = Vector(21.5, -3.165, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "ar2"
SWEP.HoldTypeSprint = "rpg"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN

SWEP.ShotgunReload = false
SWEP.HybridReload = false

local path = "comradebear/wpn/rus/svt40/handling/"
local handling = "/comradebear/wpn/rus/mosin/handling/"

local bulletin = {
    handling .. "mosin_bullet_insert_1.wav",
    handling .. "mosin_bullet_insert_2.wav",
    handling .. "mosin_bullet_insert_3.wav",
    handling .. "mosin_bullet_insert_4.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_iron"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_iron_empty"] = { Source = "empty_idle" },
    ["fire"] = { Source = {
        "base_fire_1",
        "base_fire_2",
        "base_fire_3"
    }, 
    EventTable = {
        {t = 0 / 32, s = path .. "svt40_hifi.wav", v = 0.5},
    } },
    ["fire_iron"] = { Source = {
        "iron_fire_1",
        "iron_fire_2"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "svt40_hifi.wav", v = 1.5},
    }  },
    ["fire_empty"] = { Source = {
        "base_fire_last"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "svt40_hifi.wav", v = 0.5},
    } },
    ["fire_iron_empty"] = { Source = {
        "iron_fire_last"
    },
    EventTable = {
        {t = 0 / 32, s = path .. "svt40_hifi.wav", v = 1.5},
    } },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_end" },
    ["reload"] = { Source = "base_reloadfull", MinProgress = 0.75, FireASAP = 1, EventTable = {
        {t = 14 / 32, s = path .. "mag_release.wav"},
        {t = 24 / 32, s = path .. "mag_out.wav"},
        {t = 70 / 32, s = path .. "mag_hit.wav"},
        {t = 79 / 32, s = path .. "mag_in.wav"},
        {t = 98 / 32, s = path .. "rattle.wav"},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.45, FireASAP = 1, EventTable = {
        {t = 20 / 32, s = path .. "mag_release.wav"},
        {t = 24 / 32, s = path .. "mag_out.wav"},
        {t = 70 / 32, s = path .. "mag_hit.wav"},
        {t = 78 / 32, s = path .. "mag_in.wav"},
        {t = 110 / 32, s = path .. "bolt_back.wav"},
        {t = 122 / 32, s = path .. "bolt_release.wav"},
        {t = 141 / 32, s = path .. "rattle.wav"},
    } },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = -1, Mult = 1, EjectAt = 1.05, EventTable = {
        {t = 30 / 34, s = path .. "bolt_back.wav"},
        {t = 33 / 34, s = path .. "bolt_click.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", RestoreAmmo = 0, Mult = 1, EventTable = {
            {s = path .. "kar98_boltup.wav",        t = 20 / 32, c = ci},
            {s = path .. "kar98_boltback.wav",        t = 25 / 32, c = ci},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
        {t = 14/34, s = bulletin},
    } },
    ["reload_insert_5"] = { Source = "base_reload_insert_5", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
        {t = 30/34,  s = path .. "stripperclip_insert.wav"},
        {t = 45/34,  s = path .. "stripperclip_bulletsin.wav"},
        {t = 65/34, s = path .. "stripperclip_remove.wav"},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
        {t = 17 / 34, s = path .. "bolt_back.wav"},
        {t = 20 / 34, s = path .. "bolt_release.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 0.75, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 25 / 30, s = path .. "bolt_back.wav"},
        {t = 35 / 30, s = path .. "bolt_release.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/g43/weapon_g43_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 2
    },
    ["cb_perk_bayonet"] = {
        Bodygroups = {
            {3, 1}
        }
    },
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
    {
        PrintName = "OPTIC",
        Category = "optic_svt_pu_4.5x",
        Bone = "wpn_body",
        Pos = Vector(0, 4.8, 1.8),
        Ang = Angle(0, -90, 0),
        KeepBaseIrons = true,
        CorrectiveAng = Angle(-0, 0, 0),
    },
    {
        PrintName = "BARREL",
        Category = {"cb_perk_bayonet"},
        Bone = "Weapon",
        Pos = Vector(0, 16, 1),
        Ang = Angle(0, -90, 0),
        Icon_Offset = Vector(-5, 0, 0),
    },
}

SWEP.Hook_Think = function(self)
    -- Attempt to get the owner of the weapon
    local owner = self:GetOwner() -- Use self:GetOwner() for proper owner retrieval
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Get the viewmodel from the owner
    local vm = owner:GetViewModel(0)
    if not IsValid(vm) then return end

    -- Retrieve current ammo and maximum clip size
    local maxAmmo = self:GetMaxClip1()
    local ammo = self:Clip1()

    -- Dynamically calculate the bodygroup value based on ammo
    local bodygroupValue = math.Clamp( ammo, 0, 3)

    -- Print debugging information
     --print("Calculated Bodygroup Value:", bodygroupValue)
     --print("Viewmodel Bodygroups:", vm:GetBodyGroups())

    -- Apply the calculated bodygroup value to the viewmodel
    vm:SetBodygroup(2, bodygroupValue)
end