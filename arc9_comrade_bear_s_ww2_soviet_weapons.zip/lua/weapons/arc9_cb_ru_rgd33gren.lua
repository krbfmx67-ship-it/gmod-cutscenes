AddCSLuaFile()

SWEP.Base = "arc9_base_nade"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Explosives"

SWEP.PrintName = "RGD-33 Grenade"

SWEP.Class = "Grenade"

SWEP.Trivia = {
    Manufacturer = "Kharkov Factory #30",
    Mechanism = "Release Igniter Fuze",
    Origin = "Soviet Union",
    Year = "1933"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "Comrade Bear",
}

SWEP.Description = [[The RGD-33 is a soviet fragmentation stick grenade, Unlike the German M24 stick grenade, it does not have a pull string igniter, nor a pin to release the igniter.
Instead the RGD-33 had to be thrown to activate the fuze, The grenade has a complicated arming procedure but once armed it is easy to activate, or even deactivate by switching the safety switch back.
]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_rgd33.mdl"
SWEP.WorldModel = "models/weapons/comradebear/ww2/w_f1.mdl"

SWEP.Slot = 4

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-12, 5, -5),
    Ang = Angle(0, -0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.NoTPIK = false

SWEP.EntitySelectIcon = false

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "doi_nade_cb_rgd33" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 5000
SWEP.ShootEntInheritPlayerVelocity = true

SWEP.Throwable = true
SWEP.Tossable = true
SWEP.ThrowAnimSpeed = 1

SWEP.FuseTimer = -1

SWEP.ThrowForceMin = 250
SWEP.ThrowForceMax = 1000
SWEP.TossForce = 450

SWEP.ThrowChargeTime = 3

SWEP.ThrowTumble = false

-------------------------- MAGAZINE

SWEP.Ammo = "grenade" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 1 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.
SWEP.SecondarySupplyLimit = 0 -- Amount of reserve UBGL magazines you can take.

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "THROW"
        -- add other attachment modifiers
    },
}

-------------------------- HANDLING

SWEP.FreeAimRadius = 0

SWEP.SprintToFireTime = 0.15 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 1
SWEP.SpeedMultCrouch = 1
SWEP.SpeedMultBlindFire = 1

SWEP.ShootWhileSprint = true

-------------------------- POSITIONS

SWEP.HasSights = false

SWEP.SprintAng = Angle(0, -45, 0)
SWEP.SprintPos = Vector(0, 0, 0)

SWEP.ViewModelFOVBase = 55
SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.CrouchPos = Vector(0, 0, -1)
SWEP.CrouchAng = Angle(0, 0, 0)

SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(15.5, 40, 5.5)
SWEP.CustomizeRotateAnchor = Vector(15.5, -2, -5)

SWEP.CustomizeSnapshotFOV = 45
SWEP.CustomizeSnapshotPos = Vector(0, 0, -0)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

-------------------------- HoldTypes

SWEP.HoldType = "rpg"
SWEP.HoldTypeSprint = "normal"
SWEP.HoldTypeHolstered = "slam"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_PHYSGUN
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_PISTOL
SWEP.AnimDraw = false

-------------------------- SOUNDS

local path = "comradebear/wpn/generic/explosives/"

local throw = {
    path .. "gen_grenade_throw_1.wav",
    path .. "gen_grenade_throw_2.wav",
    path .. "gen_grenade_throw_3.wav",
    path .. "gen_grenade_throw_4.wav",
}

local lowthrow = {
    path .. "gen_grenade_underthrow_1.wav",
    path .. "gen_grenade_underthrow_2.wav",
    path .. "gen_grenade_underthrow_3.wav",
}


SWEP.Animations = {
    ["idle"] = {
        Source = "base_idle"
    },
    ["idle_primed"] = {
        Source = "bakethrow",
        Mult = math.huge
    },
    ["idle_primed_toss"] = {
        Source = "lowthrow",
        Mult = math.huge
    },
    ["draw"] = {
        Source = "base_draw",
        EventTable = {
            {s = CB.Foley, t = 0}
        }
    },
    ["ready"] = {
        Source = "base_draw",
        EventTable = {
            {s = CB.Foley, t = 0}
        }
    },
    ["holster"] = {
        Source = "base_holster",
        EventTable = {
            {s = CB.Foley, t = 0}
        }
    },
    ["pullpin"] = {
        Source = "pullbackhigh",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = path .. "rgd33_pinpull.wav", t = 11 / 30},
            {s = path .. "armdraw.wav", t = 34 / 30}
        }
    },
    ["pullpin_toss"] = {
        Source = "pullbacklow",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = path .. "rgd33_pinpull.wav", t = 11 / 30},
            {s = path .. "armdraw.wav", t = 20 / 30}
        }
    },
    ["throw"] = {
        Source = "throw",
        MinProgress = 0.25,
        EventTable = {
            {s = throw, t = 0},
        }
    },
    ["toss"] = {
        Source = "throwlow",
        MinProgress = 0.25,
        EventTable = {
            {s = throw, t = 0},
        }
    },
}