AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Revolvers"

SWEP.PrintName = "Nagant M1895"

SWEP.Class = "Revolver"

SWEP.Trivia = {
    Manufacturer = "Tula Arms Factory",
    Calibre = "7.62x38R Nagant",
    Mechanism = "Single Action Revolver",
    Origin = "Soviet Union",
    Year = "1920s"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The Nagant M1895 is an old russian revolver, its notable for its unique gas-seal mechanism with the bore
along with its unique cartridge design which creates a full gas seal when fired. This in theory has the benefit of increasing accuracy
and muzzle velocity, however the complex nature of this mechanism has made it less popular with infantry as the trigger
pull is notoriously heavy. One later advantage the revolver would have is the in the development of an experimental suppressor
that makes it among one of the other few revolvers capable of being effectively suppressed.
The Nagant revolver would later be officially replaced by the TT handgun, but would still see service throughout the war.

This version is an old single action only variant, requiring the user to manually operate the hammer everytime it is fired. Yikes.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_nagant_m1895.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 55

SWEP.Slot = 3

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-8, 4, -7),
    TPIKPos = Vector(-18, 8, -4),
    Ang = Angle(-5, 0, 180),
    TPIKHolsterOffset = Vector(10, -4, 0),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.TPIKforcelefthand = false
SWEP.DefaultSkin = 1
SWEP.DefaultBodygroups = "0000000000000000000000"

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 115 -- Damage done at point blank range
SWEP.DamageMin = 50 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 19000

SWEP.ImpactForce = 8 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 20 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 2500 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 7 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 32

SWEP.ShotgunReload = true
SWEP.HybridReload = false

SWEP.ReloadTime = 1

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 14 / 0.1

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "Single Action"
    }
}

SWEP.ManualAction = true

-------------------------- RECOIL

SWEP.Recoil = 1.3

SWEP.RecoilUp = 1.2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.5 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.4
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 12

-------------------------- VISUAL RECOIL

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 2 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 1.5 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 2.5 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(2, 16, 2) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 1.8 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 1

-- SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.3
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.18 -- its a mult


SWEP.VisualRecoilDampingConst = 50 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

local path = "/comradebear/wpn/rus/m1895/"
local handling = "/comradebear/wpn/rus/m1895/handling/"
local path1 = "/hts/1942rp/weapons/gen/"

SWEP.ShootSound = "comradebear/wpn/rus/m1895/m1895_nagant_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/m1895/m1895_nagant_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/gen_pistol_indoor_dist.wav"

SWEP.DistantShootSoundSilenced = "comradebear/wpn/rus/m1895/m1895_nagant_sup_dist.wav"   
SWEP.ShootSoundSilenced = "comradebear/wpn/rus/m1895/m1895_nagant_sup_fp.wav"                    -- Fire silenced

SWEP.ShootSoundSilencedIndoor = "comradebear/wpn/gen_pistol_indoor_supp_fp.wav"
SWEP.DistantShootSoundSilencedIndoor = "comradebear/wpn/gen_pistol_indoor_supp_dist.wav"

SWEP.DryFireSound = "comradebear/wpn/rus/m1895/handling/m1895_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomIn
SWEP.ExitSightsSound = CB.RifleZoomOut

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/762x38r.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.NoShellEject = true
SWEP.NoShellEjectManualAction = true

SWEP.ManualActionNoLastCycle = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

SWEP.BulletBones = {
    [0] = "K98_Reload_Round",
    [1] = "K98_Bullet_1",
    [2] = "K98_Bullet_2",
}

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-1.82, -3, 1.6),
    Ang = Angle(0, 0.2, 0),
    Magnification = 1,
    ViewModelFOV = 45
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(1, -3, 0.2)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(4, -2, -19)
SWEP.RestAng = Angle(7, 60, 5)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(21, 20, 3.5)
SWEP.CustomizeRotateAnchor = Vector(21.5, -2.21, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "pistol"
SWEP.HoldTypeSprint = "pistol"
SWEP.HoldTypeHolstered = "normal"
SWEP.HoldTypeSights = "pistol"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.TPIKforcenoreload = true

-- SWEP.HideBones = {
    -- 86,
    -- 87,
    -- 88,
    -- 89,
    -- 90,
    -- 85,
    -- 98,
    -- 99,
    -- 79
-- }


local dumpshell = {
    handling .. "m1895_bullet_handle_1.wav",
    handling .. "m1895_bullet_handle_2.wav",
    handling .. "m1895_bullet_handle_3.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "base_empty_idle" },
    ["idle_uncycled"] = { Source = "base_empty_idle" },
    ["fire"] = { Source = "base_fire_start",  EventTable = {
        {t = 0/32, s = handling .. "m1895_hifi.wav"},
    } },
    ["fire_empty"] = { Source = "base_fire_start",  EventTable = {
        {t = 0/32, s = handling .. "m1895_hifi.wav"},
    } },
    ["fire_iron"] = { Source = "iron_fire_start",  EventTable = {
        {t = 0/32, s = handling .. "m1895_hifi.wav"},
    }  },
    ["fire_iron_empty"] = { Source = "iron_fire_start",  EventTable = {
        {t = 0/32, s = handling .. "m1895_hifi.wav"},
    }  },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_end" },
    ["cycle"] = { Source = { "base_fire_end1", "base_fire_end2", "base_fire_end3" }, MinProgress = 1, EventTable = {
        {t = 10/32, s = handling .. "m1895_hammerback.wav"},
    } },
    ["cycle_iron"] = { Source = "iron_fire_end", MinProgress = 1, EventTable = {
        {t = 10/32, s = handling .. "m1895_hammerback.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.PistolHolster},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.PistolDraw},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.PistolHolster},
    } },
    ["reload_start"] = { Source = "base_reload_start", Mult = 0.9, MinProgress = 1, EventTable = {
        {t = 15/34, s = handling .. "m1895_hammerforward.wav"},
        {t = 47/34, s = handling .. "m1895_latch.wav"},
        {t = 70/34, s = handling .. "m1895_rodpull.wav"},
        {t = 85/34, s = handling .. "m1895_barrel_latch.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", Mult = 0.9, EventTable = {
        {t = 27/34, s = handling .. "m1895_latch.wav"},
        {t = 50/34, s = handling .. "m1895_rodpull.wav"},
        {t = 65/34, s = handling .. "m1895_barrel_latch.wav"},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 0.9, MinProgress = 0.5, EjectAt = 0.1, FireASAP = 1, EventTable = {
		{t = 3/35, s = dumpshell},
        {t = 30/35,  s = handling .. "m1895_bullet_grab_1.wav"},
        {t = 40/35,  s = handling .. "m1895_cylinderrotate.wav"},
    } },
    ["reload_finish"] = { Source = "base_reload_end", Mult = 0.9, MinProgress = 0.5, FireASAP = 1, EventTable = {
        {t = 5/34,  s = handling .. "m1895_barrel_latch.wav"},
        {t = 25/34, s = handling .. "m1895_rodpull.wav"},
        {t = 47/34, s = handling .. "m1895_latch.wav"},
        {t = 75/34, s = handling .. "m1895_hammerback.wav"},
    } },
    ["enter_ubgl"] = { Source = "glsetup_in", RestoreAmmo = 1, EventTable = {
        {t = 17 / 33.5, s = path .. "rattle.wav"},
        {t = 54 / 33.5, s = path .. "gl_load1.wav"},
        {t = 63 / 33.5, s = path .. "gl_load2.wav"},
        {t = 97 / 33.5, s = path .. "rattle.wav"},
        {t = 110 / 33.5, s = path .. "shoulder.wav"},
    } },
    ["exit_ubgl"] = { Source = "glsetup_out", EventTable = {
        {t = 12 / 33.5, s = path .. "rattle.wav"},
        {t = 36 / 33.5, s = path .. "gl_remove.wav"},
        {t = 81 / 33.5, s = path .. "rattle.wav"},
        {t = 108 / 33.5, s = path .. "shoulder.wav"},
    } },
    ["exit_ubgl_glempty"] = { Source = "glsetup_out_empty", EventTable = {
        {t = 19 / 30.5, s = path .. "boltrelease.wav"},
        {t = 21 / 30.5, s = path .. "boltback.wav"},
        {t = 28 / 30.5, s = path .. "boltforward.wav"},
        {t = 32 / 30.5, s = path .. "boltlatch.wav"},
    } },
    ["idle_ubgl"] = { Source = "glsetup_idle" },
    ["idle_ubgl_empty"] = { Source = "glsetup_idle_empty" },
    ["reload_ubgl"] = { Source = "glsetup_reload", EventTable = {
        {t = 17 / 33.5, s = path .. "rattle.wav"},
        {t = 54 / 33.5, s = path .. "gl_load1.wav"},
        {t = 63 / 33.5, s = path .. "gl_load2.wav"},
        {t = 118 / 33.5, s = path .. "boltrelease.wav"},
        {t = 126 / 33.5, s = path .. "boltback.wav"},
        {t = 136 / 33.5, s = path .. "boltforward.wav"},
        {t = 145 / 33.5, s = path .. "boltlatch.wav"},
        {t = 166 / 33.5, s = path .. "rattle.wav"},
        {t = 168 / 33.5, s = path .. "shoulder.wav"},
    }  },
    ["fire_ubgl"] = { Source = "glsetup_iron_fire" }
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["cb_m1895_bramit"] = {
        Bodygroups = {
            {2, 1}
        }
    },
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
    {
        PrintName = "BARREL",
        Category = {"cb_m1895_bramit"},
        Bone = "wpn_m1895",
        Pos = Vector(0, 7, 2.9),
        Ang = Angle(0, -90, 0)
    },
}

SWEP.Hook_Think = function(self)
	-- I know this is mostly put together by ChatGPT; but Fuck you Arctic. I'm a better problem solver than you!
			--Comrade Bear; Not a Coder, sorta
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end

    -- Check if the weapon is reloading
    if self:GetReloading() then
        -- If HoldType isn't already changed, set it to the desired reload type
        if not self.ReloadingHoldTypeSet then
            self.OriginalHoldType = self.OriginalHoldType or self.HoldType
            self:SetHoldType("revolver") -- Replace with the desired reload hold type
            self.ReloadingHoldTypeSet = true
			self.WorldModelOffset = {
				Pos = Vector(-8, 4, -7),
				TPIKPos = Vector(-26, 2, -2),
				Ang = Angle(-5, 0, 180),
				Scale = 1
			}
        end
    else
        -- If reloading is finished and the hold type was changed
        if self.ReloadingHoldTypeSet then
            -- Add a timer before resetting the HoldType
            timer.Simple(2.3, function()
                -- Ensure the weapon is still valid and the owner is still holding it
                if IsValid(self) and IsValid(self:GetOwner()) and self:GetOwner():GetActiveWeapon() == self then
                    self:SetHoldType(self.OriginalHoldType)
                    self.ReloadingHoldTypeSet = false
					self.WorldModelOffset = {
						Pos = Vector(-8, 4, -7),
						TPIKPos = Vector(-18, 8, -4),
						Ang = Angle(-5, 0, 180),
						Scale = 1
					}
                end
            end)
        end
    end
end