AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Utilities"

SWEP.PrintName = "USSR Flag"

SWEP.Class = "Misc"

SWEP.Trivia = {
    Origin = "Union of Soviet Socialist Republics",
    Year = "1940"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[A USSR flag fixed to a long staff for the purpose of a standard bearer, or a wicked sick charge.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/item_sweps/c_rus_handheld_flag.mdl"
SWEP.WorldModel = "models/weapons/w_pist_glock18.mdl"

SWEP.ViewModelFOVBase = 60

SWEP.Slot = 1

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-12.5, 4, -4),
    TPIKPos = Vector(-12, 15, -5),
    Ang = Angle(10, 10, 160),
    Scale = 1
}
SWEP.NoTPIKVMPos = true

SWEP.DefaultBodygroups = "01000"
SWEP.DefaultSkin = 0

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 100 -- Damage done at point blank range
SWEP.DamageMin = 10 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 4000

SWEP.ImpactForce = 4 -- Force that bullets apply on hit

SWEP.DamageRand = 0.1 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 4 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BULLET -- The damage type of the gun.

-------------------------- PHYS BULLET BALLISTICS

SWEP.PhysBulletMuzzleVelocity = 1100 * 12 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "pistol" -- What ammo type this gun uses.

SWEP.ChamberSize = -1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = -1 -- Self-explanatory.
SWEP.SupplyLimit = 0 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 20

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 300

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "FOR THE MOTHERLAND!!"
    }
}

SWEP.ShotgunReload = false
SWEP.HybridReload = false

-------------------------- RECOIL

SWEP.Recoil = 1

SWEP.RecoilUp = 1 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.75 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.5
SWEP.RecoilRandomSide = 0.5

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 7.5
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 1.5
SWEP.SwayMultSights = 0.5
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.36 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.36 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.99

-------------------------- SOUNDS

SWEP.ShootVolume = 100
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

SWEP.ShootSound = "hts/easternfront/weapons/tt33/tt33_fp.wav"

SWEP.DryFireSound = "weapons/arc9_doi/browninghp/handling/browning_hp_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomin
SWEP.ExitSightsSound = CB.RifleZoomout

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_pistol_red" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/arc9_doi/shells/9x19.mdl"
SWEP.ShellScale = 1.3

SWEP.ShellSmoke = true

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 3 -- QC Attachment for shell ejection.
SWEP.CamQCA = 1
SWEP.CamCoolView = true -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-0, 0, 0),
    Ang = Angle(0, -0, 0),
    Magnification = 1,
    ViewModelFOV = 60
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 1.5)
SWEP.CrouchAng = Angle(0, 0, 0)

-- Position when sprinting or safe
SWEP.RestPos = Vector(0, 0, -12)
SWEP.RestAng = Angle(0, 45, 0)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)

SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(16, 32, 0)

SWEP.CustomizeRotateAnchor = Vector(15, -2.48, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, -2, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, 0, 0)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- HoldTypes

SWEP.HoldType = "melee2"
SWEP.HoldTypeSprint = "melee2"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "melee2"
SWEP.HoldTypeCustomize = "slam"
SWEP.HoldTypeNPC = "pistol"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

local path = "weapons/arc9_doi/browninghp/handling/browning_hp_"

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_iron"] = { Source = "iron_idle" },
    ["idle_iron_emtpty"] = { Source = "iron_empty" },
    ["fire"] = { Source = {
        "base_fire",
        "base_fire2",
        "base_fire3"
    } },
    ["fire_empty"] = { Source = "base_firelast" },
    ["fire_iron"] = { Source = {
        "iron_fire",
        "iron_fire2",
        "iron_fire3"
    } },
    ["enter_sights"] = { Source = "iron_idle" },
    ["enter_sights_empty"] = { Source = "iron_empty" },
    ["fire_iron_empty"] = { Source = "iron_firelast" },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_bash" },
    ["bash_empty"] = { Source = "empty_melee_bash" },
    ["special"] = { Source = "charge", MinProgress = 6, MagSwapTime = 1.25, Mult = 1.2,  EventTable = {
        {t = 10 / 31.5, s = path .. "magrelease.wav"},
        {t = 12 / 31.5, s = path .. "magout.wav"},
        {t = 49 / 31.5, s = path .. "magin.wav"},
        {t = 58 / 31.5, s = path .. "maghit.wav"},
    } },
    ["inspect"] = { Source = "wave", MinProgress = 6, MagSwapTime = 1.25, Mult = 1.5,  EventTable = {
        {t = 10 / 31.5, s = path .. "magrelease.wav"},
        {t = 12 / 31.5, s = path .. "magout.wav"},
        {t = 49 / 31.5, s = path .. "magin.wav"},
        {t = 58 / 31.5, s = path .. "maghit.wav"},
    } },
    ["reload"] = { Source = "base_reload", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.9,  EventTable = {
        {t = 10 / 31.5, s = path .. "magrelease.wav"},
        {t = 12 / 31.5, s = path .. "magout.wav"},
        {t = 49 / 31.5, s = path .. "magin.wav"},
        {t = 58 / 31.5, s = path .. "maghit.wav"},
    } },
    ["reload_empty"] = { Source = "base_reloadempty", MinProgress = 0.75, MagSwapTime = 1.25, Mult = 0.9, EventTable = {
        {t = 10 / 31.5, s = path .. "magrelease.wav"},
        {t = 12 / 31.5, s = path .. "magout.wav"},
        {t = 49 / 31.5, s = path .. "magin.wav"},
        {t = 58 / 31.5, s = path .. "maghit.wav"},
        {t = 77 / 31.5, s = path .. "boltrelease.wav"},
    } },
    ["ready"] = { Source = "base_ready", MinProgress = 1, FireASAP = true, EventTable = {
        {t = 0 / 30, s = CB.Foley},
        {t = 17 / 30, s = path .. "safety.wav"},
        {t = 40 / 30, s = path .. "boltback.wav"},
        {t = 45 / 30, s = path .. "boltrelease.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
}

SWEP.InstantSprintIdle = true

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "vgui/black"
SWEP.CustomCamoScale = 3
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 1
    },
    ["doi_perk_reload"] = {
        Bodygroups = {
            {1, 0}
        },
        IronSights = {
            Pos = Vector(-2.75, 0, 0.75),
            Ang = Angle(0, 0.75, 0),
            Magnification = 1,
            ViewModelFOV = 60
        }
    },
    ["doi_perk_pistolstock"] = {
        Bodygroups = {
            {2, 1}
        }
    }
}

SWEP.Attachments = {
}

SWEP.HookP_BlockFire = function(self)
    return false
end

-------------------------- FLAG SETTINGS (ConVars)
-- Created in lua/autorun/arc9_ussrflag_settings.lua (also adds the ARC9 settings page).

local cv_disable_entirely = GetConVar("arc9_ussrflag_enabled")

local cv_duration   = GetConVar("arc9_ussrflag_duration")
local cv_cooldown   = GetConVar("arc9_ussrflag_cooldown")
local cv_radius     = GetConVar("arc9_ussrflag_radius")
local cv_speedmult  = GetConVar("arc9_ussrflag_speedmult")
local cv_voices_enabled     = GetConVar("arc9_ussrflag_voices_enabled")
local cv_collective_enabled = GetConVar("arc9_ussrflag_collective_enabled")
local cv_collective_min     = GetConVar("arc9_ussrflag_collective_minplayers")

local cl_music      = CLIENT and GetConVar("arc9_ussrflag_cl_music")
local cl_voices     = CLIENT and GetConVar("arc9_ussrflag_cl_voices")
local cl_collective = CLIENT and GetConVar("arc9_ussrflag_cl_collective")

-- Fallback used by the client for fades
SWEP.MusicFadeIn  = 1.0
SWEP.MusicFadeOut = 0.8

SWEP.VoiceLines = {
    "comradebear/wpn/rus/ussrflag/charging_01.wav",
    "comradebear/wpn/rus/ussrflag/charging_02.wav",
    "comradebear/wpn/rus/ussrflag/charging_03.wav",
}

SWEP.LoopSong = "comradebear/wpn/rus/ussrflag/mx_theme_loop.wav"

SWEP.VoiceDelayMin = 1.2
SWEP.VoiceDelayMax = 2

SWEP.NextPrimaryAllowed = 0

SWEP.CollectiveSound = "comradebear/wpn/rus/ussrflag/voice_charge_dist.wav"
SWEP.CollectiveSoundLevel = 140
SWEP.CollectiveVolume = 1
SWEP.CollectivePitchMin = 95
SWEP.CollectivePitchMax = 105
SWEP.CollectiveMinDistanceMult = 1.2

local DEATH_SOUND = "comradebear/wpn/rus/ussrflag/ger_charge_dead.wav"

-------------------------- NETWORKING / SERVER-SIDE HOOKS

if SERVER then
    util.AddNetworkString("ARC9_USSRFLAG_PLAYVOICES")
    util.AddNetworkString("ARC9_USSRFLAG_PLAYMUSIC")
    util.AddNetworkString("ARC9_USSRFLAG_PLAYVOICES_COLLECTIVE")
    util.AddNetworkString("ARC9_USSRFLAG_DEATHSOUND")
    util.AddNetworkString("ARC9_StopLoopForPlayer")

    local function RestoreSpeed(ply)
        if ply._ARC9_OldWalk then
            ply:SetWalkSpeed(ply._ARC9_OldWalk)
            ply:SetRunSpeed(ply._ARC9_OldRun)
        end
        ply._ARC9_OldWalk = nil
        ply._ARC9_OldRun  = nil
        ply._ARC9_Boosted = nil
        ply.ARC9_ChargeActive = nil
        ply._ARC9_ChargeToken = nil
    end

    -- Registered ONCE here (not on every swing) so overlapping charges don't remove each other's hook.
    hook.Add("PlayerDeath", "ARC9_StopBoostOnDeath", function(ply)
        if not ply._ARC9_Boosted then return end

        RestoreSpeed(ply)

        -- Stop music for this player, and let their client play the "fail" sting
        -- (done client-side so their music setting is respected)
        net.Start("ARC9_StopLoopForPlayer")
            net.WriteEntity(ply)
        net.Send(ply)

        net.Start("ARC9_USSRFLAG_DEATHSOUND")
        net.Send(ply)
    end)

    function SWEP:EmitCollectiveVoice(origin)
        -- Send to ALL players, not just affected; each client decides if they want to hear it
        net.Start("ARC9_USSRFLAG_PLAYVOICES_COLLECTIVE")
            net.WriteVector(origin)
            net.WriteString(self.CollectiveSound)
            net.WriteUInt(math.random(self.CollectivePitchMin, self.CollectivePitchMax), 8)
        net.Broadcast()
    end

    function SWEP:DrawRadiusDebug(origin, radius)
        debugoverlay.Sphere(origin, radius, 10, Color(0, 255, 0, 0), true)
    end
end

-------------------------- PRIMARY ATTACK

function SWEP:PrimaryAttack()
    if cv_disable_entirely:GetBool() == false then return end

    if not IsFirstTimePredicted() then return end

    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    -- HARD BLOCK
    if CurTime() < (self.NextPrimaryAllowed or 0) then return end

    local duration = cv_duration:GetFloat()
    local lockTime = duration + cv_cooldown:GetFloat()
    self.NextPrimaryAllowed = CurTime() + lockTime

    -- Backup lock (engine-side)
    self:SetNextPrimaryFire(self.NextPrimaryAllowed)

    self:PlayAnimation("special", 1)

    if not SERVER then return end

    local radius   = cv_radius:GetFloat()
    local origin   = owner:GetPos()
    local radiusSqr = radius ^ 2

    self:DrawRadiusDebug(origin, radius)

    -- Collect all living players in radius
    local affected = {}
    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() and ply:GetPos():DistToSqr(origin) <= radiusSqr then
            table.insert(affected, ply)
        end
    end

    if cv_collective_enabled:GetBool() and #affected >= cv_collective_min:GetInt() then
        self:EmitCollectiveVoice(origin)
    end

    -- Speed boost + mark active
    local mult  = cv_speedmult:GetFloat()
    local token = (owner._ARC9_ChargeCounter or 0) + 1 -- unique id for this charge
    token = CurTime() .. "_" .. owner:EntIndex() .. "_" .. token
    owner._ARC9_ChargeCounter = (owner._ARC9_ChargeCounter or 0) + 1

    for _, ply in ipairs(affected) do
        ply.ARC9_ChargeActive = true
        ply._ARC9_Boosted = true
        ply._ARC9_ChargeToken = token

        -- Store original speeds ONCE
        if not ply._ARC9_OldWalk then
            ply._ARC9_OldWalk = ply:GetWalkSpeed()
            ply._ARC9_OldRun  = ply:GetRunSpeed()
        end

        ply:SetWalkSpeed(ply._ARC9_OldWalk * mult)
        ply:SetRunSpeed(ply._ARC9_OldRun * mult)
    end

    -- Restore speed after the charge. Only restores players still on THIS charge
    -- (so a newer charge, or a death, isn't cut short/undone by an old timer).
    timer.Simple(duration, function()
        for _, ply in ipairs(affected) do
            if IsValid(ply) and ply.ARC9_ChargeActive and ply._ARC9_ChargeToken == token then
                ply:SetWalkSpeed(ply._ARC9_OldWalk or ply:GetWalkSpeed())
                ply:SetRunSpeed(ply._ARC9_OldRun or ply:GetRunSpeed())

                ply._ARC9_OldWalk = nil
                ply._ARC9_OldRun  = nil
                ply._ARC9_Boosted = nil
                ply.ARC9_ChargeActive = nil
                ply._ARC9_ChargeToken = nil
            end
        end
    end)

    -- Voice lines
    if cv_voices_enabled:GetBool() then
        local speakers = {}

        for _, ply in ipairs(affected) do
            table.insert(speakers, {
                ply   = ply,
                sound = table.Random(self.VoiceLines),
                delay = math.Rand(0.1, 0.6),
                pitch = math.random(95, 105),
            })
        end

        net.Start("ARC9_USSRFLAG_PLAYVOICES")
            net.WriteUInt(#speakers, 8)
            for _, info in ipairs(speakers) do
                net.WriteEntity(info.ply)
                net.WriteString(info.sound)
                net.WriteFloat(info.delay)
                net.WriteUInt(info.pitch, 8)
            end
        net.Send(player.GetAll())
    end

    -- Send looping music to affected players (each client can still opt out)
    net.Start("ARC9_USSRFLAG_PLAYMUSIC")
        net.WriteEntity(owner)
        net.WriteFloat(duration)
        net.WriteString(self.LoopSong)
    net.Send(affected)
end

-------------------------- CLIENT

if CLIENT then
    local activeLoops = {}

    net.Receive("ARC9_USSRFLAG_PLAYVOICES_COLLECTIVE", function()
        local origin = net.ReadVector()
        local snd    = net.ReadString()
        local pitch  = net.ReadUInt(8)

        if not cl_collective:GetBool() then return end

        -- Play positionally from the origin in the world
        sound.Play(snd, origin, 140, pitch, 1)
    end)

    net.Receive("ARC9_USSRFLAG_PLAYVOICES", function()
        local count = net.ReadUInt(8)
        local lp = LocalPlayer()
        local wantVoices = cl_voices:GetBool()

        -- Always read everything off the net message, even if muted
        for i = 1, count do
            local ply   = net.ReadEntity()
            local snd   = net.ReadString()
            local delay = net.ReadFloat()
            local pitch = net.ReadUInt(8)

            if not wantVoices then continue end
            if not IsValid(ply) then continue end

            -- Local player plays immediately
            if ply == lp then
                delay = 0
            end

            timer.Simple(delay, function()
                if not IsValid(ply) then return end
                ply:StopSound(snd)
                ply:EmitSound(snd, 75, pitch, 1)
            end)
        end
    end)

    -- LOOPED SONG
    net.Receive("ARC9_USSRFLAG_PLAYMUSIC", function()
        local owner    = net.ReadEntity()
        local duration = net.ReadFloat()
        local song     = net.ReadString()

        if not cl_music:GetBool() then return end
        if not IsValid(owner) then return end

        local lp = LocalPlayer()
        local wep = lp:GetActiveWeapon()
        local fadeIn  = (IsValid(wep) and wep.MusicFadeIn)  or 1
        local fadeOut = (IsValid(wep) and wep.MusicFadeOut) or 1

        -- Kill existing loop ONLY for this player
        if activeLoops[lp] then
            activeLoops[lp]:FadeOut(fadeOut)
            activeLoops[lp] = nil
        end

        local snd = CreateSound(lp, song)
        snd:Play()
        snd:ChangeVolume(1, fadeIn)

        activeLoops[lp] = snd

        timer.Simple(duration, function()
            if activeLoops[lp] == snd then
                snd:FadeOut(fadeOut)
                activeLoops[lp] = nil
            end
        end)
    end)

    net.Receive("ARC9_StopLoopForPlayer", function()
        local ply = net.ReadEntity()
        if not IsValid(ply) then return end

        local snd = activeLoops[ply]
        if snd then
            snd:FadeOut(1)
            activeLoops[ply] = nil
        end
    end)

    -- Fail sting on death (client-side so it follows the music setting)
    net.Receive("ARC9_USSRFLAG_DEATHSOUND", function()
        if not cl_music:GetBool() then return end

        local lp = LocalPlayer()
        if not IsValid(lp) then return end

        local snd = CreateSound(lp, DEATH_SOUND)
        snd:PlayEx(1, 100)

        timer.Simple(20, function()
            if snd then snd:FadeOut(1) end
        end)
    end)
end

function SWEP:EnterSights()
    return false
end