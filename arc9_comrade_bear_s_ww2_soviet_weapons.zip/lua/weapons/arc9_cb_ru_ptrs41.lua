AddCSLuaFile()

SWEP.Base = "arc9_base"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Anti-Tank"

SWEP.PrintName = "PTRS-41"

SWEP.Class = "Anti-Tank Rifle"

SWEP.Trivia = {
    Manufacturer = "Tula Arms Plant",
    Calibre = "14.5x114MM",
    Mechanism = "Short stroke gas piston, Semi-automatic",
    Origin = "USSR",
    Year = "1941"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Animations = "Comrade Bear",
    Assets = "DarkFlow Software",
}

SWEP.Description = [[The PTRS-41 was one of two newly adopted Anti-Tank rifles designed and produced throughout the war, The cheaper and more simplified design
being Degtyarev's PTRD-41, A single shot, recoil operated bolt action.
The PTRS-41, unlike its cheaper single shot counter part, Is a far more heavier and complicated weapon. Although with this seemingly hefty negative, the PTRS-41
was actually the more successful design, Because of its semi-automatic short stroke piston design, along with the 5 round enbloc style clip magazine system. this
allowed the PTRS-41 to be a vastly more effective weapon, although the PTRD-41 had a moderate reload rate, The ability to take multiple shots within a short window
made the PTRS-41 a more reliable tank hunter. Though like the PTRD-41 and other Anti-Tank rifles of its time, It was ahead of its time for being among one the first Semi-Auto Anti-Material
Rifles that even today, still sees combat against light armored vehicles and infantry alike.

The 14.5x114MM APIT Cartridge is capable of penetrating up to 40MM of tank armor at 100 meters. This means that the PTRD-41 and PTRS-41 were among some of the most
effective anti-tank rifles during the early days of WW2, As many other nations at the time, had not produced decent anti-tank rifles. which predictably would eventually
become obsolete as heavier armored tanks would be introducted later in the war, making chemical based anti-tank methods, such as explosives and HEAT Based projectile weapons, like Rocket launchers or
spigot mortars, vastly more effective at taking out tanks by infantry.

The typical method for which infantry were instructed to utilize the PTRD-41 and PTRS-41 was not to engage directly onto heavy armor, instead prioritizing weak points of tanks;
such as vision slots, cupula vision slits or mantlets, Side armor around where the wheels are placed; which is where side armor is most weakest, engine blocks or rear armor, 
and in the worst case scenarios, tank tracks and wheels to immobilize advancing tanks.
Though lighter tanks, Such as the Panzer II's, and some Panzer III's, and other lighter vehicles, like cars, trucks and Half tracks, Can easily be penetrated by 14.5x114MM APIT with its effective ranges.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_ptrs41.mdl"
SWEP.WorldModel = "models/weapons/w_snip_scout.mdl"

SWEP.ViewModelFOVBase = 70

SWEP.Slot = 3

    --Red - US/USSR T-46
SWEP.TracerNum = 1 -- Tracer every X
SWEP.TracerFinalMag = 0 -- The last X bullets in a magazine are all tracers
SWEP.TracerEffect = "ARC9_tracer" -- The effect to use for hitscan tracers
SWEP.TracerColor = Color(202, 107, 83) -- Color of tracers. Only works if tracer effect supports it. For physical bullets, this is compressed down to 9-bit color.
SWEP.TracerSize = 2

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(6, 16, -16),
	TPIKPos = Vector(-10, 5, -8),
	TPIKAng = Angle(-15, 10, 180),
	Ang = Angle(4, 45, 180),
	Scale = 1,

    TPIKPosSightOffset = Vector(-0, -2, 4),
}
SWEP.NoTPIKVMPos = false
SWEP.DefaultSkin = 1
SWEP.TPIKAlternativePos = true

-------------------------- DAMAGE PROFILE

SWEP.DamageMax = 200 -- Damage done at point blank range
SWEP.DamageMin = 0 -- Damage done at maximum range

SWEP.RangeMin = 0
SWEP.RangeMax = 20000

SWEP.ImpactForce = 10 -- Force that bullets apply on hit

SWEP.DamageRand = 0 -- Damage varies randomly per shot by this fraction. 0.1 = +- 10% damage per shot.

SWEP.Penetration = 1.575 -- Units of wood that can be penetrated by this gun.
SWEP.PenetrationDelta = 0.25 -- The damage multiplier after all penetration distance is spent.

SWEP.RicochetAngleMax = 45 -- Maximum angle at which a ricochet can occur. Between 1 and 90. Angle of 0 is impossible but would theoretically always ricochet.
SWEP.RicochetChance = 0.5 -- If the angle is right, what is the chance that a ricochet can occur?

SWEP.DamageType = DMG_BLAST -- The damage type of the gun.

SWEP.ExplosionDamage = 0
SWEP.ExplosionRadius = 2

SWEP.ImpactDecal = "smallscorch"
SWEP.ImpactSound = "phx/explode00.wav"

SWEP.BodyDamageMults = {
    [HITGROUP_HEAD] = 2.5,
    [HITGROUP_CHEST] = 1.25,
    [HITGROUP_STOMACH] = 1.1,
    [HITGROUP_LEFTARM] = 1,
    [HITGROUP_RIGHTARM] = 1,
    [HITGROUP_LEFTLEG] = 0.75,
    [HITGROUP_RIGHTLEG] = 0.75,
}


-------------------------- PHYS BULLET BALLISTICS

SWEP.AlwaysPhysBullet = false

SWEP.PhysBulletMuzzleVelocity = 1012 * 39.36 -- Physical bullet muzzle velocity in Hammer Units/second. 1 HU != 1 inch.

-------------------------- MAGAZINE

SWEP.Ammo = "ar2" -- What ammo type this gun uses.

SWEP.ChamberSize = 1 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 5 -- Self-explanatory.
SWEP.SupplyLimit = 6 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.

SWEP.ReloadWhileSprint = true -- This weapon can reload while the user is sprinting.
SWEP.ReloadInSights = false -- This weapon can aim down sights while reloading.

SWEP.BarrelLength = 32

SWEP.ShotgunReload = false
SWEP.HybridReload = false

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.RPM = 200

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "SEMI"
    }
}

SWEP.ManualAction = false

-------------------------- RECOIL

SWEP.Recoil = 60

SWEP.RecoilUp = 2 -- Multiplier for vertical recoil
SWEP.RecoilSide = 0.25 -- Multiplier for vertical recoil

SWEP.RecoilRandomUp = 0.3
SWEP.RecoilRandomSide = 0.2

SWEP.RecoilAutoControl = 1 -- Multiplier for automatic recoil control.

SWEP.RecoilPatternDrift = 60

-------------------------- VISUAL RECOIL

SWEP.RecoilResetTime = 1
SWEP.RecoilPerShot = 1

SWEP.UseVisualRecoil = true

SWEP.PhysicalVisualRecoil = true -- Visual recoil actually affects your aim point.

SWEP.VisualRecoilUp = 1.8 -- Vertical tilt for visual recoil.F
SWEP.VisualRecoilSide = 0.05 -- Horizontal tilt for visual recoil.
SWEP.VisualRecoilRoll = 4 -- Roll tilt for visual recoil.

SWEP.VisualRecoilCenter = Vector(0, -0, 0) -- The "axis" of visual recoil. Where your hand is.

SWEP.VisualRecoilPunch = 5 -- How far back visual recoil moves the gun.
SWEP.VisualRecoilPunchMultSights = 0.5

SWEP.VisualRecoilMult = 1
--SWEP.VisualRecoilADSMult = 5
--SWEP.VisualRecoilPunchADSMult = 2

SWEP.VisualRecoil = 1
SWEP.VisualRecoilMultSights = 0.5
SWEP.VisualRecoilPositionBump = 1.5
SWEP.VisualRecoilPositionBumpUp = 0.5 -- its a mult


SWEP.VisualRecoilDampingConst = 5 -- How spring will be visual recoil, 120 is default
SWEP.VisualRecoilSpringMagnitude = 2
SWEP.VisualRecoilSpringPunchDamping = 2 -- ehh another val for "eft" recoil, 6 is default

-------------------------- SPREAD

SWEP.Spread = 0 -- And so it shall be.

-------------------------- HANDLING

SWEP.FreeAimRadius = 10
SWEP.FreeAimRadiusMultSights = 0

SWEP.Sway = 0.5
SWEP.SwayMultSights = 0.1
SWEP.SwayMultMove = 1.5

SWEP.AimDownSightsTime = 0.34 -- How long it takes to go from hip fire to aiming down sights.
SWEP.SprintToFireTime = 0.34 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 0.95

-------------------------- SOUNDS

SWEP.ShootVolume = 80
SWEP.ShootVolumeActual = 1
SWEP.ShootPitch = 100
SWEP.ShootPitchVariation = 0.05

local handling = "/comradebear/wpn/rus/ptrs41/handling/"

SWEP.ShootSound = "comradebear/wpn/rus/ptrs41/ptrs41_fp.wav"
SWEP.DistantShootSound = "comradebear/wpn/rus/ptrd41/ptrd41_dist.wav"

SWEP.ShootSoundIndoor = "comradebear/wpn/rus/ptrd41/ptrd41_indoor_fp.wav"
SWEP.DistantShootSoundIndoor = "comradebear/wpn/rus/ptrd41/ptrd41_indoor_dist.wav"

SWEP.DryFireSound = "weapons/arc9_doi/kar98/handling/kar98_empty.wav"
SWEP.DryFireSingleAction = false

SWEP.EnterSightsSound = CB.RifleZoomIn
SWEP.ExitSightsSound = CB.RifleZoomOut

SWEP.EnterBipodSound = handling .. "bipoddeploy.wav"
SWEP.ExitBipodSound = handling .. "bipodretract.wav"

-------------------------- EFFECTS

SWEP.MuzzleParticle = "muzzleflash_M82" -- Used for some muzzle effects.

SWEP.AfterShotEffect = "arc9_aftershoteffect"
SWEP.AfterShotParticle = nil -- Particle to spawn after shooting

SWEP.ShellModel = "models/weapons/comradebear/ww2/shells/145x114.mdl"
SWEP.ShellScale = 1

SWEP.ShellSmoke = true

SWEP.NoShellEject = false
SWEP.NoShellEjectManualAction = true

SWEP.ManualActionNoLastCycle = false

SWEP.MuzzleEffectQCA = 1 -- QC Attachment that controls muzzle effect.
SWEP.CaseEffectQCA = 2 -- QC Attachment for shell ejection.
SWEP.CamQCA = 7
SWEP.CamCoolView = false -- Enable to use procedural camera movement. Set CamQCA to muzzle QCA or something.

-------------------------- POSITIONS

SWEP.IronSights = {
    Pos = Vector(-3.96, -0, 3.8),
    Ang = Angle(0, -0.2, 0),
    Magnification = 2.5,
    ViewModelFOV = 30
}

SWEP.SightMidPoint = { -- Where the gun should be at the middle of it's irons
    Pos = Vector(0, 0, 0),
    Ang = Angle(0, 0, 15),
}

SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.MovingPos = Vector(0, -2, 0)
SWEP.MovingAng = Angle(0, 0, 0)

-- Position when crouching
SWEP.CrouchPos = Vector(0, 0, 4)
SWEP.CrouchAng = Angle(0, 0, -5)

-- Position when sprinting or safe
SWEP.RestPos = Vector(-0, 0, -0)
SWEP.RestAng = Angle(-0, 0, 0)


SWEP.HolsterPos = Vector(0, 0, -5)
SWEP.HolsterAng = Angle(0, -15, 25)


SWEP.SprintMidPoint = {
    Pos = Vector(4, 0, -4),
    Ang = Angle(0, 0, 0)
}

-- Position for customizing
SWEP.CustomizeAng = Angle(45, 0, 0)
SWEP.CustomizePos = Vector(25, 35, 16)
SWEP.CustomizeRotateAnchor = Vector(21.5, -1.21, -3)

SWEP.CustomizeSnapshotFOV = 90
SWEP.CustomizeSnapshotPos = Vector(0, 8, 4)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

SWEP.BipodPos = Vector(0, -2, 2)
SWEP.BipodAng = Angle(0, 0, 0)

SWEP.PeekPos = Vector(2, 0, -2)
SWEP.PeekAng = Angle(0, 0, 0)

SWEP.HeightOverBore = 1

-------------------------- Bipod

SWEP.Bipod = true
SWEP.RecoilUpMultBipod = 0.1
SWEP.SwayMultBipod = 0.1

-------------------------- HoldTypes

SWEP.HoldType = "passive"
SWEP.HoldTypeSprint = "rpg"
SWEP.HoldTypeHolstered = nil
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_AR2
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_AR2
SWEP.AnimDraw = false
SWEP.AnimMelee = ACT_GMOD_GESTURE_MELEE_SHOVE_2HAND

SWEP.HideBones = {"bullet"}

local bulletin = {
    handling .. "bullet_insert_01.wav",
    handling .. "bullet_insert_02.wav",
    handling .. "bullet_insert_03.wav",
}

SWEP.Animations = {
    ["idle"] = { Source = "base_idle" },
    ["idle_empty"] = { Source = "empty_idle" },
    ["idle_uncycled"] = { Source = "empty_idle" },
    ["fire"] = { Source = "base_fire_start" },
    ["fire_empty"] = { Source = "base_fire_last", Mult = 2, },
    ["fire_iron"] = { Source = "iron_fire_start" },
    ["fire_iron_empty"] = { Source = "iron_fire_last" },
    ["dryfire"] = { Source = "base_dryfire" },
    ["dryfire_iron"] = { Source = "iron_dryfire" },
    ["bash"] = { Source = "base_melee_end" },
    ["cycle"] = { Source = "base_fire_end", EjectAt = 0.5, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35, s = handling .. "mosin_bolt_back.wav"},
        {t = 28/35, s = handling .. "mosin_bolt_forward.wav"},
        {t = 40/35, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["cycle_iron"] = { Source = "iron_fire_end", EjectAt = 0.5, MinProgress = 1, EventTable = {
        {t = 13/35, s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35, s = handling .. "mosin_bolt_back.wav"},
        {t = 28/35, s = handling .. "mosin_bolt_forward.wav"},
        {t = 36/35, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["reload_empty"] = { Source = "base_reload_clip_empty", EjectAt = 0.85, MinProgress = 1, EventTable = {
        {t = 19/33,  s = handling .. "mosin_bolt_open.wav"},
        {t = 27/33,  s = handling .. "mosin_bolt_back.wav"},
        {t = 68/33,  s = handling .. "mosin_bolt_clipinsert.wav"},
        {t = 83/33,  s = handling .. "mosin_bolt_bulletsin.wav"},
        {t = 110/33, s = handling .. "mosin_bolt_clipremove.wav"},
        {t = 144/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 150/33, s = handling .. "mosin_bolt_close.wav"},
    } },
    ["ready"] = { Source = "base_draw", MinProgress = 1, FireASAP = true, EventTable = {
        {t = 0 / 33, s = CB.Foley},
        {t = 33/33, s = handling .. "mosin_hammer_open.wav"},
        {t = 38/33, s = handling .. "mosin_hammer_close.wav"},
        {t = 70/33, s = handling .. "mosin_bolt_open.wav"},
        {t = 78/33, s = handling .. "mosin_bolt_back.wav"},
        {t = 91/33, s = handling .. "mosin_bolt_forward.wav"},
        {t = 98/33, s = handling .. "mosin_bolt_close.wav"},
    } },
	
    ["enter_bipod"] = { Source = "deployed_in", EventTable = {
        {t = 1 / 36, s = CB.Foley},
        {t = 15 / 36, s = CB.BipodDrop02},
    } },
    ["exit_bipod"] = { Source = "deployed_out", EventTable = {
        {t = 3 / 36, s = CB.BipodShift01},
        {t = 12 / 36, s = CB.BipodGrab01},
        {t = 30 / 36, s = CB.BipodPickup01},
    } },
	
    ["enter_bipod_empty"] = { Source = "deployed_in_empty", EventTable = {
        {t = 1 / 36, s = CB.Foley},
        {t = 15 / 36, s = CB.BipodDrop02},
    } },
    ["exit_bipod_empty"] = { Source = "deployed_out_empty", EventTable = {
        {t = 3 / 36, s = CB.BipodShift01},
        {t = 12 / 36, s = CB.BipodGrab01},
        {t = 30 / 36, s = CB.BipodPickup01},
    } },
    ["idle_bipod"] = { Source = "deployed_idle" },
    ["idle_iron_bipod"] = { Source = "deployed_iron_idle" },
    ["idle_bipod_empty"] = { Source = "deployed_idle_empty" },
    ["idle_iron_bipod_empty"] = { Source = "deployed_iron_idle_empty" },
    ["fire_bipod"] = { Source = {
        "deployed_fire"
    }},
    ["fire_iron_bipod"] = { Source = {
        "deployed_iron_fire"
    }},
    ["fire_bipod_empty"] = { Source = {
        "deployed_fire_last"
    }},
    ["fire_iron_bipod_empty"] = { Source = {
        "deployed_iron_fire_last"
    }, EjectAt = 0.0 },
    ["dryfire_bipod"] = { Source = "deployed_dryfire" },
    ["dryfire_iron_bipod"] = { Source = "deployed_iron_dryfire" },
    ["trigger_bipod"] = { Source = "deployed_dryfire", EventTable = {
        {t = 0, s = handling .. "empty.wav"}
    } },
    ["trigger_iron_bipod"] = { Source = "deployed_iron_dryfire", EventTable = {
        {t = 0, s = handling .. "empty.wav"}
    } },
    ["reload_bipod"] = { Source = "deployed_reload", MinProgress = 0.4, FireASAP = 1, EventTable = {
        {t = 20/33, s = handling .. "clip_cover_release.wav"},
        {t = 47/33, s = handling .. "clip_cover_open.wav"},
        {t = 68/33, s = handling .. "clip_out.wav"},
        {t = 130/33, s = handling .. "clip_insert.wav"},
        {t = 170/33, s = handling .. "clip_cover_close.wav"},
        {t = 190/33, s = handling .. "clip_cover_tap.wav"},
    } },
    ["reload_bipod_empty"] = { Source = "deployed_reload_empty", Mult = 0.9, MinProgress = 0.4, FireASAP = 1, EventTable = {
        {t = 20/33, s = handling .. "clip_cover_release.wav"},
        {t = 47/33, s = handling .. "clip_cover_open.wav"},
        {t = 68/33, s = handling .. "clip_out.wav"},
        {t = 130/33, s = handling .. "clip_insert.wav"},
        {t = 170/33, s = handling .. "clip_cover_close.wav"},
        {t = 190/33, s = handling .. "clip_cover_tap.wav"},
        {t = 255/33, s = handling .. "bolt_pull.wav"},
        {t = 265/33, s = handling .. "bolt_close.wav"},
    } },
    ["draw"] = { Source = "base_draw", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster"] = { Source = "base_holster", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["draw_empty"] = { Source = "base_draw_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["holster_empty"] = { Source = "base_holster_empty", EventTable = {
        {t = 0, s = CB.Foley},
    } },
    ["reload_start"] = { Source = "base_reload_start", RestoreAmmo = -1, Mult = 1, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_start_empty"] = { Source = "base_reload_start_empty", Mult = 1, EjectAt = 0.85, EventTable = {
        {t = 13/35,  s = handling .. "mosin_bolt_open.wav"},
        {t = 20/35,  s = handling .. "mosin_bolt_back.wav"},
    } },
    ["reload_insert"] = { Source = "base_reload_insert", Mult = 1, MinProgress = 0.5, MagSwapTime = 0.5, EventTable = {
        {t = 14/37.2, s = bulletin},
    } },
    ["reload_finish"] = { Source = "base_reload_end", EventTable = {
        {t = 14 / 35.5, s = handling .. "boltforward.wav"},
        {t = 21 / 35.5, s = handling .. "boltlatch.wav"},
    } },
}

-------------------------- ATTACHMENTS

SWEP.CustomCamoTexture = "models/weapons/arc9_doi/kar98k/weapon_kar98k_worn_dm"
SWEP.CustomCamoScale = 2
SWEP.CustomCamoScale_Priority = 2
SWEP.CustomBlendFactor = 1

SWEP.AttachmentElements = {
    ["camo"] = {
        Skin = 3
    },
    ["doi_perk_sling"] = {
        Bodygroups = {
            {3, 1}
        }
    },
    ["doi_perk_stock"] = {
        Skin = 0
    },
    ["doi_perk_bayonet"] = {
        Bodygroups = {
            {4, 1}
        }
    },
    ["doi_perk_gl"] = {
        Bodygroups = {
            {5, 1}
        }
    },
    ["doi_optic_k98"] = {
        HybridReload = false
    },
    ["doi_optic_k98_4x"] = {
        HybridReload = false
    }
}

SWEP.Hook_ModifyBodygroups = function(self, data)
    local mdl = data.model

    local clip = self:Clip1()

    --print(self:GetReloading())
    --print(mdl:GetSequence())

    if self:GetReloading() then
        local timerName = "ARC9_BodygroupReset_" .. self:EntIndex()

        if not timer.Exists(timerName) then
            local delay = 3

            if mdl:GetSequence() == 14 then
                timer.Create(timerName, delay, 1, function()
                    mdl:SetBodygroup(1, 0)
                    print("Reload Full")
                end)
            else
                timer.Create(timerName, delay, 1, function()
                    mdl:SetBodygroup(1, 0)
                    print("Reload Empty")
                end)
            end
        end
    end

    if !self:GetReloading() then
        mdl:SetBodygroup(1, math.Clamp(5 - clip, 0, 5))
        --print("we are not reloading right now?")
    end
    --mdl:SetBodygroup(1, math.Clamp(5 - clip, 0, 5))

    if self:HasElement("camo") then
        mdl:SetSkin(5)
        if self:HasElement("doi_perk_reload") then
            mdl:SetSkin(4)
        end
    else
        if self:HasElement("doi_perk_stock") then
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(0)
            else
                mdl:SetSkin(2)
            end
        else
            if self:HasElement("doi_perk_reload") then
                mdl:SetSkin(3)
            else
                mdl:SetSkin(1)
            end
        end
    end
end

SWEP.Attachments = {
}

function SWEP:EnterSights()-- I kind of wish there was a hook for this kind of thing.. Womp womp I guess.
    local IsDeployed = self:GetBipod()
    if IsDeployed then
    if self:GetSprintAmount() > 0.5 then return end
    if !self:GetProcessedValue("HasSights", true) then return end
    if self:GetCustomize() then return end
    if !self:GetProcessedValue("ReloadInSights", true) and self:GetReloading() then return end
    if self:GetHolsterTime() > 0 then return end
    if self:GetProcessedValue("UBGLInsteadOfSights", true) then return end
    if self:GetSafe() then return end
    if self.SightsInterruptInspect and self:GetInspecting() then self:CancelInspect() end
    if self:GetAnimLockTime() > CurTime() and !self:GetReloading() then return end -- i hope this won't cause any issues later
    if self:GetValue("UBGL") and self:GetOwner():KeyDown(IN_USE) then return end
    if self:GetIsNearWall() and math.abs(self:GetOwner():GetNW2Float("leaning_fraction", 0)) < 0.1 then return end -- leaning mod support
    if self:HasAnimation("bash") and self.SetNextAiming then
        if self.SetNextAiming > CurTime() then return end
    end

    -- self:ToggleBlindFire(false)
    self:SetInSights(true)
    if IsFirstTimePredicted() then
        local soundtab1 = {
            name = "entersights",
            sound = self:RandomChoice(self:GetProcessedValue("EnterSightsSound", true)),
            channel = ARC9.CHAN_FIDDLE,
        }

        self:PlayTranslatedSound(soundtab1)
    end

    if !self:StillWaiting() or self.NoFireDuringSighting then
        if !(self.SightIsAlsoBipodAnims and self:GetBipod()) then
            if self:GetProcessedValue("InstantSightIdle", true) then
                self:PlayAnimation("idle")
            else
                local anim = self:TranslateAnimation("enter_sights")
                local mult = self:GetProcessedValue("AimDownSightsTime") -- Incorrectly uses a time as a multiplier! Preserved for legacy behavior
                if self:GetAnimationEntry(anim).NoStatAffectors then
                    mult = 1
                end
                self:PlayAnimation(anim, mult, self.NoFireDuringSighting, nil, nil, true)
            end
        end
    end

    self:SetShouldHoldType()
end
end

SWEP.LastBlockFireTime = 0 -- Initialize the cooldown tracker

SWEP.HookP_BlockFire = function(self)
    -- Check if the bipod is deployed
    local IsDeployed = self:GetBipod()

    if not IsDeployed then
        local curTime = CurTime()

        -- Only play the sound and message if enough time has passed
        if curTime > (self.LastBlockFireTime + 1) then -- 1-second delay
            self:EmitSound("hts/easternfront/weapons/dp27/handling/dp_empty.wav")
            self:GetOwner():PrintMessage(HUD_PRINTCENTER, "You need to deploy the bipod before shooting!")
            self.LastBlockFireTime = curTime -- Update the cooldown timer
        end

        -- Block firing explicitly
        return true
    end

    -- Allow firing if the bipod is deployed
    return false
end

SWEP.Hook_BlockTPIK = function(self)

    local IsDeployed = self:GetBipod()
    if IsDeployed then
        return false
    else
        return true
    end
end

SWEP.Hook_Think = function(self)
    if CLIENT then
        local muzzle = self:GetOwner():GetViewModel():GetAttachment(self:GetQCAMuzzle())
        local muzzle2 = self:GetAttachment(self:GetQCAMuzzle())

        --debugoverlay.Cross(muzzle.Pos, 10, 0, Color(0, 255, 0))
        --debugoverlay.Cross(muzzle2.Pos, 10, 0, Color(0, 0, 255))
    end

    if self:GetBipod() then
        self:SetHoldType("ar2")
    else
        self:SetHoldType("passive")
    end

	local IsDeployed = self:GetBipod()

    --print(self)
    --print(self.TPIKAlternativePos)
	
	if IsDeployed == true then
	else
	end
end

SWEP.LastBlockReloadTime = 0 -- Initialize the cooldown tracker for reloading

--[[function SWEP:DoProjectileAttack(pos, ang, spread)
    if IsFirstTimePredicted() then
        if not CLIENT then return end

        local owner = self:GetOwner()
        if not IsValid(owner) then return end
    
        local muzzle = self:GetOwner():GetViewModel():GetAttachment(self:GetQCAMuzzle())
    
        PrintTable(muzzle)
    
        if not muzzle then return end
    
        --debugoverlay.Cross(muzzle.Pos, 100, 10, Color(255, 0, 0), true)
    
        net.Start('use_this_to_cheat')
        net.WriteVector(muzzle.Pos)
        net.WriteAngle(muzzle.Ang)
        net.SendToServer()
    
        if CLIENT then return end
    
        -- print('NUTS NIGGA 9000 GEORGE DROID NEGROTECH', SERVER, CLIENT) 
    end
end

if SERVER then
    util.AddNetworkString('use_this_to_cheat')

    net.Receive('use_this_to_cheat', function(length, ply)
        --print('NUTS NIGGA 9000 GEORGE DROID NEGROTECH', SERVER, CLIENT)

        local pos = net.ReadVector()
        local ang = net.ReadAngle()

        local bullet = {}
        bullet.Src = pos
        bullet.Dir = ang:Forward()
        bullet.Spread = Vector(0, 0, 0)
        bullet.TracerName = "lvs_tracer_cannon_45mm_br243sp"
        bullet.Attacker = ply
        bullet.Force = 40 * 102
        bullet.HullSize = 0
        bullet.Damage = 350
        bullet.Velocity = 350 / 0.01905
		bullet.EnableBallistics = true
    
        -- Fire the LVS bullet manually
        LVS:FireBullet(bullet)
    
        -- Play muzzle effect for LVS bullet
        local effectdata = EffectData()
        effectdata:SetOrigin(pos)
        --effectdata:SetNormal(ang:Vector())
        --effectdata:SetEntity(vm)
        util.Effect("lvs_muzzle", effectdata)
    end)

end]]

function SWEP:DoProjectileAttack(pos, ang, spread)
    if SERVER then
        local owner = self:GetOwner()

        --local localOffset = Vector(50, -4, -5)
        local localOffset = Vector(100, -0, -5)

        local src = LocalToWorld(localOffset, Angle(0,0,0), pos, ang)

        local bullet = {}
        bullet.Src = src
        bullet.Dir = ang:Forward()
        bullet.Spread = Vector(0, 0, 0)
        bullet.TracerName = "lvs_tracer_cannon_14.5mm_B32"
        bullet.Attacker = ply
        bullet.Force = 40 * 102
        bullet.Force1km = 10 * 102
        bullet.HullSize = 0
        bullet.Damage = 600
        bullet.Velocity = 1012 / 0.01905
		bullet.EnableBallistics = true
        bullet.Entity = owner

        --debugoverlay.Cross(src, 100, 10, Color(255, 0, 0), true)

        LVS:FireBullet(bullet)
    end
end

SWEP.Hook_PrimaryAttack = function(self)
    

    -- Define the bullet properties for LVS
    

    -- Return true to prevent ARC9's default bullet from firing
    return false
end

function SWEP:CanReload()
	local IsDeployed = self:GetBipod()

	if IsDeployed then
		-- print("Okay, We can reload!")
		if self:GetOwner():KeyDown(IN_WALK) then return false end
		if self:StillWaiting() then return end
		if self:GetCapacity(self:GetUBGL()) <= 0 then return end
		-- if self:GetTraversalSprintAmount() >= 0 then return end
		local ammo = self:Ammo1()
		if self:GetUBGL() then
			ammo = self:Ammo2()
		end
		if ammo <= 0 and !self:GetInfiniteAmmo() then return end
		if !self:GetProcessedValue("ReloadWhileSprint", true) and self:GetSprintAmount() > 0 then
			return
		end
		if self:GetJammed() then return end
		if self:GetCustomize() then
			return
		end
	
		return true
	else
		-- print("No, We cannot reload!")
        local curTime = CurTime()

        -- Only play the sound and message if enough time has passed
        if curTime > (self.LastBlockReloadTime + 1) then -- 1-second delay to prevent spamming
            self:EmitSound("hts/easternfront/weapons/dp27/handling/dp_empty.wav")
            self:GetOwner():PrintMessage(HUD_PRINTCENTER, "You need to deploy the bipod before reloading!")
            self.LastBlockReloadTime = curTime -- Update the cooldown timer
        end
		return false
	end
end

