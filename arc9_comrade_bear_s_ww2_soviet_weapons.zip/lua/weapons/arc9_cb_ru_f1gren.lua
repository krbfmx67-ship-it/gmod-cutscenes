AddCSLuaFile()

SWEP.Base = "arc9_base_nade"

SWEP.Spawnable = true
SWEP.Category = "ARC9 - ComradeBear - USSR SWEPS"
SWEP.SubCategory = "Soviet - Explosives"

SWEP.PrintName = "F1 Grenade"

SWEP.Class = "Grenade"

SWEP.Trivia = {
    Manufacturer = "Eastman Kodak",
    Mechanism = "Pin Pulled, Delayed fuze",
    Origin = "Soviet Union",
    Year = "1939"
}

SWEP.Credits = {
    Author = "Comrade Bear",
    Assets = "New World Interactive, Comrade Bear",
}

SWEP.Description = [[The F1 grenade was adopted shortly before the start of World War 2, Sometime in 1939.
The grenade is based on the French grenade of the same name, with a domestic model of fuze; This particular fuze,
is of the Koveshnikov design. An early WW2 design which would later be replaced midway through the war by the UZRG fuze.
These grenades were easy to manufacture, Simple to use, and extremely effective.]]

SWEP.ViewModel = "models/weapons/comradebear/ww2/c_f1.mdl"
SWEP.WorldModel = "models/weapons/comradebear/ww2/w_f1.mdl"

SWEP.Slot = 4

SWEP.MirrorVMWM = true
SWEP.WorldModelOffset = {
    Pos = Vector(-8, 6, -4),
    Ang = Angle(0, -0, 180),
    Scale = 1
}
SWEP.NoTPIKVMPos = true
SWEP.NoTPIK = false

SWEP.EntitySelectIcon = false

-------------------------- ENTITY LAUNCHING

SWEP.ShootEnt = "doi_nade_cb_f1" -- Set to an entity to launch it out of this weapon.
SWEP.ShootEntForce = 5000
SWEP.ShootEntInheritPlayerVelocity = true

SWEP.Throwable = true
SWEP.Tossable = true
SWEP.ThrowAnimSpeed = 1

SWEP.FuseTimer = -1

SWEP.ThrowForceMin = 350
SWEP.ThrowForceMax = 1250
SWEP.TossForce = 275

SWEP.ThrowChargeTime = 3

SWEP.ThrowTumble = true

-------------------------- MAGAZINE

SWEP.Ammo = "grenade" -- What ammo type this gun uses.

SWEP.ChamberSize = 0 -- The amount of rounds this gun can chamber.
SWEP.ClipSize = 1 -- Self-explanatory.
SWEP.SupplyLimit = 1 -- Amount of magazines of ammo this gun can take from an ARC9 supply crate.
SWEP.SecondarySupplyLimit = 0 -- Amount of reserve UBGL magazines you can take.

SWEP.DryFireDelay = 0.25
-------------------------- FIREMODES

SWEP.Firemodes = {
    {
        Mode = 1,
        PrintName = "THROW"
        -- add other attachment modifiers
    },
}

-------------------------- HANDLING

SWEP.FreeAimRadius = 0

SWEP.SprintToFireTime = 0.15 -- How long it takes to go from sprinting to being able to fire.

SWEP.SpeedMult = 1
SWEP.SpeedMultCrouch = 1
SWEP.SpeedMultBlindFire = 1

SWEP.ShootWhileSprint = true

-------------------------- POSITIONS

SWEP.HasSights = false

SWEP.SprintAng = Angle(0, -45, 0)
SWEP.SprintPos = Vector(0, 0, 0)

SWEP.ViewModelFOVBase = 55
SWEP.ActivePos = Vector(0, 0, 0)
SWEP.ActiveAng = Angle(0, 0, 0)

SWEP.CrouchPos = Vector(0, 0, -1)
SWEP.CrouchAng = Angle(0, 0, 0)

SWEP.CustomizeAng = Angle(90, 0, 0)
SWEP.CustomizePos = Vector(13.5, 30, 5)
SWEP.CustomizeRotateAnchor = Vector(13.5, -4.5, -5)

SWEP.CustomizeSnapshotFOV = 45
SWEP.CustomizeSnapshotPos = Vector(0, 0, -0)
SWEP.CustomizeSnapshotAng = Angle(0, 0, 0)
SWEP.CustomizeNoRotate = false

-------------------------- HoldTypes

SWEP.HoldType = "rpg"
SWEP.HoldTypeSprint = "normal"
SWEP.HoldTypeHolstered = "slam"
SWEP.HoldTypeSights = "ar2"
SWEP.HoldTypeCustomize = "slam"

SWEP.AnimShoot = ACT_HL2MP_GESTURE_RANGE_ATTACK_PISTOL
SWEP.AnimReload = ACT_HL2MP_GESTURE_RELOAD_MAGIC
SWEP.NonTPIKAnimReload = ACT_HL2MP_GESTURE_RELOAD_PISTOL
SWEP.AnimDraw = false

-------------------------- SOUNDS

local path2 = "comradebear/wpn/generic/explosives/"

local pullpin = {
    path2 .. "mk2_pullpin_01.wav",
    path2 .. "mk2_pullpin_02.wav",
    path2 .. "mk2_pullpin_03.wav",
    path2 .. "mk2_pullpin_04.wav",
}

local throw = {
    path2 .. "gen_grenade_throw_1.wav",
    path2 .. "gen_grenade_throw_2.wav",
    path2 .. "gen_grenade_throw_3.wav",
    path2 .. "gen_grenade_throw_4.wav",
}

local lowthrow = {
    path2 .. "gen_grenade_underthrow_1.wav",
    path2 .. "gen_grenade_underthrow_2.wav",
    path2 .. "gen_grenade_underthrow_3.wav",
}

SWEP.Animations = {
    ["idle"] = {
        Source = "base_idle",
        EventTable = {
            {ind = 1, bg = 0, t = 0 / 30}
        }
    },
    ["idle_primed"] = {
        Source = "bakethrow",
        Mult = math.huge
    },
    ["idle_primed_toss"] = {
        Source = "lowthrow",
        Mult = math.huge
    },
    ["ready"] = {
        Source = "base_draw",
        EventTable = {
            {s = CB.Foley, t = 0},
            {ind = 1, bg = 0, t = 0 / 30}
        }
    },
    ["draw"] = {
        Source = "base_draw",
        EventTable = {
            {s = CB.Foley, t = 0},
            {ind = 1, bg = 0, t = 0 / 30}
        }
    },
    ["holster"] = {
        Source = "base_holster",
        EventTable = {
            {s = CB.Foley, t = 0},
            {ind = 1, bg = 0, t = 0 / 30}
        }
    },
    ["pullpin"] = {
        Source = "pullbackhigh",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = pullpin, t = 19 / 30},
            --{s = path .. "armdraw.wav", t = 34 / 30},
            {ind = 1, bg = 1, t = 35 / 30},
        }
    },
    ["pullpin_toss"] = {
        Source = "pullbacklow",
        MinProgress = 1,
        FireASAP = true,
        EventTable = {
            {s = pullpin, t = 19 / 30},
            --{s = path .. "armdraw.wav", t = 20 / 30},
            {ind = 1, bg = 1, t = 25 / 30},
        }
    },
    ["throw"] = {
        Source = "bakethrow",
        MinProgress = 0.25,
        EventTable = {
            {s = throw, t = 0},
            {ind = 1, bg = 1, t = 0},
        }
    },
    ["toss"] = {
        Source = "lowthrow",
        MinProgress = 0.25,
        EventTable = {
            {s = lowthrow, t = 0},
        }
    },
}