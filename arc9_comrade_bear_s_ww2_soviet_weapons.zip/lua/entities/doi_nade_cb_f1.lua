AddCSLuaFile()

ENT.Type 				= "anim"
ENT.Base 				= "arc9_nade_base"
ENT.PrintName 			= "Mk 2 Grenade"

ENT.Spawnable 			= false
ENT.CollisionGroup = COLLISION_GROUP_PROJECTILE

ENT.Model = "models/weapons/comradebear/ww2/w_f1_thrown.mdl"
-- ENT.SphereSize = 1
-- ENT.PhysMat = "grenade"

ENT.LifeTime = 5

ENT.ExplodeOnImpact = false

ENT.SmokeTrail = false

ENT.Drag = true
ENT.Gravity = true
ENT.Mass = 2
ENT.DragCoefficient = 5
ENT.Boost = 0
ENT.Lift = 0

ENT.shrapnelcount = 120
ENT.shrapneldmg = 120

ENT.dmgradiusminM = 3 * 2
ENT.dmgradiusmaxM = 7 * 1.5

local path2 = "comradebear/wpn/generic/explosives/"

ENT.BounceSounds = {
    path2 .. "gen_grenade_bounce1.wav",
    path2 .. "gen_grenade_bounce2.wav",
    path2 .. "gen_grenade_bounce3.wav",
    path2 .. "gen_grenade_bounce4.wav",
    path2 .. "gen_grenade_bounce5.wav",
}

ENT.closeSound = path2 .. "f1_fuse1.wav"
ENT.loopSound = path2 .. "m24_fuse_loop.wav"
ENT.loopendSound = path2 .. "m24_fuse_loop_end.wav"

ENT.nextloopsound = 999999999999

local smallvector = Vector(0, 0, 5)
local spreadvector = Vector(0.6, 0.6, 0.6)

function ENT:makeshrapnel(count, dmg, owner, pos)
    local batchSize = 50
    local delay = 0.01
    local coneAngle = 50            -- Degrees of vertical spread allowed upward
    local minVerticalAngle = -10    -- Minimum vertical angle in degrees (negative = slightly down, 0 = flat, positive = only upward)
    local debugTime = 5

    local batches = math.ceil(count / batchSize)

    for b = 0, batches - 1 do
        timer.Simple(b * delay, function()
            if not IsValid(self) then return end

            for i = 1, math.min(batchSize, count - b * batchSize) do
                -- Get random horizontal angle
                local angle = math.Rand(0, math.pi * 2)

                -- Base horizontal vector
                local flatDir = Vector(math.cos(angle), math.sin(angle), 0)

                -- Get a random vertical angle in the allowed range
                local verticalAngle = math.Rand(minVerticalAngle, coneAngle)
                local z = math.tan(math.rad(verticalAngle))

                -- Compose final direction and normalize
                local dir = flatDir + Vector(0, 0, z)
                dir:Normalize()

                local distance = math.random(1024, 2048)
                local src = pos + VectorRand() * 2
                local endPos = src + dir * distance

                -- Debug line (red)
                debugoverlay.Line(src, endPos, debugTime, Color(255, 0, 0), true)

                -- Fire bullet
                local shrap = {
                    Attacker = owner,
                    Damage = dmg,
                    Force = 5,
                    AmmoType = "Pistol",
                    Src = src,
                    Dir = dir,
                    Num = 1,
                    Tracer = 0,
                    Spread = vector_origin,
                    Distance = distance,
                    IgnoreEntity = self
                }

                self:FireBullets(shrap)
            end
        end)
    end
end

local dirs = {
    Angle(-90, 90, 0), -- Up            angled by 15 degrees
    Angle(-75, 135, 0), -- Up right
    Angle(-105, 135, 0), -- Up left
    Angle(-105, 45, 0), -- Up front
    Angle(-105, 225, 0), -- Up back
}

local traceResultTable = {}

local traceTable = {
    start = 0,
    endpos = 0,
    mask = 16513,
    output = traceResultTable
}

function ENT:checkindoor()
    local hits = 0
    local endmult = 0

    local eyePos = self:GetPos()
    local eyePos2 = Vector(eyePos)

    traceTable.start = self:GetPos()
    traceTable.endpos = eyePos2

    for i, dir in ipairs(dirs) do
        local dirForward = dir:Forward()
        dirForward:Mul(500 * (i == 1 and 2 or 1))
        eyePos2:Set(eyePos)
        eyePos2:Add(dirForward)

        util.TraceLine(traceTable)

        local tr = traceResultTable

        if tr.Hit and !tr.HitSky then
            hits = hits + 1
        end

        -- if ARC9.Dev(2) then
            -- debugoverlay.Line(traceTable.start, traceTable.endpos, 3, (tr.Hit and !tr.HitSky) and Color(255,0,0) or color_white, true)
        -- end
    end

    return hits >= #dirs * 0.5
end

function ENT:Initialize()
    self:SetModel(self.Model)
    if self.PhysBoxSize then
        self:PhysicsInitBox(-self.PhysBoxSize, self.PhysBoxSize)
    elseif self.SphereSize then
        self:PhysicsInitSphere(self.SphereSize, self.PhysMat)
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
    end

    if SERVER then
        timer.Simple(0.01, function()
            if SERVER then
                -- Yea, Most of this is ChatGPT but it works.
                local prop = ents.Create("prop_physics")
                if IsValid(prop) then
                    local model = "models/weapons/comradebear/ww2/w_f1_spoon.mdl"
                    prop:SetModel(model)
                    prop:SetPos(self:GetPos() + Vector(0, -0, 0))
                    prop:SetAngles(self:GetAngles())
                    prop:Spawn()
                    prop:SetCollisionGroup(COLLISION_GROUP_DEBRIS_TRIGGER)
            
                    -- Calculate bounding box from model
                    local min, max = prop:GetModelBounds()
                    prop:PhysicsInitBox(Vector(-1, -1, -2), Vector(1, 1, 2))
                    prop:SetSolid(SOLID_VPHYSICS)

                    constraint.NoCollide(self, prop, 0, 0)
                    prop:GetPhysicsObject():SetMaterial("Grenade")
            
                    local propPhys = prop:GetPhysicsObject()
                    local mainPhys = self:GetPhysicsObject()
            
                    if IsValid(mainPhys) and IsValid(propPhys) then
                        propPhys:Wake()
                        local ang = self:GetAngles()
                        local offset = ang:Forward() * 0 + ang:Right() * -125 + ang:Up() * 40
                        propPhys:SetVelocity(mainPhys:GetVelocity() + offset)
                        propPhys:AddAngleVelocity(Vector(10, 250, 10))
                    end
            
                    timer.Simple(5, function()
                        if IsValid(prop) then
                            prop:Remove()
                        end
                    end)
                end
            end
        end)
    end

    local phys = self:GetPhysicsObject()
    if phys:IsValid() then
        phys:Wake()
        phys:AddAngleVelocity(Vector(500, 1000, 500))
        phys:EnableDrag(self.Drag)
        phys:SetDragCoefficient(self.DragCoefficient)
        phys:EnableGravity(self.Gravity)
        phys:SetMass(self.Mass)
        phys:SetBuoyancyRatio(0.4)
    end
    self:EmitSound(self.closeSound, 75, 100, 1, nil, nil, 0) --We don't need this, The grenade is pulled before throwing, so it pops before that.
    self.loopSoundObj = CreateSound(self, self.loopSound)
    self.loopSoundObj:SetSoundLevel(60)
    self.loopSoundObj:Play()
    timer.Simple(5, function()
        self.loopSoundObj:Stop()
    end)

    if self.SmokeTrail then
        util.SpriteTrail(self, 0, Color( 255 , 255 , 255 ), false, self.SmokeTrailSize, 0, self.SmokeTrailTime, 1 / self.SmokeTrailSize * 0.5, self.SmokeTrailMat)
    end

    self.SpawnTime = CurTime()
end

function ENT:Detonate()
    if not self:IsValid() then return end
    if self.Defused then return end
    if self:WaterLevel() > 0 then
        local tr = util.TraceLine({
            start = self:GetPos(),
            endpos = self:GetPos() + Vector(0, 0, 1) * 1024,
            filter = self,
        })
        local tr2 = util.TraceLine({
            start = tr.HitPos,
            endpos = self:GetPos(),
            filter = self,
            mask = MASK_WATER
        })
        ParticleEffect("water_explosion", tr2.HitPos + Vector(0, 0, 8), Angle(0, 0, 0), nil)

        // Overpressure radius
        -- util.BlastDamage(self, IsValid(self:GetOwner()) and self:GetOwner() or self, self:GetPos(), 512, 110)

        self:EmitSound("comradebear/wpn/generic/explosives/explode_water_close_01.wav", 140, 100, 10, nil, nil, 0)
        self:EmitSound("comradebear/wpn/generic/explosives/explode_dist_01.wav", 140, 100, 0.5, nil, nil, 0, ARC9.EveryoneRecipientFilter)
        -- self:EmitSound("weapons/arc9_doi/mk2/water/mk2_water_detonate_dist_0" .. math.random(1, 3) .. ".wav", 130)
    else
        ParticleEffect("explosion_he_grenade", self:GetPos(), Angle(0, 0, 0), nil)

        // Overpressure radius
        --util.BlastDamage(self, IsValid(self:GetOwner()) and self:GetOwner() or self, self:GetPos(), 256, 100)
        local Pos =  self:GetPos() 

        if LVS then --I've added this because util.BlastDamage does insane damage to LVS vehicles, Using LVS:BlastDamage instead solves the issue and prevents using hand grenades to kill King Tiger tanks.
            LVS:BlastDamage( Pos, self:GetForward(), IsValid(self:GetOwner()) and self:GetOwner(), self, 275, DMG_BULLET, 372, 2000 ) 
            --print("Okay, We are LVS Compatible")
        else
            util.BlastDamage(self, IsValid(self:GetOwner()) and self:GetOwner() or self, self:GetPos(), 512, 175)
            --print("LVS isn't installed, So we don't need to worry.")
        end

		self:makeshrapnel(self.shrapnelcount, self.shrapneldmg, owner, Pos)
        -- // Shrapnel radius
         // util.BlastDamage(self, IsValid(self:GetOwner()) and self:GetOwner() or self, self:GetPos(), 512, 50)

        //self:EmitSound("hts/easternfront/weapons/explosives/grenade_explosion" .. math.random(1, 6) .. ".wav", 125) -- don't need this anymore, We're using cooler code!!
		--self:EmitSound(self.loopendSound, 60, 100, 1, nil, nil, 0)

        if self:checkindoor() then
            self:EmitSound("comradebear/wpn/generic/explosives/explode_close_indoor_01.wav", 90, 100, 10, nil, nil, 0)
            self:EmitSound("comradebear/wpn/generic/explosives/explode_dist_indoor_01.wav", 140, 100, 0.5, nil, nil, 0, ARC9.EveryoneRecipientFilter)

        else
            self:EmitSound("comradebear/wpn/generic/explosives/explode_close_01.wav", 90, 100, 10, nil, nil, 0)
            self:EmitSound("comradebear/wpn/generic/explosives/explode_dist_01.wav", 140, 100, 0.5, nil, nil, 0, ARC9.EveryoneRecipientFilter)
        end 
    end

    if SERVER then
        local dir = self.HitVelocity or self:GetVelocity()

        if self.Boost <= 0 then
            dir = Vector(0, 0, -1)
        end

        self:FireBullets({
            Attacker = self,
            Damage = 0,
            Tracer = 0,
            Distance = 256,
            Dir = dir,
            Src = self:GetPos(),
            Callback = function(att, tr, dmg)
                if self.Scorch then
                    util.Decal("Scorch", tr.StartPos, tr.HitPos - (tr.HitNormal * 16), self)
                end
            end
        })
    end
    self.Defused = true

    self.loopSoundObj:Stop()

    SafeRemoveEntityDelayed(self, self.SmokeTrailTime)
    self:SetRenderMode(RENDERMODE_NONE)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
end

function ENT:Use(activator, caller, useType, value)
        if not IsValid(activator) or not activator:IsPlayer() then return end

        local phys = self:GetPhysicsObject()
        if not IsValid(phys) then
            activator:ChatPrint("Can't pick this up (no physics object).")
            return
        end

        -- Make sure it's light enough; player pickup for +use often fails if mass is huge
        if phys:GetMass() > 50 then
            phys:SetMass(self.Mass or 5)
            phys:Wake()
        end

        -- Use player's built-in pickup function (this is what makes +use pick up props)
        if activator.PickupObject then
            activator:PickupObject(self)
        end
    end