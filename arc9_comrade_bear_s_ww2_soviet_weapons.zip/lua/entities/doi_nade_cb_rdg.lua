AddCSLuaFile()

ENT.Type 				= "anim"
ENT.Base 				= "arc9_nade_base"
ENT.PrintName 			= "Mk 2 Grenade"

ENT.Spawnable 			= false
ENT.CollisionGroup = COLLISION_GROUP_PROJECTILE

ENT.Model = "models/weapons/comradebear/ww2/w_rdg1.mdl"
-- ENT.SphereSize = 1
-- ENT.PhysMat = "grenade"

ENT.ExplodeOnImpact = false

ENT.SmokeTrail = false

ENT.StartTime = 1
ENT.LifeTime = 266
ENT.EmitTime = 90

ENT.Drag = true
ENT.Gravity = true
ENT.Mass = 2
ENT.DragCoefficient = 5
ENT.Boost = 0
ENT.Lift = 0

ENT.BounceSounds = {
    "weapons/arc9_doi/stielhandgranate/stielhandgranate_bounce_01.wav",
    "weapons/arc9_doi/stielhandgranate/stielhandgranate_bounce_02.wav",
    "weapons/arc9_doi/stielhandgranate/stielhandgranate_bounce_03.wav",
    "weapons/arc9_doi/stielhandgranate/stielhandgranate_bounce_04.wav",
}

local path = "weapons/darsu_eft/grenades/"
local path2 = "hts/easternfront/weapons/explosives/"

ENT.closeSound = path2 .. "m24_smoke_start.wav"
ENT.loopSound = path2 .. "m24_smoke_loop.wav"
ENT.loopendSound = path2 .. "m24_smoke_end.wav"

ENT.PopSound = path2 .. "m24_fuse_start.wav"
ENT.PopLoopSound = path2 .. "m24_fuse_loop.wav"

ENT.nextloopsound = 999999999999

function ENT:Think()

    local phys = self:GetPhysicsObject()
    if phys:IsValid() then
        phys:SetBuoyancyRatio(6)
    end

	-- print(LifeTime)
	LifeTime = 266
    if SERVER and self.SpawnTime + LifeTime < CurTime() then 
        SafeRemoveEntity(self)
        self.FuseSound:Stop()
    end
    
    if SERVER and self.nextloopsound < CurTime() then 
        if (self.SpawnTime + self.EmitTime - CurTime()) > 0 then
			self.FuseSound:Stop()
            self:EmitSound(self.loopSound, 60, 100, 1, nil, nil, 0)
            self.nextloopsound = CurTime() + 1.15
        else
            self:EmitSound(self.loopendSound, 60, 100, 1, nil, nil, 0)
            self.nextloopsound = 9999999999
        end
    end

    if self.Defused then return end

    if CLIENT and !self.LightPlayed then
        self.LightPlayed = true
        ParticleEffectAttach("port_smoke_heavy", PATTACH_ABSORIGIN_FOLLOW, self, 1) -- flash
		self:EmitSound(self.closeSound, 60, 100, 1, nil, nil, 0)
    end

    if self.StartTime > 0 and self.SpawnTime + self.StartTime < CurTime() then
        self:StartSmoke()
        return
    end

end

PrecacheParticleSystem( "smoke_exhaust_01" )

function ENT:StartSmoke()
    self.Defused = true

    if CLIENT then
        ParticleEffectAttach( "smoke_exhaust_01", PATTACH_ABSORIGIN_FOLLOW, self, 1 )
        timer.Simple(self.EmitTime, function()
            if IsValid(self) then self:StopParticles() end
        end)
    else
        self:EmitSound(self.closeSound, 60, 100, 1, nil, nil, 0)
        self.nextloopsound = CurTime() + 0.9

        local fear = ents.Create("ai_sound")
        fear:SetKeyValue("soundtype", 8)
        fear:SetKeyValue("volume", 256)
        fear:SetKeyValue("duration", 80)
        fear:SetOwner(self.Owner)
        fear:SetPos(self:GetPos())
        fear:Fire("EmitAISound" , "", 0.82)
        fear:Fire("kill", "", 6)

        local exp = ents.Create("env_smoketrail")
        exp:SetKeyValue("startsize", "11100")
        exp:SetKeyValue("endsize", "100000")
        exp:SetKeyValue("spawnradius", "128")
        exp:SetKeyValue("opacity", "1")
        exp:SetKeyValue("lifetime", "" .. self.EmitTime)
        exp:SetKeyValue("spawnrate", "4")
        exp:SetKeyValue("emittime", "" .. self.EmitTime)
        exp:SetKeyValue("maxspeed", "1")
        exp:SetKeyValue("maxdirectedspeed", "5")
        exp:SetKeyValue("startcolor", "200 200 200")
        exp:SetKeyValue("endcolor", "160 160 160")
        exp:SetPos(self:GetPos())
        exp:SetParent(self)
        exp:Spawn()
        exp:Fire("kill", "", self.EmitTime + 1)
    end
end

function ENT:Initialize()
        self:SetModel(self.Model)
        if self.PhysBoxSize then
            self:PhysicsInitBox(-self.PhysBoxSize, self.PhysBoxSize)
        elseif self.SphereSize then
            self:PhysicsInitSphere(self.SphereSize, self.PhysMat)
        else
            self:PhysicsInit(SOLID_VPHYSICS)
            self:SetSolid(SOLID_VPHYSICS)
        end

        local phys = self:GetPhysicsObject()
        if phys:IsValid() then
            phys:Wake()
			phys:AddAngleVelocity(Vector(250, 1000, 500))
            phys:EnableDrag(self.Drag)
            phys:SetDragCoefficient(self.DragCoefficient)
            phys:EnableGravity(self.Gravity)
            phys:SetMass(self.Mass)
            phys:SetBuoyancyRatio(6)
        end

        if self.SmokeTrail then
            util.SpriteTrail(self, 0, Color( 255 , 255 , 255 ), false, self.SmokeTrailSize, 0, self.SmokeTrailTime, 1 / self.SmokeTrailSize * 0.5, self.SmokeTrailMat)
        end

        self.FuseSound = CreateSound(self, self.PopLoopSound)
        self.FuseSound:Play()

        self.SpawnTime = CurTime()
end

if CLIENT then
    function ENT:Initialize()
        self.SpawnTime = CurTime()

        -- ParticleEffectAttach("port_smoke_heavy", PATTACH_ABSORIGIN_FOLLOW, self, 1) -- flash
    end
end

function ENT:Use(activator, caller, useType, value)
        if not IsValid(activator) or not activator:IsPlayer() then return end

        local phys = self:GetPhysicsObject()
        if not IsValid(phys) then
            activator:ChatPrint("Can't pick this up (no physics object).")
            return
        end

        -- Use player's built-in pickup function (this is what makes +use pick up props)
        if activator.PickupObject then
            activator:PickupObject(self)
        end
end